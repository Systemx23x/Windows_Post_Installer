//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// networkwizard.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

function NetworkUpdated()
{
   position = "networkwizard.js";
   whatfunc = "NetworkUpdated()";

   isNetworkSaved = false;
}

function CreateNetworkPage()
{
   position = "networkwizard.js";
   whatfunc = "CreateNetworkPage()";

   NetworkWindow = dhxWins.createWindow("NetworkWindow", 50, 50, 500, document.getElementById("bgpiclayer").offsetHeight - 50);
   NetworkWindow.setText(getText(lblNetworkWizard));
   NetworkWindow.setModal(true);
   NetworkWindow.button("park").hide();
   NetworkWindow.button("minmax1").hide();
   NetworkWindow.button("close").hide();
   NetworkWindow.keepInViewport(true);
   NetworkWindow.denyResize();
   NetworkWindow.center();
   ActiveWindow = NetworkWindow.getText();
   BlockWindow = "NetworkWindow";

   StatusBar = NetworkWindow.attachStatusBar();

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layernetwork";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "10px";

   objDiv.appendChild(newDiv);

   NetworkWindow.attachObject("layernetwork");
   document.getElementById("layernetwork").style.visibility = 'hidden';

   CreateTab("\\Common\\networkwizardtemplate.htm", "layernetwork");
   CreateTab("\\Common\\networkwizardtemplate_user.htm", "tabtabUser");
   CreateTab("\\Common\\networkwizardtemplate_general.htm", "tabtabGeneral");
   CreateTab("\\Common\\networkwizardtemplate_ipsettings.htm", "tabtabIPSettings");
   CreateTab("\\Common\\networkwizardtemplate_dns.htm", "tabtabDNS");
   CreateTab("\\Common\\networkwizardtemplate_wins.htm", "tabtabWINS");

   networkTabs = new dhtmlXTabBar("NetworkTabs", "top");
   networkTabs.setImagePath("../common/codebase/imgs/");
   networkTabs.setStyle(dhxSkin);
   networkTabs.enableForceHiding(true);
   var tablist = new Array('tabUser', 'tabGeneral', 'tabIPSettings', 'tabDNS', 'tabWINS');
   for (var i = 0; i < tablist.length; i ++ )
   {
      networkTabs.addTab("Tab" + (i + 1).toString(), getText(eval(tablist[i])), "" + Math.round((parseInt(document.getElementById("NetworkTabs").offsetWidth) - 16) / tablist.length) + "px");
   }

   LocalizeNetworkTexts();

   UsersGrid = new dhtmlXGridObject('UsersGrid');
   UsersGrid.setImagePath("../common/codebase/imgs/");
   UsersGrid.setSkin(dhxSkin);
   UsersGrid.setHeader(getText(GridFriendlyName) + ',' + getText(GridComputerName) + ',' + getText(GridUserName));
   UsersGrid.setInitWidths("*,125,125");
   UsersGrid.setColAlign("left,left,left");
   UsersGrid.setColTypes("ro,ro,ro");
   UsersGrid.setColSorting("str,str,str");
   UsersGrid.enableMultiselect(false);
   UsersGrid.enableMultiline(false);
   UsersGrid.enableKeyboardSupport(true);
   UsersGrid.attachEvent("onRowSelect", JumpToUser);
   UsersGrid.init();
   UsersGrid.objBox.style.overflowX = "hidden";

   var pos1 = getAbsolutePos(document.all.layernetwork);
   var pos2 = getAbsolutePos(document.all.ObtainIP1);
   document.getElementById("RadioSpacer2").style.width = (pos2.x - pos1.x) - 15;
   document.getElementById("RadioSpacer3").style.width = (pos2.x - pos1.x) - 15;

   IPAddressesGrid = new dhtmlXGridObject('IPAddressesGrid');
   IPAddressesGrid.setImagePath("../common/codebase/imgs/");
   IPAddressesGrid.setSkin(dhxSkin);
   IPAddressesGrid.setHeader(getText(lblIPAddresses) + ',' + getText(lblSubnetMask));
   IPAddressesGrid.setInitWidths("*,*");
   IPAddressesGrid.setColAlign("left,left");
   IPAddressesGrid.setColTypes("ro,ro");
   IPAddressesGrid.enableMultiselect(false);
   IPAddressesGrid.enableMultiline(false);
   IPAddressesGrid.enableKeyboardSupport(false);
   IPAddressesGrid.attachEvent("onRowSelect", HandlePickIPAddress);
   IPAddressesGrid.init();
   IPAddressesGrid.objBox.style.overflowX = "hidden";

   DefaultGatewaysGrid = new dhtmlXGridObject('DefaultGatewaysGrid');
   DefaultGatewaysGrid.setImagePath("../common/codebase/imgs/");
   DefaultGatewaysGrid.setSkin(dhxSkin);
   DefaultGatewaysGrid.setHeader(getText(lblGateway) + ',' + getText(lblMetric));
   DefaultGatewaysGrid.setInitWidths("*,*");
   DefaultGatewaysGrid.setColAlign("left,left");
   DefaultGatewaysGrid.setColTypes("ro,ro");
   DefaultGatewaysGrid.enableMultiselect(false);
   DefaultGatewaysGrid.enableMultiline(false);
   DefaultGatewaysGrid.enableKeyboardSupport(false);
   DefaultGatewaysGrid.attachEvent("onRowSelect", HandlePickDefaultGateway);
   DefaultGatewaysGrid.init();
   DefaultGatewaysGrid.objBox.style.overflowX = "hidden";

   DNSServersGrid = new dhtmlXGridObject('DNSServersGrid');
   DNSServersGrid.setImagePath("../common/codebase/imgs/");
   DNSServersGrid.setSkin(dhxSkin);
   DNSServersGrid.enableDragAndDrop(true);
   DNSServersGrid.setHeader(getText(lblDNSServersInOrder));
   DNSServersGrid.setInitWidths("*");
   DNSServersGrid.setColAlign("left");
   DNSServersGrid.setColTypes("ro");
   DNSServersGrid.enableMultiselect(false);
   DNSServersGrid.enableMultiline(false);
   DNSServersGrid.enableKeyboardSupport(false);
   DNSServersGrid.attachEvent("onRowSelect", HandlePickDNSServer);
   DNSServersGrid.attachEvent("onDrop", HandleDropDNSServer);
   DNSServersGrid.init();
   DNSServersGrid.objBox.style.overflowX = "hidden";

   WINSServersGrid = new dhtmlXGridObject('WINSServersGrid');
   WINSServersGrid.setImagePath("../common/codebase/imgs/");
   WINSServersGrid.setSkin(dhxSkin);
   WINSServersGrid.enableDragAndDrop(true);
   WINSServersGrid.setHeader(getText(lblWINSServersInOrder));
   WINSServersGrid.setInitWidths("*");
   WINSServersGrid.setColAlign("left");
   WINSServersGrid.setColTypes("ro");
   WINSServersGrid.enableMultiselect(false);
   WINSServersGrid.enableMultiline(false);
   WINSServersGrid.enableKeyboardSupport(false);
   WINSServersGrid.attachEvent("onRowSelect", HandlePickWINSServer);
   WINSServersGrid.init();
   WINSServersGrid.objBox.style.overflowX = "hidden";

   for (var i = 0; i < tablist.length; i ++ )
   {
      networkTabs.setContent("Tab" + (i + 1).toString(), "tab" + tablist[i]);
   }

   networkTabs.setTabActive('Tab1');


   for (var i = 0; i < NetworkOptions.Users.length;
   i ++ )
   NetworkOptions.Users[i].UserPassword = decode64(NetworkOptions.Users[i].UserPassword);

   PopulateUsersGrid();
   cpos = 0;
   FillInAllTabs(cpos);

   FillInNetworkFile();

   document.getElementById("layernetwork").style.visibility = 'visible';
   document.getElementById("layernetwork").style.display = 'block';
}

function LocalizeNetworkTexts()
{
   position = "networkwizard.js";
   whatfunc = "LocalizeNetworkTexts()";

   document.getElementById("lblPickUserWhenInstall").innerHTML = getText(lblPickUserWhenInstall);
   document.getElementById("legControlsUsers").innerHTML = getText(lblControls);
   document.getElementById("Network_UsersAdd").innerHTML = getText(btnAdd);
   document.getElementById("Network_UsersDelete").innerHTML = getText(btnDelete);
   document.getElementById("legUserInformation").innerHTML = getText(legUserInformation);
   document.getElementById("lblFriendlyName").innerHTML = getText(lblFriendlyName);
   document.getElementById("lblComputerName").innerHTML = getText(lblComputerName);
   document.getElementById("legWindowsUserInformation").innerHTML = getText(legWindowsUserInformation);
   document.getElementById("lblUserName").innerHTML = getText(lblUserName);
   document.getElementById("lblUserPassword").innerHTML = getText(lblUserPassword);
   document.getElementById("lblConfirmPassword").innerHTML = getText(lblConfirmPassword);
   document.getElementById("lblAdministrator").innerHTML = getText(lblAdministrator);
   document.getElementById("legJoinWorkgroup").innerHTML = getText(legJoinWorkgroup);
   document.getElementById("lblWorkgroup").innerHTML = getText(lblWorkgroup);
   document.getElementById("legOptions").innerHTML = getText(legOptions);
   document.getElementById("lblRebootAfterApplied").innerHTML = getText(lblRebootAfterApplied);
   document.getElementById("lblAutoLogonUser").innerHTML = getText(lblAutoLogonUser);
   document.getElementById("lblClearAutoLogonUser").innerHTML = getText(lblClearAutoLogonUser);
   document.getElementById("txtIPSettings").innerHTML = getText(txtIPSettings);
   document.getElementById("lblObtainIPAutomatically").innerHTML = getText(lblObtainIPAutomatically);
   document.getElementById("lblUseFollowingIPAddress").innerHTML = getText(lblUseFollowingIPAddress) + "&nbsp;&nbsp;";
   document.getElementById("lblIPAddress").innerHTML = getText(lblIPAddress);
   document.getElementById("lblSubnetMask").innerHTML = getText(lblSubnetMask);
   document.getElementById("lblDefaultGateway").innerHTML = getText(lblDefaultGateway);
   document.getElementById("lblObtainDNSAutomatically").innerHTML = getText(lblObtainDNSAutomatically);
   document.getElementById("lblUseFollowingDNSAddress").innerHTML = getText(lblUseFollowingDNSAddress) + "&nbsp;&nbsp;";
   document.getElementById("lblPreferredDNS").innerHTML = getText(lblPreferredDNS);
   document.getElementById("lblAlternateDNS").innerHTML = getText(lblAlternateDNS);
   document.getElementById("lblIPAddresses").innerHTML = getText(lblIPAddresses);
   document.getElementById("lblIPAddresses_Add").innerHTML = getText(lblAdd);
   document.getElementById("lblIPAddresses_Edit").innerHTML = getText(lblEdit);
   document.getElementById("lblIPAddresses_Delete").innerHTML = getText(lblDelete);
   document.getElementById("lblDefaultGateways").innerHTML = getText(lblDefaultGateways);
   document.getElementById("lblDefaultGateways_Add").innerHTML = getText(lblAdd);
   document.getElementById("lblDefaultGateways_Edit").innerHTML = getText(lblEdit);
   document.getElementById("lblDefaultGateways_Delete").innerHTML = getText(lblDelete);
   document.getElementById("lblAutomaticMetric").innerHTML = getText(lblAutomaticMetric) + "&nbsp;&nbsp;";
   document.getElementById("lblInterfaceMetric").innerHTML = getText(lblInterfaceMetric);
   document.getElementById("lblDNSServers").innerHTML = getText(lblDNSServers);
   document.getElementById("lblDNSServers_Add").innerHTML = getText(lblAdd);
   document.getElementById("lblDNSServers_Edit").innerHTML = getText(lblEdit);
   document.getElementById("lblDNSServers_Delete").innerHTML = getText(lblDelete);
   document.getElementById("lblWINSServers").innerHTML = getText(lblWINSServers);
   document.getElementById("lblWINSServers_Add").innerHTML = getText(lblAdd);
   document.getElementById("lblWINSServers_Edit").innerHTML = getText(lblEdit);
   document.getElementById("lblWINSServers_Delete").innerHTML = getText(lblDelete);
   document.getElementById("networkNewNetwork").innerHTML = getText(btnNewNetwork);
   document.getElementById("networkRead").innerHTML = getText(btnRead);
   document.getElementById("networkSave").innerHTML = getText(btnSave);
   document.getElementById("networkSaveAs").innerHTML = getText(btnSaveAs);
   document.getElementById("networkExit").innerHTML = getText(btnExit);
}

function CheckForDefaultUser()
{
   position = "networkwizard.js";
   whatfunc = "CheckForDefaultUser()";

   var foundDefault = false;

   for (var i = 0; i < NetworkOptions.Users.length;
   i ++ )
   {
      if (NetworkOptions.Users[i].UserName == ".default")
      {
         foundDefault = true;
         break;
      }
   }
   if ( ! foundDefault)
   {
      var AddUser;

      AddUser = new NewUser();
      NetworkOptions.Users.splice(0, 0, AddUser);
      NetworkOptions.Users[0].FriendlyName = ".default";
      NetworkOptions.Users[0].ComputerName = "";
      NetworkOptions.Users[0].UserName = "Administrator";
      NetworkOptions.Users[0].UserPassword = "";
      NetworkOptions.Users[0].Administrator = true;
   }
}

function CheckForNetworkUser(user)
{
   position = "networkwizard.js";
   whatfunc = "CheckForNetworkUser()";

   var foundUser = false;

   UserPos = - 1;

   for (var i = 0; i < NetworkOptions.Users.length;
   i ++ )
   {
      if (NetworkOptions.Users[i].FriendlyName == user)
      {
         foundUser = true;
         UserPos = i;
         break;
      }
   }

   return foundUser;
}

function CopyUser(pos)
{
   position = "networkwizard.js";
   whatfunc = "CopyUser()";

   // User tab
   NetworkOptions.Users[cpos].FriendlyName = document.getElementById("FriendlyName").value;
   NetworkOptions.Users[cpos].ComputerName = document.getElementById("ComputerName").value;
   NetworkOptions.Users[cpos].UserName = document.getElementById("UserName").value;
   NetworkOptions.Users[cpos].UserPassword = document.getElementById("UserPassword").value;
   NetworkOptions.Users[cpos].Administrator = document.getElementById("Administrator").checked;
   NetworkOptions.Users[cpos].Workgroup = document.getElementById("Workgroup").value.toUpperCase();
   NetworkOptions.Users[cpos].RebootAfterApplied = document.getElementById("RebootAfterApplied").checked;
   NetworkOptions.Users[cpos].AutoLogonUser = document.getElementById("AutoLogonUser").checked;
   NetworkOptions.Users[cpos].ClearAutoLogonUser = document.getElementById("ClearAutoLogonUser").checked;

   // General tab
   if (document.getElementById("ObtainIP0").checked)
   NetworkOptions.Users[cpos].ObtainIP = "Automatically";
   if (document.getElementById("ObtainIP1").checked)
   NetworkOptions.Users[cpos].ObtainIP = "Assigned";
   NetworkOptions.Users[cpos].IPAddress = document.getElementById("IPAddress").value;
   NetworkOptions.Users[cpos].SubnetMask = document.getElementById("SubnetMask").value;
   NetworkOptions.Users[cpos].DefaultGateway = document.getElementById("DefaultGateway").value;

   if (document.getElementById("ObtainDNS0").checked)
   NetworkOptions.Users[cpos].ObtainDNS = "Automatically";
   if (document.getElementById("ObtainDNS1").checked)
   NetworkOptions.Users[cpos].ObtainDNS = "Assigned";
   NetworkOptions.Users[cpos].PreferredDNS = document.getElementById("PreferredDNS").value;
   NetworkOptions.Users[cpos].AlternateDNS = document.getElementById("AlternateDNS").value;

   // IP Settings tab
   NetworkOptions.Users[cpos].IPAddresses.splice(0, NetworkOptions.Users[cpos].IPAddresses.length);
   for (i = 0; i < IPAddressesGrid.getRowsNum(); i ++ )
   {
      var AddIP = new NewIPAddress();
      NetworkOptions.Users[cpos].IPAddresses.splice(NetworkOptions.Users[cpos].IPAddresses.length, 0, AddIP);
      NetworkOptions.Users[cpos].IPAddresses[i].IP = IPAddressesGrid.cells(IPAddressesGrid.getRowId(i), 0).getValue();
      NetworkOptions.Users[cpos].IPAddresses[i].Subnet = IPAddressesGrid.cells(IPAddressesGrid.getRowId(i), 1).getValue();
   }

   NetworkOptions.Users[cpos].DefaultGateways.splice(0, NetworkOptions.Users[cpos].DefaultGateways.length);
   for (i = 0; i < DefaultGatewaysGrid.getRowsNum();
   i ++ )
   {
      var AddDG = new NewDefaultGateway();
      NetworkOptions.Users[cpos].DefaultGateways.splice(NetworkOptions.Users[cpos].DefaultGateways.length, 0, AddDG);

      NetworkOptions.Users[cpos].DefaultGateways[i].Gateway = DefaultGatewaysGrid.cells(DefaultGatewaysGrid.getRowId(i), 0).getValue();
      NetworkOptions.Users[cpos].DefaultGateways[i].Metric = DefaultGatewaysGrid.cells(DefaultGatewaysGrid.getRowId(i), 1).getValue();
   }

   NetworkOptions.Users[cpos].AutomaticMetric = document.getElementById("AutomaticMetric").checked;
   NetworkOptions.Users[cpos].InterfaceMetric = document.getElementById("InterfaceMetric").value;

   // DNS tab
   NetworkOptions.Users[cpos].DNSServers.splice(0, NetworkOptions.Users[cpos].DNSServers.length);
   for (i = 0; i < DNSServersGrid.getRowsNum(); i ++ )
   {
      var AddDNS = new NewDNSServer();
      NetworkOptions.Users[cpos].DNSServers.splice(NetworkOptions.Users[cpos].DNSServers.length, 0, AddDNS);

      NetworkOptions.Users[cpos].DNSServers[i].IP = DNSServersGrid.cells(DNSServersGrid.getRowId(i), 0).getValue();
   }

   // WINS tab
   NetworkOptions.Users[cpos].WINSServers.splice(0, NetworkOptions.Users[cpos].WINSServers.length);
   for (i = 0; i < WINSServersGrid.getRowsNum(); i ++ )
   {
      var AddWINS = new NewWINSServer();
      NetworkOptions.Users[cpos].WINSServers.splice(NetworkOptions.Users[cpos].WINSServers.length, 0, AddWINS);

      NetworkOptions.Users[cpos].WINSServers[i].IP = WINSServersGrid.cells(WINSServersGrid.getRowId(i), 0).getValue();
   }
}

function ClearAllTabs()
{
   position = "networkwizard.js";
   whatfunc = "ClearAllTabs()";

   ClearOtherGadgets();
   ClearUserTab();
   ClearGeneralTab();
   ClearIPSettingsTab();
   ClearDNSTab();
   ClearWINSTab();
}

function FillInAllTabs(pos)
{
   position = "networkwizard.js";
   whatfunc = "FillInAllTabs()";

   FillInOtherGadgets();
   FillInUserTab(pos);
   FillInGeneralTab(pos);
   FillInIPSettingsTab(pos);
   FillInDNSTab(pos);
   FillInWINSTab(pos);
}

function ClearOtherGadgets()
{
   position = "networkwizard.js";
   whatfunc = "ClearOtherGadgets()";

}

function FillInOtherGadgets()
{
   position = "networkwizard.js";
   whatfunc = "FillInOtherGadgets()";

   if (NetworkOptions.OpenPickUser)
   {
      document.getElementById("PickUserBeforeInstall").checked = true;
   }
   else
   {
      document.getElementById("PickUserBeforeInstall").checked = false;
   }
}

function HandleOpenPickUser()
{
   position = "networkwizard.js";
   whatfunc = "HandleOpenPickUser()";

   if (document.getElementById("PickUserBeforeInstall").checked)
   {
      NetworkOptions.OpenPickUser = true;
   }
   else
   {
      NetworkOptions.OpenPickUser = false;
   }
}

function PopulateUsersGrid()
{
   position = "networkwizard.js";
   whatfunc = "PopulateUsersGrid()";

   UsersGrid.clearAll();

   for (var i = 0; i < NetworkOptions.Users.length;
   i ++ )
   {
      UsersGrid.addRow(i, [NetworkOptions.Users[i].FriendlyName, NetworkOptions.Users[i].ComputerName, NetworkOptions.Users[i].UserName]);
   }

   UsersGrid.selectRow(0, false, false, true);
}

function JumpToUser(pos)
{
   position = "networkwizard.js";
   whatfunc = "JumpToUser()";

   CopyUser(cpos);

   ClearAllTabs();

   cpos = pos;
   FillInAllTabs(cpos);
}

function HandleAddUser()
{
   position = "networkwizard.js";
   whatfunc = "HandleAddUser()";

   var AddUser;

   CopyUser(cpos);

   AddUser = new NewUser();
   NetworkOptions.Users.splice(NetworkOptions.Users.length, 0, AddUser);

   cpos = NetworkOptions.Users.length - 1;

   UsersGrid.addRow(UsersGrid.getRowsNum(), [NetworkOptions.Users[cpos].FriendlyName, NetworkOptions.Users[cpos].ComputerName, NetworkOptions.Users[cpos].UserName]);
   UsersGrid.selectRow(UsersGrid.getRowsNum() - 1, false, false, true);

   ClearAllTabs();
   FillInAllTabs(cpos);

   networkTabs.setTabActive('Tab1', false);

   selectText(this.document.all.FriendlyName, getText(txtNew));

   NetworkUpdated();
}

function NewUser()
{
   position = "networkwizard.js";
   whatfunc = "NewUser()";

   this.FriendlyName = getText(txtNew);
   this.ComputerName = "";
   this.UserName = "";
   this.UserPassword = "";
   this.Administrator = false;
   this.Workgroup = "";
   this.RebootAfterApplied = false;
   this.AutoLogonUser = false;
   this.ClearAutoLogonUser = false;
   this.ObtainIP = "Automatically";
   this.IPAddress = "";
   this.SubnetMask = "";
   this.DefaultGateway = "";
   this.ObtainDNS = "Automatically";
   this.PreferredDNS = "";
   this.AlternateDNS = "";
   this.IPAddresses = [];
   this.DefaultGateways = [];
   this.AutomaticMetric = true;
   this.InterfaceMetric = "";
   this.DNSServers = [];
   this.WINSServers = [];
}

function NewIPAddress()
{
   position = "networkwizard.js";
   whatfunc = "NewIPAddress()";

   this.IP = "";
   this.Subnet = "";
}

function NewDefaultGateway()
{
   position = "networkwizard.js";
   whatfunc = "NewDefaultGateway()";

   this.Gateway = "";
   this.Metric = "";
}

function NewDNSServer()
{
   position = "networkwizard.js";
   whatfunc = "NewDNSServer()";

   this.IP = "";
}

function NewWINSServer()
{
   position = "networkwizard.js";
   whatfunc = "NewWINSServer()";

   this.IP = "";
}

function HandleDeleteUser()
{
   position = "networkwizard.js";
   whatfunc = "HandleDeleteUser()";

   NetworkOptions.Users.splice(cpos, 1);

   PopulateUsersGrid();
   cpos = UsersGrid.getRowId(0);
   UsersGrid.selectRowById(cpos, false, true);

   FillInAllTabs(cpos);

   networkTabs.setTabActive('Tab1', false);

   NetworkUpdated();
}

function ClearUserTab()
{
   position = "networkwizard.js";
   whatfunc = "ClearUserTab()";

   document.getElementById("FriendlyName").value = "";
   document.getElementById("ComputerName").value = "";
   document.getElementById("UserName").value = "";
   document.getElementById("UserPassword").value = "";
   document.getElementById("ConfirmPassword").value = "";
   document.getElementById("Administrator").checked = false;
   document.getElementById("Workgroup").disabled = true;
   document.getElementById("Workgroup").value = "";
}

function FillInUserTab(pos)
{
   position = "networkwizard.js";
   whatfunc = "FillInUserTab()";

   document.getElementById("FriendlyName").value = NetworkOptions.Users[pos].FriendlyName;
   if (document.getElementById("FriendlyName").value == ".default")
   {
      document.getElementById("Btn_Network_UsersDelete").disabled = true;
      document.getElementById("FriendlyName").disabled = true;
   }
   else
   {
      document.getElementById("Btn_Network_UsersDelete").disabled = false;
      document.getElementById("FriendlyName").disabled = false;
   }
   document.getElementById("ComputerName").value = NetworkOptions.Users[pos].ComputerName;
   document.getElementById("UserName").value = NetworkOptions.Users[pos].UserName;
   document.getElementById("UserPassword").value = NetworkOptions.Users[pos].UserPassword;
   document.getElementById("ConfirmPassword").value = NetworkOptions.Users[pos].UserPassword;
   document.getElementById("Administrator").checked = NetworkOptions.Users[pos].Administrator;
   document.getElementById("Workgroup").value = NetworkOptions.Users[pos].Workgroup;
   document.getElementById("Workgroup").disabled = false;
   document.getElementById("RebootAfterApplied").checked = NetworkOptions.Users[pos].RebootAfterApplied;
   document.getElementById("AutoLogonUser").checked = NetworkOptions.Users[pos].AutoLogonUser;
   document.getElementById("ClearAutoLogonUser").checked = NetworkOptions.Users[pos].ClearAutoLogonUser;
   HandleAutoLogonUser();
}

function HandleFriendlyName()
{
   position = "networkwizard.js";
   whatfunc = "HandleFriendlyName()";

   if (document.getElementById("FriendlyName").value == ".default")
   {
      document.getElementById("FriendlyName").value = "";
      document.getElementById("FriendlyName").focus();
   }
   else
   UsersGrid.cells(cpos, 0).setValue(document.getElementById("FriendlyName").value);
}

function HandleComputerName()
{
   position = "networkwizard.js";
   whatfunc = "HandleComputerName()";

   var txt;

   txt = HandleSpecialCharacters(document.getElementById("ComputerName").value, false);
   document.getElementById("ComputerName").value = txt;
   UsersGrid.cells(cpos, 1).setValue(txt);
}

function HandleUserName()
{
   position = "networkwizard.js";
   whatfunc = "HandleUserName()";

   var txt;

   txt = HandleSpecialCharacters(document.getElementById("UserName").value, true);
   document.getElementById("UserName").value = txt;
   UsersGrid.cells(cpos, 2).setValue(document.getElementById("UserName").value);
}

function HandleUserPassword()
{
   position = "networkwizard.js";
   whatfunc = "HandleUserPassword()";

}

function HandleConfirmPassword()
{
   position = "networkwizard.js";
   whatfunc = "HandleConfirmPassword()";

   if (document.getElementById("UserPassword").value != document.getElementById("ConfirmPassword").value)
   {
      Alert("", getText(txtPasswordsDontMatch), getText(lblOK), "", 2, 0, 0, 0);
      document.getElementById("UserPassword").value = "";
      document.getElementById("ConfirmPassword").value = "";
      document.getElementById("UserPassword").focus();
   }
}

function HandleAdministrator()
{
   position = "networkwizard.js";
   whatfunc = "HandleAdministrator()";

}

function HandleWorkgroup()
{
   position = "networkwizard.js";
   whatfunc = "HandleWorkgroup()";

   var txt;

   txt = HandleSpecialCharacters(document.getElementById("Workgroup").value, false);
   document.getElementById("Workgroup").value = txt;
}

function HandleRebootAfterApplied()
{
   position = "networkwizard.js";
   whatfunc = "HandleRebootAfterApplied()";

}

function HandleAutoLogonUser()
{
   position = "networkwizard.js";
   whatfunc = "HandleAutoLogonUser()";

   if (document.getElementById("AutoLogonUser").checked)
   {
      document.getElementById("ClearAutoLogonUser").disabled = false;
   }
   else
   {
      document.getElementById("ClearAutoLogonUser").disabled = true;
      document.getElementById("ClearAutoLogonUser").checked = false;
   }
}

function HandleClearAutoLogonUser()
{
   position = "networkwizard.js";
   whatfunc = "HandleClearAutoLogonUser()";

}

function ClearGeneralTab()
{
   position = "networkwizard.js";
   whatfunc = "ClearGeneralTab()";

   document.getElementById("ObtainIP0").checked = false;
   document.getElementById("ObtainIP1").checked = false;
   document.getElementById("IPAddress").value = "";
   document.getElementById("SubnetMask").value = "";
   document.getElementById("DefaultGateway").value = "";
   document.getElementById("ObtainDNS0").checked = false;
   document.getElementById("ObtainDNS1").checked = false;
   document.getElementById("PreferredDNS").value = "";
   document.getElementById("AlternateDNS").value = "";
}

function FillInGeneralTab(pos)
{
   position = "networkwizard.js";
   whatfunc = "FillInGeneralTab()";

   if (NetworkOptions.Users[pos].ObtainIP == "Automatically")
   {
      document.getElementById("ObtainIP0").checked = true;
      document.getElementById("ObtainIP1").checked = false;
      document.getElementById("IPAddress").value = "";
      document.getElementById("IPAddress").disabled = true;
      document.getElementById("SubnetMask").value = "";
      document.getElementById("SubnetMask").disabled = true;
      document.getElementById("DefaultGateway").value = "";
      document.getElementById("DefaultGateway").disabled = true;
      document.getElementById("ObtainDNS0").disabled = false;
      document.getElementById("ObtainDNS1").disabled = false;
   }
   else
   {
      document.getElementById("ObtainIP0").checked = false;
      document.getElementById("ObtainIP1").checked = true;
      document.getElementById("IPAddress").value = NetworkOptions.Users[pos].IPAddress;
      document.getElementById("IPAddress").disabled = false;
      document.getElementById("SubnetMask").value = NetworkOptions.Users[pos].SubnetMask;
      document.getElementById("SubnetMask").disabled = false;
      document.getElementById("DefaultGateway").value = NetworkOptions.Users[pos].DefaultGateway;
      document.getElementById("DefaultGateway").disabled = false;
      document.getElementById("ObtainDNS0").disabled = true;
      document.getElementById("ObtainDNS1").disabled = false;
   }

   if (NetworkOptions.Users[pos].ObtainDNS == "Automatically")
   {
      document.getElementById("ObtainDNS0").checked = true;
      document.getElementById("ObtainDNS1").checked = false;
      document.getElementById("PreferredDNS").value = "";
      document.getElementById("PreferredDNS").disabled = true;
      document.getElementById("AlternateDNS").value = "";
      document.getElementById("AlternateDNS").disabled = true;
   }
   else
   {
      document.getElementById("ObtainDNS0").checked = false;
      document.getElementById("ObtainDNS1").checked = true;
      document.getElementById("PreferredDNS").value = NetworkOptions.Users[pos].PreferredDNS;
      document.getElementById("PreferredDNS").disabled = false;
      document.getElementById("AlternateDNS").value = NetworkOptions.Users[pos].AlternateDNS;
      document.getElementById("AlternateDNS").disabled = false;
   }
}

function HandleObtainIP()
{
   position = "networkwizard.js";
   whatfunc = "HandleObtainIP()";

   if (document.getElementById("ObtainIP0").checked)
   {
      document.getElementById("IPAddress").disabled = true;
      document.getElementById("IPAddress").value = "";
      document.getElementById("SubnetMask").disabled = true;
      document.getElementById("SubnetMask").value = "";
      document.getElementById("DefaultGateway").disabled = true;
      document.getElementById("DefaultGateway").value = "";
      document.getElementById("ObtainDNS0").disabled = false;
      document.getElementById("ObtainDNS1").disabled = false;
   }
   else
   {
      document.getElementById("IPAddress").disabled = false;
      document.getElementById("IPAddress").value = "";
      document.getElementById("SubnetMask").disabled = false;
      document.getElementById("SubnetMask").value = "";
      document.getElementById("DefaultGateway").disabled = false;
      document.getElementById("DefaultGateway").value = "";
      document.getElementById("ObtainDNS0").disabled = true;
      document.getElementById("ObtainDNS1").disabled = false;
      document.getElementById("IPAddress").focus();
   }

   IPAddressesGrid.clearAll();
   DefaultGatewaysGrid.clearAll();

   CopyUser(cpos);
   FillInIPSettingsTab(cpos);
}

function HandleIPAddress()
{
   position = "networkwizard.js";
   whatfunc = "HandleIPAddress()";

   var i, temp = [], subnet = "0.0.0.0";

   if (document.getElementById("IPAddress").value.indexOf(".") != - 1)
   {
      temp = document.getElementById("IPAddress").value.split(".");
      i = Number(temp[0]);
      if (i <= 127)
      subnet = "255.0.0.0";
      else if (i >= 128 && i <= 191)
      subnet = "255.255.0.0";
      else if (i >= 192 && i <= 254)
      subnet = "255.255.255.0";
      else
      subnet = "255.255.255.0";
   }
   document.getElementById("SubnetMask").value = subnet;

   if (IPAddressesGrid.getRowsNum() == 0)
   {
      IPAddressesGrid.addRow(0, [document.getElementById("IPAddress").value, document.getElementById("SubnetMask").value]);
      IPAddressesGrid.selectRowById(0, false, true);
   }
   else
   {
      IPAddressesGrid.cells(0, 0).setValue(document.getElementById("IPAddress").value);
      IPAddressesGrid.cells(0, 1).setValue(document.getElementById("SubnetMask").value);
   }

   CopyUser(cpos);
   IPAddressesAddEditDeleteState();
}

function HandleSubnetMask()
{
   position = "networkwizard.js";
   whatfunc = "HandleSubnetMask()";

   IPAddressesGrid.cells(0, 1).setValue(document.getElementById("SubnetMask").value);
}

function HandleDefaultGateway()
{
   position = "networkwizard.js";
   whatfunc = "HandleDefaultGateway()";

   if (DefaultGatewaysGrid.getRowsNum() == 0)
   {
      DefaultGatewaysGrid.addRow(0, [document.getElementById("DefaultGateway").value, getText(lblAutomatic)]);
      DefaultGatewaysGrid.selectRowById(0, false, true);
   }
   else
   {
      DefaultGatewaysGrid.cells(0, 0).setValue(document.getElementById("DefaultGateway").value);
      DefaultGatewaysGrid.cells(0, 1).setValue(getText(lblAutomatic));
   }

   CopyUser(cpos);
   DefaultGatewaysAddEditDeleteState();
}

function HandleObtainDNS()
{
   position = "networkwizard.js";
   whatfunc = "HandleObtainDNS()";

   if (document.getElementById("ObtainDNS0").checked)
   {
      document.getElementById("PreferredDNS").disabled = true;
      document.getElementById("PreferredDNS").value = "";
      document.getElementById("AlternateDNS").disabled = true;
      document.getElementById("AlternateDNS").value = "";
   }
   else
   {
      document.getElementById("PreferredDNS").disabled = false;
      document.getElementById("PreferredDNS").value = "";
      document.getElementById("AlternateDNS").disabled = false;
      document.getElementById("AlternateDNS").value = "";
      document.getElementById("PreferredDNS").focus();
   }

   DNSServersGrid.clearAll();

   CopyUser(cpos);
   FillInDNSTab(cpos);
}

function HandlePreferredDNS()
{
   position = "networkwizard.js";
   whatfunc = "HandlePreferredDNS()";

   if (DNSServersGrid.getRowsNum() == 0)
   {
      DNSServersGrid.addRow(0, [document.getElementById("PreferredDNS").value]);
      DNSServersGrid.selectRowById(0, false, true);
   }
   else
   {
      DNSServersGrid.cells(0, 0).setValue(document.getElementById("PreferredDNS").value);
   }

   CopyUser(cpos);
   DNSServersAddEditDeleteState();
}

function HandleAlternateDNS()
{
   position = "networkwizard.js";
   whatfunc = "HandleAlternateDNS()";

   if (DNSServersGrid.getRowsNum() == 0)
   {
      DNSServersGrid.addRow(0, [""]);
      DNSServersGrid.selectRowById(0, false, true);
      DNSServersGrid.addRow(1, [document.getElementById("AlternateDNS").value]);
      DNSServersGrid.selectRowById(1, false, true);
   }
   else if (DNSServersGrid.getRowsNum() == 1)
   {
      DNSServersGrid.addRow(1, [document.getElementById("AlternateDNS").value]);
      DNSServersGrid.selectRowById(1, false, true);
   }
   else
   {
      DNSServersGrid.cells(1, 0).setValue(document.getElementById("AlternateDNS").value);
   }

   CopyUser(cpos);
   DNSServersAddEditDeleteState();
}

function ClearIPSettingsTab()
{
   position = "networkwizard.js";
   whatfunc = "ClearIPSettingsTab()";

   IPAddressesGrid.clearAll();
   document.getElementById("Btn_IPAddresses_Add").disabled = true;
   document.getElementById("Btn_IPAddresses_Edit").disabled = true;
   document.getElementById("Btn_IPAddresses_Delete").disabled = true;

   DefaultGatewaysGrid.clearAll();
   document.getElementById("Btn_DefaultGateways_Add").disabled = true;
   document.getElementById("Btn_DefaultGateways_Edit").disabled = true;
   document.getElementById("Btn_DefaultGateways_Delete").disabled = true;
   document.getElementById("AutomaticMetric").checked = true;
   document.getElementById("InterfaceMetric").value = "";
   document.getElementById("InterfaceMetric").disabled = true;
}

function FillInIPSettingsTab(pos)
{
   position = "networkwizard.js";
   whatfunc = "FillInIPSettingsTab()";

   PopulateIPAddressesGrid();
   IPAddressesAddEditDeleteState();

   PopulateDefaultGatewaysGrid();
   DefaultGatewaysAddEditDeleteState();

   document.getElementById("AutomaticMetric").checked = NetworkOptions.Users[cpos].AutomaticMetric;
   if (NetworkOptions.Users[cpos].AutomaticMetric)
   {
      document.getElementById("InterfaceMetric").value = "";
      document.getElementById("InterfaceMetric").disabled = true;
   }
   else
   {
      document.getElementById("InterfaceMetric").value = NetworkOptions.Users[cpos].InterfaceMetric;
      document.getElementById("InterfaceMetric").disabled = false;
   }
}

function PopulateIPAddressesGrid()
{
   position = "networkwizard.js";
   whatfunc = "PopulateIPAddressesGrid()";

   IPAddressesGrid.clearAll();

   if (NetworkOptions.Users[cpos].ObtainIP == "Automatically")
   {
      IPAddressesGrid.addRow(0, [getText(lblDHCPEnabled), ""]);
   }
   else
   {
      for (var i = 0; i < NetworkOptions.Users[cpos].IPAddresses.length;
      i ++ )
      {
         IPAddressesGrid.addRow(i, [NetworkOptions.Users[cpos].IPAddresses[i].IP, NetworkOptions.Users[cpos].IPAddresses[i].Subnet]);
      }

      IPAddressesGrid.selectRow(0, false, false, true);
   }

   ippos = 0;
}

function IPAddressesAddEditDeleteState()
{
   position = "networkwizard.js";
   whatfunc = "IPAddressesAddEditDeleteState()";

   if (NetworkOptions.Users[cpos].IPAddresses.length == 0)
   {
      document.getElementById("Btn_IPAddresses_Edit").disabled = true;
      document.getElementById("Btn_IPAddresses_Delete").disabled = true;
   }
   else if (NetworkOptions.Users[cpos].IPAddresses.length == 1)
   {
      document.getElementById("Btn_IPAddresses_Edit").disabled = false;
      document.getElementById("Btn_IPAddresses_Delete").disabled = true;
   }
   else
   {
      document.getElementById("Btn_IPAddresses_Edit").disabled = false;
      document.getElementById("Btn_IPAddresses_Delete").disabled = false;
   }
   if (NetworkOptions.Users[cpos].ObtainIP == "Automatically")
   {
      document.getElementById("Btn_IPAddresses_Add").disabled = true;
      document.getElementById("Btn_IPAddresses_Edit").disabled = true;
      document.getElementById("Btn_IPAddresses_Delete").disabled = true;
   }
   else
   document.getElementById("Btn_IPAddresses_Add").disabled = false;
}

function PopulateDefaultGatewaysGrid()
{
   position = "networkwizard.js";
   whatfunc = "PopulateDefaultGatewaysGrid()";

   DefaultGatewaysGrid.clearAll();

   if (NetworkOptions.Users[cpos].ObtainIP == "Automatically")
   {
      DefaultGatewaysGrid.addRow(0, [getText(lblDHCPEnabled), ""]);
   }
   else
   {
      for (var i = 0; i < NetworkOptions.Users[cpos].DefaultGateways.length;
      i ++ )
      {
         DefaultGatewaysGrid.addRow(i, [NetworkOptions.Users[cpos].DefaultGateways[i].Gateway, NetworkOptions.Users[cpos].DefaultGateways[i].Metric]);
      }

      DefaultGatewaysGrid.selectRow(0, false, false, true);
   }

   dgpos = 0;
}

function DefaultGatewaysAddEditDeleteState()
{
   position = "networkwizard.js";
   whatfunc = "DefaultGatewaysAddEditDeleteState()";

   if (NetworkOptions.Users[cpos].DefaultGateways.length == 0)
   {
      document.getElementById("Btn_DefaultGateways_Edit").disabled = true;
      document.getElementById("Btn_DefaultGateways_Delete").disabled = true;
   }
   else if (NetworkOptions.Users[cpos].DefaultGateways.length == 1)
   {
      document.getElementById("Btn_DefaultGateways_Edit").disabled = false;
      document.getElementById("Btn_DefaultGateways_Delete").disabled = true;
   }
   else
   {
      document.getElementById("Btn_DefaultGateways_Edit").disabled = false;
      document.getElementById("Btn_DefaultGateways_Delete").disabled = false;
   }
   if (NetworkOptions.Users[cpos].ObtainIP == "Automatically")
   {
      document.getElementById("Btn_DefaultGateways_Add").disabled = true;
      document.getElementById("Btn_DefaultGateways_Edit").disabled = true;
      document.getElementById("Btn_DefaultGateways_Delete").disabled = true;
   }
   else
   document.getElementById("Btn_DefaultGateways_Add").disabled = false;
}

function HandlePickIPAddress(pos)
{
   position = "networkwizard.js";
   whatfunc = "HandlePickIPAddress()";

   ippos = pos;
}

function HandleIPAddress_AddEdit(mode)
{
   position = "networkwizard.js";
   whatfunc = "HandleIPAddress_AddEdit()";

   if (mode == 0)
   {
      IPAddressesGrid.addRow(IPAddressesGrid.getRowsNum(), [document.getElementById("IPAddress_TCPIP").value, document.getElementById("SubnetMask_TCPIP").value]);
      ippos = IPAddressesGrid.getRowsNum() - 1;
      IPAddressesGrid.selectRow(ippos, false, false, true);
      CopyUser(cpos);
      IPAddressesAddEditDeleteState();
   }
   if (mode == 1)
   {
      IPAddressesGrid.cells(ippos, 0).setValue(document.getElementById("IPAddress_TCPIP").value);
      IPAddressesGrid.cells(ippos, 1).setValue(document.getElementById("SubnetMask_TCPIP").value);
   }

   if (ippos == 0)
   {
      document.getElementById("IPAddress").value = document.getElementById("IPAddress_TCPIP").value;
      document.getElementById("SubnetMask").value = document.getElementById("SubnetMask_TCPIP").value;
   }

   HideTCPIPAddress();

   NetworkUpdated();
}

function HandleIPAddress_Delete()
{
   position = "networkwizard.js";
   whatfunc = "HandleIPAddress_Delete()";

   NetworkOptions.Users[cpos].IPAddresses.splice(ippos, 1);

   PopulateIPAddressesGrid();
   CopyUser(cpos);
   IPAddressesAddEditDeleteState();

   document.getElementById("IPAddress").value = IPAddressesGrid.cells(IPAddressesGrid.getRowId(ippos), 0).getValue();

   NetworkUpdated();
}

function ShowTCPIPAddress(mode)
{
   position = "networkwizard.js";
   whatfunc = "ShowTCPIPAddress()";

   AddEdit = mode;

   dhxWins.window("NetworkWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 400, 125);
   SubWizardWindow.setText(getText(lblTCPIPAddress));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\networkwizardtemplate_addeditipaddress.htm", "layersubwizard");

   document.getElementById("legIPAddress_TCPIP").innerHTML = getText(lblIPAddress);
   document.getElementById("lblIPAddress_TCPIP").innerHTML = getText(lblIPAddress);
   document.getElementById("lblSubnetMask_TCPIP").innerHTML = getText(lblSubnetMask);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);

   if (mode == 0)
   {
      document.getElementById("IPAddress_TCPIP").value = "";
      document.getElementById("SubnetMask_TCPIP").value = "";
   }
   if (mode == 1)
   {
      document.getElementById("IPAddress_TCPIP").value = IPAddressesGrid.cells(IPAddressesGrid.getRowId(ippos), 0).getValue();
      document.getElementById("SubnetMask_TCPIP").value = IPAddressesGrid.cells(IPAddressesGrid.getRowId(ippos), 1).getValue();
   }


   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   AutoSizeWindow(SubWizardWindow, "layersubwizard");

   document.getElementById("IPAddress_TCPIP").focus();
   moveCaretToEnd(this.document.all.IPAddress_TCPIP);
}

function HandleIPAddress_TCPIP()
{
   position = "networkwizard.js";
   whatfunc = "HandleIPAddress_TCPIP()";

   var i, temp = [], subnet = "0.0.0.0";

   if (document.getElementById("IPAddress_TCPIP").value.indexOf(".") != - 1)
   {
      temp = document.getElementById("IPAddress_TCPIP").value.split(".");
      i = Number(temp[0]);
      if (i <= 127)
      subnet = "255.0.0.0";
      else if (i >= 128 && i <= 191)
      subnet = "255.255.0.0";
      else if (i >= 192 && i <= 254)
      subnet = "255.255.255.0";
      else
      subnet = "255.255.255.0";
   }
   document.getElementById("SubnetMask_TCPIP").value = subnet;
}

function HideTCPIPAddress()
{
   position = "networkwizard.js";
   whatfunc = "HideTCPIPAddress()";

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = NetworkWindow.getText();
   dhxWins.window("NetworkWindow").setModal(true);
}

function HandlePickDefaultGateway(pos)
{
   position = "networkwizard.js";
   whatfunc = "HandlePickDefaultGateway()";

   dgpos = pos;
}

function HandleDefaultGateway_AddEdit(mode)
{
   position = "networkwizard.js";
   whatfunc = "HandleDefaultGateway_AddEdit()";

   if (mode == 0)
   {
      DefaultGatewaysGrid.addRow(DefaultGatewaysGrid.getRowsNum(), [document.getElementById("Gateway_TCPIP").value, ""]);
      dgpos = DefaultGatewaysGrid.getRowsNum() - 1;
      DefaultGatewaysGrid.selectRow(dgpos, false, false, true);
      CopyUser(cpos);
      DefaultGatewaysAddEditDeleteState();
   }
   if (mode == 1)
   {
      DefaultGatewaysGrid.cells(dgpos, 0).setValue(document.getElementById("Gateway_TCPIP").value);
   }
   if (document.getElementById("AutomaticMetric_TCPIP").checked)
   {
      DefaultGatewaysGrid.cells(dgpos, 1).setValue(getText(lblAutomatic));
   }
   else
   {
      DefaultGatewaysGrid.cells(dgpos, 1).setValue(document.getElementById("Metric_TCPIP").value);
   }

   if (dgpos == 0)
   {
      document.getElementById("DefaultGateway").value = document.getElementById("Gateway_TCPIP").value;
   }

   HideTCPIPGatewayAddress();

   NetworkUpdated();
}

function HandleDefaultGateway_Delete()
{
   position = "networkwizard.js";
   whatfunc = "HandleDefaultGateway_Delete()";

   NetworkOptions.Users[cpos].DefaultGateways.splice(dgpos, 1);

   PopulateDefaultGatewaysGrid();
   CopyUser(cpos);
   DefaultGatewaysAddEditDeleteState();

   document.getElementById("DefaultGateway").value = DefaultGatewaysGrid.cells(DefaultGatewaysGrid.getRowId(dgpos), 0).getValue();

   NetworkUpdated();
}

function ShowTCPIPGatewayAddress(mode)
{
   position = "networkwizard.js";
   whatfunc = "ShowTCPIPGatewayAddress()";

   AddEdit = mode;

   dhxWins.window("NetworkWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 400, 125);
   SubWizardWindow.setText(getText(lblTCPIPGatewayAddress));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\networkwizardtemplate_addeditgatewayaddress.htm", "layersubwizard");

   document.getElementById("legGateway_TCPIP").innerHTML = getText(lblGateway);
   document.getElementById("lblGateway_TCPIP").innerHTML = getText(lblGateway);
   document.getElementById("lblAutomaticMetric_TCPIP").innerHTML = getText(lblAutomaticMetric) + "&nbsp;&nbsp;";
   document.getElementById("lblMetric_TCPIP").innerHTML = getText(lblMetric);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);

   if (mode == 0)
   {
      document.getElementById("Gateway_TCPIP").value = "";
      document.getElementById("AutomaticMetric_TCPIP").checked = true;
      document.getElementById("Metric_TCPIP").value = "";
      document.getElementById("Metric_TCPIP").disabled = true;
   }
   if (mode == 1)
   {
      document.getElementById("Gateway_TCPIP").value = DefaultGatewaysGrid.cells(DefaultGatewaysGrid.getRowId(dgpos), 0).getValue();
      document.getElementById("AutomaticMetric_TCPIP").checked = DefaultGatewaysGrid.cells(DefaultGatewaysGrid.getRowId(dgpos), 1).getValue() == getText(lblAutomatic) ? true : false;
      if (document.getElementById("AutomaticMetric_TCPIP").checked)
      {
         document.getElementById("Metric_TCPIP").value = ""
         document.getElementById("Metric_TCPIP").disabled = true;
      }
      else
      {
         document.getElementById("Metric_TCPIP").value = DefaultGatewaysGrid.cells(DefaultGatewaysGrid.getRowId(dgpos), 1).getValue();
         document.getElementById("Metric_TCPIP").disabled = false;
      }
   }

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   AutoSizeWindow(SubWizardWindow, "layersubwizard");

   document.getElementById("Gateway_TCPIP").focus();
   moveCaretToEnd(this.document.all.Gateway_TCPIP);
}

function HandleAutomaticMetric_TCPIP()
{
   position = "networkwizard.js";
   whatfunc = "HandleAutomaticMetric_TCPIP()";

   if (document.getElementById("AutomaticMetric_TCPIP").checked)
   {
      document.getElementById("Metric_TCPIP").value = ""
      document.getElementById("Metric_TCPIP").disabled = true;
   }
   else
   {
      document.getElementById("Metric_TCPIP").value = "";
      document.getElementById("Metric_TCPIP").disabled = false;
   }
}

function HideTCPIPGatewayAddress()
{
   position = "networkwizard.js";
   whatfunc = "HideTCPIPGatewayAddress()";

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = NetworkWindow.getText();
   dhxWins.window("NetworkWindow").setModal(true);
}

function HandleAutomaticMetric()
{
   position = "networkwizard.js";
   whatfunc = "HandleAutomaticMetric()";

   if (document.getElementById("AutomaticMetric").checked)
   {
      document.getElementById("InterfaceMetric").value = "";
      document.getElementById("InterfaceMetric").disabled = true;
   }
   else
   {
      document.getElementById("InterfaceMetric").value = "";
      document.getElementById("InterfaceMetric").disabled = false;
      document.getElementById("InterfaceMetric").focus();
   }
}

function HandleInterfaceMetric()
{
   position = "networkwizard.js";
   whatfunc = "HandleInterfaceMetric()";

}

function ClearDNSTab()
{
   position = "networkwizard.js";
   whatfunc = "ClearDNSTab()";

   DNSServersGrid.clearAll();
   document.getElementById("Btn_DNSServers_Add").disabled = true;
   document.getElementById("Btn_DNSServers_Edit").disabled = true;
   document.getElementById("Btn_DNSServers_Delete").disabled = true;
}

function FillInDNSTab(pos)
{
   position = "networkwizard.js";
   whatfunc = "FillInDNSTab()";

   PopulateDNSServersGrid();
   DNSServersAddEditDeleteState();
}

function PopulateDNSServersGrid()
{
   position = "networkwizard.js";
   whatfunc = "PopulateDNSServersGrid()";

   DNSServersGrid.clearAll();

   if (NetworkOptions.Users[cpos].ObtainDNS == "Automatically")
   {
      DNSServersGrid.addRow(0, [getText(lblDHCPEnabled), ""]);
   }
   else
   {
      for (var i = 0; i < NetworkOptions.Users[cpos].DNSServers.length;
      i ++ )
      {
         DNSServersGrid.addRow(i, [NetworkOptions.Users[cpos].DNSServers[i].IP]);
      }

      DNSServersGrid.selectRow(0, false, false, true);
   }

   dnspos = 0;
}

function DNSServersAddEditDeleteState()
{
   position = "networkwizard.js";
   whatfunc = "DNSServersAddEditDeleteState()";

   if (NetworkOptions.Users[cpos].DNSServers.length == 0)
   {
      document.getElementById("Btn_DNSServers_Edit").disabled = true;
      document.getElementById("Btn_DNSServers_Delete").disabled = true;
   }
   else
   {
      document.getElementById("Btn_DNSServers_Edit").disabled = false;
      document.getElementById("Btn_DNSServers_Delete").disabled = false;
   }
   if (NetworkOptions.Users[cpos].ObtainDNS == "Automatically")
   {
      document.getElementById("Btn_DNSServers_Add").disabled = true;
      document.getElementById("Btn_DNSServers_Edit").disabled = true;
      document.getElementById("Btn_DNSServers_Delete").disabled = true;
   }
   else
   document.getElementById("Btn_DNSServers_Add").disabled = false;
}

function HandlePickDNSServer(pos)
{
   position = "networkwizard.js";
   whatfunc = "HandlePickDNSServer()";

   dnspos = pos;
}

function HandleDropDNSServer()
{
   position = "networkwizard.js";
   whatfunc = "HandleDropDNSServer()";

   NetworkOptions.Users[cpos].DNSServers.splice(0, NetworkOptions.Users[cpos].DNSServers.length);
   for (i = 0; i < DNSServersGrid.getRowsNum(); i ++ )
   {
      var AddDNS = new NewDNSServer();
      NetworkOptions.Users[cpos].DNSServers.splice(NetworkOptions.Users[cpos].DNSServers.length, 0, AddDNS);
      NetworkOptions.Users[cpos].DNSServers[i].IP = DNSServersGrid.cells(DNSServersGrid.getRowId(i), 0).getValue();
   }

   NetworkOptions.Users[cpos].PreferredDNS = DNSServersGrid.cells(DNSServersGrid.getRowId(0), 0).getValue();
   NetworkOptions.Users[cpos].AlternateDNS = DNSServersGrid.cells(DNSServersGrid.getRowId(1), 0).getValue();

   FillInGeneralTab(cpos);
}

function HandleDNSServer_AddEdit(mode)
{
   position = "networkwizard.js";
   whatfunc = "HandleDNSServer_AddEdit()";

   if (mode == 0)
   {
      DNSServersGrid.addRow(DNSServersGrid.getRowsNum(), [document.getElementById("DNSServer_TCPIP").value]);
      dnspos = DNSServersGrid.getRowsNum() - 1;
      DNSServersGrid.selectRow(dnspos, false, false, true);
      CopyUser(cpos);
      DNSServersAddEditDeleteState();
   }
   if (mode == 1)
   {
      DNSServersGrid.cells(dnspos, 0).setValue(document.getElementById("DNSServer_TCPIP").value);
   }

   if (dnspos == 0)
   {
      document.getElementById("DNSServer").value = document.getElementById("DNSServer_TCPIP").value;
   }

   HideTCPIPDNSServer();

   NetworkUpdated();
}

function HandleDNSServer_Delete()
{
   position = "networkwizard.js";
   whatfunc = "HandleDNSServer_Delete()";

   NetworkOptions.Users[cpos].DNSServers.splice(dnspos, 1);

   PopulateDNSServersGrid();
   CopyUser(cpos);
   DNSServersAddEditDeleteState();

   document.getElementById("PreferredDNS").value = "";
   document.getElementById("AlternateDNS").value = "";
   if (NetworkOptions.Users[cpos].DNSServers.length > 0)
   document.getElementById("PreferredDNS").value = DNSServersGrid.cells(DNSServersGrid.getRowId(dnspos), 0).getValue();
   if (NetworkOptions.Users[cpos].DNSServers.length > 1)
   document.getElementById("AlternateDNS").value = DNSServersGrid.cells(DNSServersGrid.getRowId(dnspos + 1), 0).getValue();

   NetworkUpdated();
}

function ShowTCPIPDNSServer(mode)
{
   position = "networkwizard.js";
   whatfunc = "ShowTCPIPDNSServer()";

   AddEdit = mode;

   dhxWins.window("NetworkWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 400, 125);
   SubWizardWindow.setText(getText(lblTCPIPDNSServer));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\networkwizardtemplate_addeditdnsserver.htm", "layersubwizard");

   document.getElementById("legDNSServer_TCPIP").innerHTML = getText(lblDNSServer);
   document.getElementById("lblDNSServer_TCPIP").innerHTML = getText(lblDNSServer);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);

   if (mode == 0)
   {
      document.getElementById("DNSServer_TCPIP").value = "";
   }
   if (mode == 1)
   {
      document.getElementById("DNSServer_TCPIP").value = DNSServersGrid.cells(DNSServersGrid.getRowId(dnspos), 0).getValue();
   }

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   AutoSizeWindow(SubWizardWindow, "layersubwizard");

   document.getElementById("DNSServer_TCPIP").focus();
   moveCaretToEnd(this.document.all.DNSServer_TCPIP);
}

function HandleDNSServer_TCPIP()
{
   position = "networkwizard.js";
   whatfunc = "HandleDNSServer_TCPIP()";

}

function HideTCPIPDNSServer()
{
   position = "networkwizard.js";
   whatfunc = "HideTCPIPDNSServer()";

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = NetworkWindow.getText();
   dhxWins.window("NetworkWindow").setModal(true);
}

function ClearWINSTab()
{
   position = "networkwizard.js";
   whatfunc = "ClearWINSTab()";

   WINSServersGrid.clearAll();
   document.getElementById("Btn_WINSServers_Edit").disabled = true;
   document.getElementById("Btn_WINSServers_Delete").disabled = true;
}

function FillInWINSTab(pos)
{
   position = "networkwizard.js";
   whatfunc = "FillInWINSTab()";

   PopulateWINSServersGrid();
   WINSServersAddEditDeleteState();
}

function PopulateWINSServersGrid()
{
   position = "networkwizard.js";
   whatfunc = "PopulateWINSServersGrid()";

   WINSServersGrid.clearAll();

   for (var i = 0; i < NetworkOptions.Users[cpos].WINSServers.length;
   i ++ )
   {
      WINSServersGrid.addRow(i, [NetworkOptions.Users[cpos].WINSServers[i].IP]);
   }

   WINSServersGrid.selectRow(0, false, false, true);

   winspos = 0;
}

function WINSServersAddEditDeleteState()
{
   position = "networkwizard.js";
   whatfunc = "WINSServersAddEditDeleteState()";

   if (NetworkOptions.Users[cpos].WINSServers.length == 0)
   {
      document.getElementById("Btn_WINSServers_Edit").disabled = true;
      document.getElementById("Btn_WINSServers_Delete").disabled = true;
   }
   else
   {
      document.getElementById("Btn_WINSServers_Edit").disabled = false;
      document.getElementById("Btn_WINSServers_Delete").disabled = false;
   }
}

function HandlePickWINSServer(pos)
{
   position = "networkwizard.js";
   whatfunc = "HandlePickWINSServer()";

   winspos = pos;
}

function HandleWINSServer_AddEdit(mode)
{
   position = "networkwizard.js";
   whatfunc = "HandleWINSServer_AddEdit()";

   if (mode == 0)
   {
      WINSServersGrid.addRow(WINSServersGrid.getRowsNum(), [document.getElementById("WINSServer_TCPIP").value]);
      winspos = WINSServersGrid.getRowsNum() - 1;
      WINSServersGrid.selectRow(winspos, false, false, true);
      CopyUser(cpos);
      WINSServersAddEditDeleteState();
   }
   if (mode == 1)
   {
      WINSServersGrid.cells(winspos, 0).setValue(document.getElementById("WINSServer_TCPIP").value);
   }

   HideTCPIPWINSServer();

   NetworkUpdated();
}

function HandleWINSServer_Delete()
{
   position = "networkwizard.js";
   whatfunc = "HandleWINSServer_Delete()";

   NetworkOptions.Users[cpos].WINSServers.splice(winspos, 1);

   PopulateWINSServersGrid();
   CopyUser(cpos);
   WINSServersAddEditDeleteState();

   NetworkUpdated();
}

function ShowTCPIPWINSServer(mode)
{
   position = "networkwizard.js";
   whatfunc = "ShowTCPIPWINSServer()";

   AddEdit = mode;

   dhxWins.window("NetworkWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 400, 125);
   SubWizardWindow.setText(getText(lblTCPIPWINSServer));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\networkwizardtemplate_addeditwinsserver.htm", "layersubwizard");

   document.getElementById("legWINSServer_TCPIP").innerHTML = getText(lblWINSServer);
   document.getElementById("lblWINSServer_TCPIP").innerHTML = getText(lblWINSServer);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);

   if (mode == 0)
   {
      document.getElementById("WINSServer_TCPIP").value = "";
   }
   if (mode == 1)
   {
      document.getElementById("WINSServer_TCPIP").value = WINSServersGrid.cells(WINSServersGrid.getRowId(winspos), 0).getValue();
   }

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   AutoSizeWindow(SubWizardWindow, "layersubwizard");

   document.getElementById("WINSServer_TCPIP").focus();
   moveCaretToEnd(this.document.all.WINSServer_TCPIP);
}

function HandleWINSServer_TCPIP()
{
   position = "networkwizard.js";
   whatfunc = "HandleWINSServer_TCPIP()";

}

function HideTCPIPWINSServer()
{
   position = "networkwizard.js";
   whatfunc = "HideTCPIPWINSServer()";

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = NetworkWindow.getText();
   dhxWins.window("NetworkWindow").setModal(true);
}

function FillInNetworkFile()
{
   position = "optionswizard.js";
   whatfunc = "FillInNetworkFile()";

   StatusBar.setText(networkFile);
}

function NewNetworkOptions()
{
   position = "networkwizard.js";
   whatfunc = "NewNetworkOptions()";

   var temp;

   if ( ! isNetworkSaved)
   {
      if ( ! Alert("", getText(txtDiscardChangesContinue), getText(lblOK) + "|" + getText(lblCancel), "", 5, 0, 0, 0))
      return;
   }

   temp = Alert("", getText(txtSaveNetworkAs), getText(lblOK) + "|" + getText(lblCancel), networkFile, 6, 0, 125, 0);
   if (temp != null)
   {
      if (FileExists(temp))
      {
         if ( ! Alert("", temp + "\n\n" + getText(txtFileExistsReplace), getText(lblOK) + "|" + getText(lblCancel), "", 5, 0, 0, 0))
         return;
      }
      networkFile = temp;

      NetworkOptions =
      {
         "OpenPickUser" : false, "Users" : []
      }
      ;

      cpos = 0;
      CheckForDefaultUser();
      PopulateUsersGrid();
      ClearAllTabs();
      FillInAllTabs(cpos);

      SetNetworkPath(true);

      SaveNetworkOptions(false);
   }
}

function networkClearReadBrowse()
{
   position = "networkwizard.js";
   whatfunc = "networkClearReadBrowse()";

   document.getElementById("div_networkReadBrowse").innerHTML = "";
   document.getElementById("div_networkReadBrowse").innerHTML = '<input id="networkReadBrowse" type="file" style="display:none;">';
}

function HandleReadNetworkOptions()
{
   position = "networkwizard.js";
   whatfunc = "HandleReadNetworkOptions()";

   if ( ! isNetworkSaved)
   {
      if ( ! Alert("", getText(txtDiscardChangesContinue), getText(lblOK) + "|" + getText(lblCancel), "", 5, 0, 0, 0))
      return;
   }

   networkClearReadBrowse();
   document.all.networkReadBrowse.click();

   if (document.getElementById("networkReadBrowse").value != "")
   {
      isNetworkSaved = true;
      SetNetworkPath(false);
      ReadNetworkOptions();
   }
}

function SetNetworkPath(mode)
{
   position = "networkwizard.js";
   whatfunc = "SetNetworkPath()";

   var i, txt;

   if ( ! mode)
   {
      networkFile = document.getElementById("networkReadBrowse").value;
   }
   else
   {
   }

   FillInNetworkFile();
}


function GetNetworkPath()
{
   position = "networkwizard.js";
   whatfunc = "GetNetworkPath()";

   var temp;
   temp = Alert("", getText(txtSaveNetworkAs), getText(lblOK) + "|" + getText(lblCancel), configFile, 6, 0, 125, 0);
   if (temp != null)
   {
      networkFile = temp;
      SetNetworkPath(true);
      SaveNetworkOptions(false);
   }
}

function GetNetworkVersion()
{
   position = "networkwizard.js";
   whatfunc = "GetNetworkVersion()";

   var line = new String();
   var num = 1, ver = - 1;

   strFile = networkFile;
   if (FileExists(strFile))
   {
      try
      {
         tf = fso.OpenTextFile(strFile, 1, 0, - 2);
         while ( ! tf.AtEndOfStream && num < 2)
         {
            line = tf.ReadLine();
            if (line.indexOf("// WPI Network Options ") != - 1)
            {
               line = line.replace(/[^0-9]/g, '');
               ver = Number(line);
            }
            else
            ver = 0;
            num ++ ;
         }
      }
      catch(ex)
      {
         ;

      }
      finally
      {
         try
         {
            tf.Close();
         }
         catch (ex0)
         {
            ;

         }
      }
   }

   return ver;
}

function ReadNetworkOptions()
{
   position = "networkwizard.js";
   whatfunc = "ReadNetworkOptions()";

   var line = new String();

   WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\NetworkFile", networkFile, "REG_SZ");

   strFile = networkFile;
   if (FileExists(strFile))
   {
      try
      {
         tf = fso.OpenTextFile(strFile, 1, 0, - 2);
         for (i = 0; i < 7; i ++ )
         {
            // Skip header
            tf.ReadLine();
         }
         while ( ! tf.AtEndOfStream)
         {
            line = tf.ReadAll();
         }
      }
      catch(ex)
      {
         ;

      }
      finally
      {
         try
         {
            tf.Close();
         }
         catch (ex0)
         {
            ;

         }
      }

      line = line.replace("};", "}");
      // Very last };

      NetworkOptions =
      {
      }
      ;
      NetworkOptions = json_parse(line);

      for (var i = 0; i < NetworkOptions.Users.length;
      i ++ )
      NetworkOptions.Users[i].UserPassword = decode64(NetworkOptions.Users[i].UserPassword);

      cpos = 0;
      CheckForDefaultUser();
      PopulateUsersGrid();
      ClearAllTabs();
      FillInAllTabs(cpos);

      FillInNetworkFile();
   }
   else
   {
      alert(getText(errCouldNotOpenFile) + " '"+strFile+"'.\n\n" + getText(errUsingDefaultSet));
   }
}

function SaveDefaultNetworkOptions()
{
   position = "optionswizard.js";
   whatfunc = "SaveDefaultNetworkOptions()";

   NetworkOptions =
   {
      "OpenPickUser" : false, "Users" : []
   }
   ;

   cpos = 0;
   CheckForDefaultUser();

   SaveNetworkOptions(true);
}

function SaveNetworkOptions(defaults)
{
   position = "networkwizard.js";
   whatfunc = "SaveNetworkOptions()";

   var txt = new String();

   if (fromCDDrive)
   {
      Alert("", getText(txtCanNotSaveToCD), getText(lblOK), "", 2, 0, 0, 0);

      return;
   }

   if ( ! defaults)
   CopyUser(cpos);

   strFile = networkFile;
   try
   {
      if ( ! defaults)
      Alert("", "<center>" + getText(txtSavingNetworkFile), "---none---", "", 1, - 1, 0, - 80);

      tf = fso.CreateTextFile(strFile, true, true);
      tf.WriteLine("// WPI Network Options 8.1.0");
      tf.WriteLine("//");
      tf.WriteLine("// User defined options");
      tf.WriteLine("//");
      tf.WriteLine("");
      tf.WriteLine("");
      for (var i = 0; i < NetworkOptions.Users.length;
      i ++ )
      NetworkOptions.Users[i].UserPassword = encode64(NetworkOptions.Users[i].UserPassword);
      txt = JSON.stringify(NetworkOptions, null, '\t');
      txt = "NetworkOptions=\r\n" + txt;
      txt += ";\n";
      tf.WriteLine(txt);

      isNetworkSaved = true;
   }
   catch(ex)
   {
      alert(getText(errCouldNotSaveFile) + "\n\n" + getText(lblFile) + ": " + strFile + "\n" + getText(lblErrorNumber) + ": " + (ex.number & 0xffff) + "\n" + getText(lblErrorDescription) + ": " + ex.description);
   }
   finally
   {
      try
      {
         tf.Close();
      }
      catch (ex0)
      {
         ;

      }

      if ( ! defaults)
      {
         Pause(1, 0);
         CloseAlert(0);
      }
   }
}

function ShowNetwork()
{
   position = "networkwizard.js";
   whatfunc = "ShowNetwork()";

   stopInterval();

   ManualSection = "Network";

   CreateNetworkPage();
   NetworkWizardOpen = true;
}

function HideNetwork(reload)
{
   position = "networkwizard.js";
   whatfunc = "HideNetwork()";

   if (dhxWins.isWindow("NetworkWindow"))
   {
      NetworkWindow.close();
      NetworkWindow = null;

      NetworkWizardOpen = false;
   }

   if (reload)
   RefreshWPI();
}

function ToggleNetwork()
{
   position = "networkwizard.js";
   whatfunc = "ToggleNetwork()";

   if (ReadMeWindow != null || AboutWindow != null)
   return;
   if (OptionsWizardOpen || ConfigWizardOpen)
   {
      Alert("", getText(txtCanNotSwitchWizards), getText(lblOK), "", 3, 0, 0, 0);
      return;
   }

   if ( ! dhxWins.isWindow("NetworkWindow"))
   {
      isNetworkSaved = true;
      ShowNetwork();
   }
   else
   {
      if (isNetworkSaved)
      HideNetwork(false);
      else
      {
         if (Alert("", getText(txtDiscardChanges), getText(lblOK) + "|" + getText(lblCancel), "", 5, 0, 0, 0))
         {
            isNetworkSaved = true;
            HideNetwork(false);
         }
      }
   }
}

function CreatePickUserPage()
{
   position = "networkwizard.js";
   whatfunc = "CreatePickUserPage()";

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 500, 300);
   SubWizardWindow.setText(getText(lblNetworkWizard));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.visibility = 'hidden';

   CreateTab("\\Common\\networkwizardtemplate_pickuser.htm", "layersubwizard");

   LocalizePickUserTexts();

   UsersGrid = new dhtmlXGridObject('UsersGrid');
   UsersGrid.setImagePath("../common/codebase/imgs/");
   UsersGrid.setSkin(dhxSkin);
   UsersGrid.setHeader(getText(GridFriendlyName) + ',' + getText(GridComputerName) + ',' + getText(GridUserName));
   UsersGrid.setInitWidths("*,125,125");
   UsersGrid.setColAlign("left,left,left");
   UsersGrid.setColTypes("ro,ro,ro");
   UsersGrid.setColSorting("str,str,str");
   UsersGrid.enableMultiselect(false);
   UsersGrid.enableMultiline(false);
   UsersGrid.enableKeyboardSupport(true);
   UsersGrid.attachEvent("onRowSelect", JumpToPickUser);
   UsersGrid.init();
   UsersGrid.objBox.style.overflowX = "hidden";

   PopulateUsersGrid();
   UserPos = 0;

   document.getElementById("layersubwizard").style.visibility = 'visible';
   document.getElementById("layersubwizard").style.display = 'block';
}

function LocalizePickUserTexts()
{
   position = "networkwizard.js";
   whatfunc = "LocalizePickUserTexts()";

   document.getElementById("txtPickNetworkUser").innerHTML = getText(txtPickNetworkUser);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);
}

function JumpToPickUser(pos)
{
   position = "networkwizard.js";
   whatfunc = "JumpToPickUser()";

   UserPos = pos;
}

function HandlePickUser(btn)
{
   position = "networkwizard.js";
   whatfunc = "HandlePickUser()";

   if (btn)
   {
   }
   else
   {
      UserPos = - 1;
   }

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   checkInstall2();
}
