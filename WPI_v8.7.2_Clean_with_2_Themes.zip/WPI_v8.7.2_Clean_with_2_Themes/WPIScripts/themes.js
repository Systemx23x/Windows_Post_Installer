//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// themes.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

function GetThemes(Combo)
{
   position = "themes.js";
   whatfunc = "GetThemes()";

   var f, fc, s;

   f = fso.GetFolder(wpipath + "\\Themes\\");
   fc = new Enumerator(f.SubFolders);
   s = new String();
   for (; ! fc.atEnd(); fc.moveNext())
   {
      s = "";
      s += fc.item();
      s = s.substr(s.lastIndexOf("\\") + 1);
      if ( ! AtStartUp)
      {
         var opt = document.createElement("option");

         opt.value = s;
         opt.text = s;
         document.getElementById(Combo).options.add(opt);
      }
   }
}

function GetSkins(Combo)
{
   position = "themes.js";
   whatfunc = "GetSkins()";

   var f, fc, s;
   try
   {
      f = fso.GetFolder(wpipath + "\\Common\\Skins\\");
      fc = new Enumerator(f.SubFolders);
      s = new String();
      for (; ! fc.atEnd(); fc.moveNext())
      {
         s = "";
         s += fc.item();
         s = s.substr(s.lastIndexOf("\\") + 1);

         var opt = document.createElement("option");

         opt.value = s;
         opt.text = s;
         document.getElementById(Combo).options.add(opt);
      }
   }
   catch (ex)
   {
      ;

   }

}

function GetInstallBgs(Combo)
{
   position = "themes.js";
   whatfunc = "GetInstallBgs()";

   var f, fc, s;

   try
   {
      f = fso.GetFolder(wpipath + "\\Common\\imgs\\InstallBgs\\");
      fc = new Enumerator(f.Files);
      s = new String();
      for (; ! fc.atEnd(); fc.moveNext())
      {
         s = "";
         s += fc.item();
         s = s.substr(s.lastIndexOf("\\") + 1);
         s = s.replace(/.png/, "");

         Combo._addOption(
         {
            value : s, text : s, img_src : "../Common/imgs/InstallBgs/" + s + ".png"
         }
         );
      }
   }
   catch (ex)
   {
      ;

   }
}

function GetProgressBars(Combo)
{
   position = "themes.js";
   whatfunc = "GetProgressBars()";

   var f, fc, s;

   try
   {
      f = fso.GetFolder(wpipath + "\\Common\\imgs\\ProgressBars\\");
      fc = new Enumerator(f.Files);
      s = new String();
      for (; ! fc.atEnd(); fc.moveNext())
      {
         s = "";
         s += fc.item();
         s = s.substr(s.lastIndexOf("\\") + 1);
         s = s.replace(/.png/, "");

         Combo._addOption(
         {
            value : s, text : s, img_src : "../Common/imgs/ProgressBars/" + s + ".png"
         }
         );
      }
   }
   catch (ex)
   {
      ;

   }
}

function GetFonts(Combo)
{
   position = "themes.js";
   whatfunc = "GetFonts()";

   var s;

   try
   {
      var rgFonts = new Array();

      for (var i = 1; i <= dlgHelper.fonts.count; i ++ )
      {
         rgFonts[i - 1] = dlgHelper.fonts(i);
      }
      rgFonts.sort();

      s = new String();
      for (var i = 0; i < rgFonts.length; i ++ )
      {
         s = "";
         s += rgFonts[i];

         var opt = document.createElement("option");

         opt.value = s;
         opt.text = s;
         document.getElementById(Combo).options.add(opt);
      }
   }
   catch (ex)
   {
      ;

   }
}

function CheckThemeType()
{
   position = "themes.js";
   whatfunc = "CheckThemeType()";

   var line = new String();
   var num = 1, success = true;

   if ( ! FileExists(wpipath + "\\Themes\\" + Theme + "\\wpi.inf"))
   {
      alert("'"+Theme+"' wpi.inf does not exist.\n\nSwitching to " + DefaultTheme + ", the default theme.");
      Theme = DefaultTheme;
      ThemeType = DefaultType;

      return false;
   }

   try
   {
      tf = fso.OpenTextFile(wpipath + "\\Themes\\" + Theme + "\\wpi.inf", 1, 0, - 2);
      while ( ! tf.AtEndOfStream && num < 3)
      {
         line = tf.ReadLine();
         if (num == 2)
         {
            ThemeType = line;
            success = true;
            break;
         }
         num ++ ;
      }
   }
   catch(ex)
   {
      ;

   }
   finally
   {
      try
      {
         tf.Close();
      }
      catch (ex0)
      {
         ;

      }
   }

   return success;
}

function CheckThemeVersion()
{
   position = "themes.js";
   whatfunc = "CheckThemeVersion()";

   return true;

}

function CheckThemeIEVersion()
{
   position = "themes.js";
   whatfunc = "CheckThemeIEVersion()";

   return true;
}

function InstallThemeFonts()
{
   position = "themes.js";
   whatfunc = "InstallThemeFonts()";
       
   return true;

}

function LoadThemedContent()
{
   position = "themes.js";
   whatfunc = "LoadThemedContent()";

   var line = new String();

   if ( ! CheckThemeType())
   {
      if ( ! CheckThemeType())
      return false;
   }

   if ( ! CheckThemeVersion())
   {
      if (AtStartUp)
      {
         if ( ! CheckThemeVersion())
         {
            if (AtStartUp)
            {
               alert("The '"+DefaultTheme+"' theme could not be loaded. Please re-install the theme.");

               return false;
            }
         }
      }
      else
      return false;
   }

   if ( ! CheckThemeIEVersion())
   {
      if (AtStartUp)
      {
         if ( ! CheckThemeIEVersion())
         {
            if (AtStartUp)
            {
               alert("The '"+DefaultTheme+"' theme could not be loaded. Please re-install the theme.");

               return false;
            }
         }
      }
      else
      return false;
   }

   InstallThemeFonts();

   try
   {
      tf = fso.OpenTextFile(wpipath + "\\Common\\Themes\\" + ThemeType + "\\wpi.htm", 1, 0, - 2);
      while ( ! tf.AtEndOfStream)
      {
         line = tf.ReadAll();
         document.write(line);
      }
   }
   catch(ex)
   {
      alert("LoadThemedContent() error:" + ex.message);
   }
   finally
   {
      try
      {
         tf.Close();
      }
      catch (ex0)
      {
         ;

      }
   }

   SetupTips(Style[0]);

   return true;
}

function HandleSelectMultiDefaults()
{
 position="themes.js";
 whatfunc="HandleSelectMultiDefaults()";

   var optG, opt;

   if ( ! isCorporate && ! isAccordion)
   {
      optG = document.createElement("optgroup");
      optG.label = "WPI";
      document.getElementById("selectConfig").appendChild(optG);
      opt = document.createElement("option");
      opt.value = "default";
      opt.text = getText(lblSelectDefaults);
      if (CheckOnLoad == "default")
      opt.selected = true;
      document.getElementById("selectConfig").options.add(opt);

      opt = document.createElement("option");
      opt.value = "all";
      opt.text = getText(lblSelectAll);
      if (CheckOnLoad == "all")
      opt.selected = true;
      document.getElementById("selectConfig").options.add(opt);

      opt = document.createElement("option");
      opt.value = "none";
      opt.text = getText(lblSelectNone);
      if (CheckOnLoad == "none")
      opt.selected = true;
      document.getElementById("selectConfig").options.add(opt);

      optG = document.createElement("optgroup");
      optG.label = getText(lblConfigurations);
      document.getElementById("selectConfig").appendChild(optG);
      if (Configurations.length > 0 && Configurations[0] != "")
      {
         for (var i = 0; i < Configurations.length; i ++ )
         {
            opt = document.createElement("option");

            opt.value = Configurations[i];
            opt.text = noTags(Configurations[i]);
            if (CheckOnLoad == Configurations[i])
            opt.selected = true;
            document.getElementById("selectConfig").options.add(opt);
         }
      }

      if (ShowMultiDefault)
      {
         document.getElementById("divMultiDefault").style.visibility = "visible";
         document.getElementById("divSelectButtons").style.display = "none";
      }
      else
      {
         document.getElementById("divSelectButtons").style.visibility = "visible";
         document.getElementById("divMultiDefault").style.display = "none";
      }
   }
}

function HandleShowExtraButtons()
{
   position = "themes.js";
   whatfunc = "HandleShowExtraButtons()";

   if (isCorporate)
   return;

   if (iseuDock)
   return;

   if (ShowExtraButtons)
   {
      if (DoNotShowIfCD && fromCDDrive)
      return;
      if (DoNotShowIfUSB && fromUSBDrive)
      return;

      document.getElementById("ExtraButtons").style.display = "block";
   }
}

function SetThemeImage(id, image)
{
   position = "themes.js";
   whatfunc = "SetThemeImage()";

   if (ThemeType == "Accordion" || ThemeType == "euDock")
   {
      if (FileExists(wpipath + "//Themes//" + Theme + "//" + image))
      document.getElementById(id).src = "../Themes/" + Theme + "/" + image;
      else
      document.getElementById(id).src = "../Common/imgs/spacer.gif";

      return;
   }

   switch (id)
   {
      case "readmebutton" :
         if (FileExists(wpipath + "//Themes//" + Theme + "//" + image))
         {
            document.getElementById(id).src = "../Themes/" + Theme + "/" + image;
         }
         else
         {
            document.getElementById("readmespacer").style.width = "2px";
            document.getElementById(id).src = "../Common/imgs/spacer.gif";
            isReadMeImage = false;
         }
         break;

      case "installbutton" :
         if (FileExists(wpipath + "//Themes//" + Theme + "//" + image))
         {
            document.getElementById(id).src = "../Themes/" + Theme + "/" + image;
         }
         else
         {
            document.getElementById("installspacer").style.width = "2px";
            document.getElementById(id).src = "../Common/imgs/spacer.gif";
            isInstallImage = false;
         }
         break;

      case "defaultsbutton" :
         if (FileExists(wpipath + "//Themes//" + Theme + "//" + image))
         {
            document.getElementById(id).src = "../Themes/" + Theme + "/" + image;
         }
         else
         {
         document.getElementById("defaultsspacer").style.width = "2px";
            document.getElementById(id).src = "../Common/imgs/spacer.gif";
            isCheckImage = false;
         }
         break;

      case "allbutton" :
         if (FileExists(wpipath + "//Themes//" + Theme + "//" + image))
         {
            document.getElementById(id).src = "../Themes/" + Theme + "/" + image;
         }
         else
         {
            document.getElementById("allspacer").style.width = "2px";
            document.getElementById(id).src = "../Common/imgs/spacer.gif";
            isCheckImage = false;
         }
         break;

      case "nonebutton" :
         if (FileExists(wpipath + "//Themes//" + Theme + "//" + image))
         {
            document.getElementById(id).src = "../Themes/" + Theme + "/" + image;
         }
         else
         {
            document.getElementById("nonespacer").style.width = "2px";
            document.getElementById(id).src = "../Common/imgs/spacer.gif";
            isCheckImage = false;
         }
         break;

      case "optionsbutton" :
         if (FileExists(wpipath + "//Themes//" + Theme + "//" + image))
         {
            document.getElementById(id).src = "../Themes/" + Theme + "/" + image;
         }
         else
         {
            document.getElementById("optionsspacer").style.width = "2px";
            document.getElementById(id).src = "../Common/imgs/spacer.gif";
            isOptionsImage = false;
         }
         break;

      case "configbutton" :
         if (FileExists(wpipath + "//Themes//" + Theme + "//" + image))
         {
            document.getElementById(id).src = "../Themes/" + Theme + "/" + image;
         }
         else
         {
            document.getElementById("configspacer").style.width = "2px";
            document.getElementById(id).src = "../Common/imgs/spacer.gif";
            isConfigImage = false;
         }
         break;

      case "networkbutton" :
         if (FileExists(wpipath + "//Themes//" + Theme + "//" + image))
         {
            document.getElementById(id).src = "../Themes/" + Theme + "/" + image;
         }
         else
         {
            document.getElementById("networkspacer").style.width = "2px";
            document.getElementById(id).src = "../Common/imgs/spacer.gif";
            isNetworkImage = false;
         }
         break;

      case "themebutton" :
         if (FileExists(wpipath + "//Themes//" + Theme + "//" + image))
         {
            document.getElementById(id).src = "../Themes/" + Theme + "/" + image;
         }
         else
         {
            document.getElementById("themespacer").style.width = "2px";
            document.getElementById(id).src = "../Common/imgs/spacer.gif";
            isThemeImage = false;
         }
         break;

      case "informationbutton" :
         if (FileExists(wpipath + "//Themes//" + Theme + "//" + image))
         {
            document.getElementById(id).src = "../Themes/" + Theme + "/" + image;
         }
         else
         {
            document.getElementById("informationspacer").style.width = "2px";
            document.getElementById(id).src = "../Common/imgs/spacer.gif";
            isInformationImage = false;
         }
         break;

      case "manualbutton" :
         if (FileExists(wpipath + "//Themes//" + Theme + "//" + image))
         {
            document.getElementById(id).src = "../Themes/" + Theme + "/" + image;
         }
         else
         {
            document.getElementById("manualspacer").style.width = "2px";
            document.getElementById(id).src = "../Common/imgs/spacer.gif";
            isManualImage = false;
         }
         break;

      case "aboutbutton" :
         if (FileExists(wpipath + "//Themes//" + Theme + "//" + image))
         {
            document.getElementById(id).src = "../Themes/" + Theme + "/" + image;
         }
         else
         {
            document.getElementById("aboutspacer").style.width = "2px";
            document.getElementById(id).src = "../Common/imgs/spacer.gif";
            isAboutImage = false;
         }
         break;

      case "exitbuttonL" :
      if (FileExists(wpipath+"//Themes//"+Theme+"//"+image))
   {
    document.getElementById(id).src="../Themes/"+Theme+"/"+image;
   }
   else
   {
    document.getElementById("exitbuttonLspacer").style.width="2px";
    document.getElementById(id).src="../Common/imgs/spacer.gif";
    isExitImage=false;
   }
   break;
   
      case "exitbuttonR" :
         if (FileExists(wpipath + "//Themes//" + Theme + "//" + image))
         {
            document.getElementById(id).src = "../Themes/" + Theme + "/" + image;
         }
         else
         {
            document.getElementById("exitbuttonRspacer").style.width = "2px";
            document.getElementById(id).src = "../Common/imgs/spacer.gif";
            isExitImage = false;
         }
         break;

      default :
         if (FileExists(wpipath + "//Themes//" + Theme + "//" + image))
         document.getElementById(id).src = "../Themes/" + Theme + "/" + image;
         else
         document.getElementById(id).src = "../Common/imgs/spacer.gif";
         break;
   }
}

function DoMouseOver(id, which)
{
   position = "themes.js";
   whatfunc = "DoMouseOver()";

   switch (which)
   {
      case 0 :
      if (isInstallImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/InstallOver.png";
      break;

      case 1 :
      if (isDefaultsImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/DefaultsOver.png";
      break;

      case 2 :
      if (isAllImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/AllOver.png";
      break;

      case 3 :
      if (isNoneImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/NoneOver.png";
      break;

      case 10 :
      if (isOptionsImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/OptionsOver.png";
      break;

      case 11 :
      if (isConfigImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/ConfigOver.png";
      break;

      case 12 :
      if (isNetworkImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/NetworkOver.png";
      break;

      case 13 :
      if (isThemeImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/ThemeOver.png";
      break;

      case 80 :
      if (isInformationImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/InformationOver.png";
      break;

      case 81 :
      if (isManualImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/ManualOver.png";
      break;

      case 82 :
      if (isReadMeImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/ReadMeOver.png";
      break;

      case 90 :
      if (isAboutImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/AboutWPIOver.png";
      break;

      case 99 :
      if (isExitImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/ExitOver.png";
      break;
   }
}

function DoMouseDown(id, which)
{
   position = "themes.js";
   whatfunc = "DoMouseDown()";

   switch (which)
   {
      case 0 :
      if (isInstallImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/InstallDown.png";
      break;

      case 1 :
      if (isDefaultsImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/DefaultsDown.png";
      break;

      case 2 :
      if (isAllImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/AllDown.png";
      break;

      case 3 :
      if (isNoneImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/NoneDown.png";
      break;

      case 10 :
      if (isOptionsImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/OptionsDown.png";
      break;

      case 11 :
      if (isConfigImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/ConfigDown.png";
      break;

      case 12 :
      if (isNetworkImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/NetworkDown.png";
      break;

      case 13 :
      if (isThemeImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/ThemeDown.png";
      break;

      case 80 :
      if (isInformationImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/InformationDown.png";
      break;

      case 81 :
      if (isManualImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/ManualDown.png";
      break;

      case 82 :
      if (isReadMeImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/ReadMeDown.png";
      break;

      case 90 :
      if (isAboutImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/AboutWPIDown.png";
      break;

      case 99 :
      if (isExitImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/ExitDown.png";
      break;
   }
}

function DoMouseOut(id, which)
{
   position = "themes.js";
   whatfunc = "DoMouseOut()";

   switch (which)
   {
      case 0 :
      if (isInstallImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/Install.png";
      break;

      case 1 :
      if (isDefaultsImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/Defaults.png";
      break;

      case 2 :
      if (isAllImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/All.png";
      break;

      case 3 :
      if (isNoneImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/None.png";
      break;

      case 10 :
      if (isOptionsImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/Options.png";
      break;

      case 11 :
      if (isConfigImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/Config.png";
      break;

      case 12 :
      if (isNetworkImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/Network.png";
      break;

      case 13 :
      if (isThemeImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/Theme.png";
      break;

      case 80 :
      if (isInformationImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/Information.png";
      break;

      case 81 :
      if (isManualImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/Manual.png";
      break;

      case 82 :
      if (isReadMeImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/ReadMe.png";
      break;

      case 90 :
      if (isAboutImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/AboutWPI.png";
      break;

      case 99 :
      if (isExitImage)
      document.getElementById(id).src = "../Themes/" + Theme + "/Exit.png";
      break;
   }
}

function SetUpAudioFiles()
{
   position = "themes.js";
   whatfunc = "SetUpAudioFiles()";

   if (SndWPIStartCB)
   {
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndWPIStartCB", SndWPIStartCB == true ? 1 : 0, "REG_DWORD");
      if (FileExists(wpipath + "\\Themes\\" + Theme + "\\SndWPIStart.wav"))
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndWPIStart", wpipath + "\\Themes\\" + Theme + "\\SndWPIStart.wav", "REG_SZ");
      else if (FileExists(wpipath + "\\Themes\\" + Theme + "\\SndWPIStart.mid"))
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndWPIStart", wpipath + "\\Themes\\" + Theme + "\\SndWPIStart.mid", "REG_SZ");
      else
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndWPIStart", SndWPIStart, "REG_SZ");
   }

   if (SndInstallStartCB)
   {
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallStartCB", SndInstallStartCB == true ? 1 : 0, "REG_DWORD");
      if (FileExists(wpipath + "\\Themes\\" + Theme + "\\SndInstallStart.wav"))
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallStart", wpipath + "\\Themes\\" + Theme + "\\SndInstallStart.wav", "REG_SZ");
      else if (FileExists(wpipath + "\\Themes\\" + Theme + "\\SndInstallStart.mid"))
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallStart", wpipath + "\\Themes\\" + Theme + "\\SndInstallStart.mid", "REG_SZ");
      else
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallStart", SndInstallStart, "REG_SZ");
   }

   if (SndInstallSuccessCB)
   {
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallSuccessCB", SndInstallSuccessCB == true ? 1 : 0, "REG_DWORD");
      if (FileExists(wpipath + "\\Themes\\" + Theme + "\\SndInstallSuccess.wav"))
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallSuccess", wpipath + "\\Themes\\" + Theme + "\\SndInstallSuccess.wav", "REG_SZ");
      else if (FileExists(wpipath + "\\Themes\\" + Theme + "\\SndInstallSuccess.mid"))
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallSuccess", wpipath + "\\Themes\\" + Theme + "\\SndInstallSuccess.mid", "REG_SZ");
      else
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallSuccess", SndInstallSuccess, "REG_SZ");
   }

   if (SndInstallWarningCB)
   {
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallWarningCB", SndInstallWarningCB == true ? 1 : 0, "REG_DWORD");
      if (FileExists(wpipath + "\\Themes\\" + Theme + "\\SndInstallWarning.wav"))
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallWarning", wpipath + "\\Themes\\" + Theme + "\\SndInstallWarning.wav", "REG_SZ");
      else if (FileExists(wpipath + "\\Themes\\" + Theme + "\\SndInstallWarning.mid"))
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallWarning", wpipath + "\\Themes\\" + Theme + "\\SndInstallWarning.mid", "REG_SZ");
      else
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallWarning", SndInstallWarning, "REG_SZ");
   }

   if (SndInstallFailCB)
   {
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallFailCB", SndInstallFailCB == true ? 1 : 0, "REG_DWORD");
      if (FileExists(wpipath + "\\Themes\\" + Theme + "\\SndInstallFail.wav"))
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallFail", wpipath + "\\Themes\\" + Theme + "\\SndInstallFail.wav", "REG_SZ");
      else if (FileExists(wpipath + "\\Themes\\" + Theme + "\\SndInstallFail.mid"))
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallFail", wpipath + "\\Themes\\" + Theme + "\\SndInstallFail.mid", "REG_SZ");
      else
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallFail", SndInstallFail, "REG_SZ");
   }

   if (SndInstallFinishCB)
   {
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallFinishCB", SndInstallFinishCB == true ? 1 : 0, "REG_DWORD");
      if (FileExists(wpipath + "\\Themes\\" + Theme + "\\SndInstallFinish.wav"))
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallFinish", wpipath + "\\Themes\\" + Theme + "\\SndInstallFinish.wav", "REG_SZ");
      else if (FileExists(wpipath + "\\Themes\\" + Theme + "\\SndInstallFinish.mid"))
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallFinish", wpipath + "\\Themes\\" + Theme + "\\SndInstallFinish.mid", "REG_SZ");
      else
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallFinish", SndInstallFinish, "REG_SZ");
   }

   if (SndWPIExitCB)
   {
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndWPIExitCB", SndWPIExitCB == true ? 1 : 0, "REG_DWORD");
      if (FileExists(wpipath + "\\Themes\\" + Theme + "\\SndWPIExit.wav"))
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndWPIExit", wpipath + "\\Themes\\" + Theme + "\\SndWPIExit.wav", "REG_SZ");
      else if (FileExists(wpipath + "\\Themes\\" + Theme + "\\SndWPIExit.mid"))
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndWPIExit", wpipath + "\\Themes\\" + Theme + "\\SndWPIExit.mid", "REG_SZ");
      else
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\SndWPIExit", SndWPIExit, "REG_SZ");
   }
}

function RefreshElement4(id)
{
   position = "themes.js";
   whatfunc = "RefreshElement4()";

   if (document.getElementById("chkbox" + id).disabled || (document.getElementById("lbl" + id).value == "IsGray" && DisableIfDoGray))
   document.getElementById("box" + id).className = "disabledBox";
   else if (document.getElementById("lbl" + id).value == "IsGray" && ! document.getElementById("chkbox" + id).checked && (document.getElementById("lbl" + id).value != "Forced"))
   document.getElementById("box" + id).className = "grayedBox";
   else if (document.getElementById("lbl" + id).value == "Forced")
   document.getElementById("box" + id).className = "forcedBox";
   else if (document.getElementById("chkbox" + id).checked)
   document.getElementById("box" + id).className = "selectedBox";
   else
   document.getElementById("box" + id).className = "normalBox";
}
