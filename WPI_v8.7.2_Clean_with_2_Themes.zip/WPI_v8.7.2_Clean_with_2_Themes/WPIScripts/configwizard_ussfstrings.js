//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// configwizard_ussfstrings.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

var USSFStrings =
{
   "Types" : [
   {
      "Type" : getText(txtUSSFType0_Type),
      "Switches" : 'rundll32.exe setupapi,InstallHinfSection DefaultInstall 132 %s',
      "Notes" : getText(txtUSSFType0_Notes)
   }
   ,
   {
      "Type" : getText(txtUSSFType1_Type),
      "Switches" : 'regedit.exe /s %s',
      "Notes" : getText(txtUSSFType1_Notes)
   }
   ,
   {
      "Type" : getText(txtUSSFType2_Type),
      "Switches" : "%s /S",
      "Notes" : getText(txtUSSFType2_Notes)
   }
   ,
   {
      "Type" : getText(txtUSSFType3_Type),
      "Switches" : '%s /VERYSILENT /SUPPRESSMSGBOXES /NORESTART /SP-',
      "Notes" : getText(txtUSSFType3_Notes)
   }
   ,
   {
      "Type" : getText(txtUSSFType4_Type),
      "Switches" : '%s',
      "Notes" : getText(txtUSSFType4_Notes)
   }
   ,
   {
      "Type" : getText(txtUSSFType5_Type),
      "Switches" : '%s /s /v"/qb"',
      "Notes" : getText(txtUSSFType5_Notes)
   }
   ,
   {
      "Type" : getText(txtUSSFType6_Type),
      "Switches" : '%s /S',
      "Notes" : getText(txtUSSFType6_Notes)
   }
   ,
   {
      "Type" : getText(txtUSSFType7_Type),
      "Switches" : '%s /S',
      "Notes" : getText(txtUSSFType7_Notes)
   }
   ,
   {
      "Type" : getText(txtUSSFType8_Type),
      "Switches" : '%s',
      "Notes" : getText(txtUSSFType8_Notes)
   }
   ,
   {
      "Type" : getText(txtUSSFType9_Type),
      "Switches" : '%s',
      "Notes" : getText(txtUSSFType9_Notes)
   }
   ,
   {
      "Type" : getText(txtUSSFType10_Type),
      "Switches" : '%s',
      "Notes" : getText(txtUSSFType10_Notes)
   }
   ,
   {
      "Type" : getText(txtUSSFType11_Type),
      "Switches" : '%s',
      "Notes" : getText(txtUSSFType11_Notes)
   }
   ,
   {
      "Type" : getText(txtUSSFType12_Type),
      "Switches" : '%s',
      "Notes" : getText(txtUSSFType12_Notes)
   }
   ,
   {
      "Type" : getText(txtUSSFType13_Type),
      "Switches" : '%s',
      "Notes" : getText(txtUSSFType13_Notes)
   }
   ,
   {
      "Type" : getText(txtUSSFType14_Type),
      "Switches" : '%s',
      "Notes" : getText(txtUSSFType14_Notes)
   }
   ,
   {
      "Type" : getText(txtUSSFType15_Type),
      "Switches" : 'msiexec.exe /i %s /qb',
      "Notes" : getText(txtUSSFType15_Notes)
   }
   ],

   "Errors" : [
   {
      "Error" : getText(txtUSSFError0_Error),
      "Notes" : getText(txtUSSFError0_Notes)
   }
   ,
   {
      "Error" : getText(txtUSSFError1_Error),
      "Notes" : getText(txtUSSFError1_Notes)
   }
   ,
   {
      "Error" : getText(txtUSSFError2_Error),
      "Notes" : getText(txtUSSFError2_Notes)
   }
   ,
   {
      "Error" : getText(txtUSSFError3_Error),
      "Notes" : getText(txtUSSFError3_Notes)
   }
   ,
   {
      "Error" : getText(txtUSSFError4_Error),
      "Notes" : getText(txtUSSFError4_Notes)
   }
   ,
   {
      "Error" : getText(txtUSSFError5_Error),
      "Notes" : getText(txtUSSFError5_Notes)
   }
   ,
   {
      "Error" : getText(txtUSSFError6_Error),
      "Notes" : getText(txtUSSFError6_Notes)
   }
   ,
   {
      "Error" : getText(txtUSSFError7_Error),
      "Notes" : getText(txtUSSFError7_Notes)
   }
   ]
}
;
