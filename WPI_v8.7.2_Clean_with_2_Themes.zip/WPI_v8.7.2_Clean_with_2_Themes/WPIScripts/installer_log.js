//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// installer_log.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

function OpenLogFile()
{
   position = "installer_log.js";
   whatfunc = "OpenLogFile()";

   var logFile;
   var stamp, month, date, hours, minutes, seconds;
   var TheDate = new Date();

   if (LogInstallation)
   {
      if (LogPath == "")
      {
         LogPath = DefaultLogPath;
      }

      logFile = ReplacePath(LogPath[0]);

      if (TimeStampLogFile && ! ResumeInstall)
      {
         month = (TheDate.getMonth() + 1) < 10 ? "0" + (TheDate.getMonth() + 1) : (TheDate.getMonth() + 1);
         date = (TheDate.getDate() < 10) ? "0" + TheDate.getDate() : TheDate.getDate();
         hours = (TheDate.getHours() < 10) ? "0" + TheDate.getHours() : TheDate.getHours();
         minutes = (TheDate.getMinutes() < 10) ? "0" + TheDate.getMinutes() : TheDate.getMinutes();
         seconds = (TheDate.getSeconds() < 10) ? "0" + TheDate.getSeconds() : TheDate.getSeconds();
         stamp = "_" + TheDate.getFullYear() + "." + month + "." + date + "_" + hours + "." + minutes + "." + seconds + ".txt";
         logFile = logFile.replace(/.txt/gi, stamp);
      }

      if ( ! ResumeInstall)
      {
         WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\LogPath", logFile, "REG_SZ");
      }

      if (ResumeInstall)
      {
         try
         {
            logFile = logFile.replace(/\"/g,"");
            logHandle = fso.OpenTextFile(logFile, 8, 0, - 2);
         }
         catch(ex)
         {
            LogInstallation = false;

            return;
         }
      }
      else
      {
         try
         {
            logFile = logFile.replace(/\"/g,"");
            logHandle = fso.CreateTextFile(logFile, true, true);
            logHandle.WriteLine(getText(WPIInstallLogFile) + "\r\n");
            logHandle.WriteLine(getText(InstallProcessStarted) + " " + LogTimeStamp());
            LogWPIInformation();
            LogGlobalVariables();
         }
         catch(ex)
         {
            LogInstallation = false;

            return;
         }
      }
   }
   else
   WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\LogPath", "", "REG_SZ");
}

function LogWPIInformation()
{
   position = "installer_log.js";
   whatfunc = "LogWPIInformation()";

   WriteLogLinePlain("\r\n" + getText(txtWPIInformation));
   WriteLogLinePlain("   " + getText(legVersion) + "=" + ShortVersion);
   WriteLogLinePlain("   " + getText(lblUsedLauncher) + "=" + usedLauncher);
   WriteLogLinePlain("   " + getText(lblIEVersion) + "=" + getIEver());
   WriteLogLinePlain("   " + getText(lblInternetConnection) + "=" + ConnectedToInternet());
   WriteLogLinePlain("\r\n" + getText(lblOperatingSystem));
   WriteLogLinePlain("   " + getText(lblOSvernumber) + "=" + getOSvernum());
   WriteLogLinePlain("   " + getText(lblOperatingSystem) + "=" + getOSver());
   WriteLogLinePlain("   " + getText(lblOSBuild) + "=" + getOSBuildID());
   WriteLogLinePlain("   " + getText(lblEditionID) + "=" + getOSeditionID());
   WriteLogLinePlain("   " + getText(lblServicePack) + "=" + getSPver());
   WriteLogLinePlain("\r\n" + getText(lblArchitecture));
   WriteLogLinePlain("   " + getText(lblArchName) + "=" + getArchName());
   WriteLogLinePlain("   " + getText(lblArchNameString) + "=" + getArchNameString());
   WriteLogLinePlain("   " + getText(lblArchID) + "=" + getArchIdentifier());
   WriteLogLinePlain("   " + getText(lblNumberProcessors) + "=" + getArchNumProcs());
   WriteLogLinePlain("   " + getText(lblMHz) + "=" + getArchMHz());
   WriteLogLinePlain("   " + getText(lblArchType) + "=" + getArch());
   WriteLogLinePlain("   " + getText(lblArchBits) + "=" + getBits());
   WriteLogLinePlain("");
   WriteLogLinePlain("   " + getText(lblConfigFile) + "=" + configFile);
   WriteLogLinePlain("   " + getText(lblOptionsFile) + "=" + optionsFile);
   WriteLogLinePlain("   " + getText(lblNetworkFile) + "=" + networkFile);
   WriteLogLinePlain("   " + getText(lblThemeFile) + "=" + themeFile);
   WriteLogLinePlain("   " + getText(lblWindowsFile) + "=" + windowFile);

   // Window tab
   WriteLogLinePlain("");
   WriteLogLinePlain("// Window tab");
   WriteLogLinePlain("   Resolution=" + Resolution);
   WriteLogLinePlain("   MainWindowWidth=" + MainWindowWidth);
   WriteLogLinePlain("   MainWindowHeight=" + MainWindowHeight);
   WriteLogLinePlain("   MainWindowX=" + MainWindowX);
   WriteLogLinePlain("   MainWindowY=" + MainWindowY);
   WriteLogLinePlain("   InstallerWindowX=" + InstallerWindowX);
   WriteLogLinePlain("   InstallerWindowY=" + InstallerWindowY);

   // General tab
   WriteLogLinePlain("");
   WriteLogLinePlain("// General tab");
   WriteLogLinePlain("   NumCols=" + NumCols);
   WriteLogLinePlain("   // ---");
   WriteLogLinePlain("   Timer=" + Timer);
   WriteLogLinePlain("   Seconds=" + Seconds);
   WriteLogLinePlain("   StartBeepAtSecs=" + StartBeepAtSecs);
   WriteLogLinePlain("   // ---");
   WriteLogLinePlain("   Language='" + Language + "'");
   WriteLogLinePlain("   // ---");
   WriteLogLinePlain("   DefaultInstallPath='" + DefaultInstallPath +"'");
   WriteLogLinePlain("   CustomInstallPath=['"+ CustomInstallPath +"']");
   WriteLogLinePlain("   // ---");
   WriteLogLinePlain("   AbortInstallIfFailure=" + AbortInstallIfFailure);
   WriteLogLinePlain("   ExecuteCommandIfFailure=['"+ ExecuteCommandIfFailure +"']");
   WriteLogLinePlain("   ContinueWhereFailed=" + ContinueWhereFailed);

   // Features tab
   WriteLogLinePlain("");
   WriteLogLinePlain("// Features tab");
   WriteLogLinePlain("   ShowDownloadOutput=" + ShowDownloadOutput);
   WriteLogLinePlain("   DisableInstallCombobox=" + DisableInstallCombobox);
   WriteLogLinePlain("   ShowExtraButtons=" + ShowExtraButtons);
   WriteLogLinePlain("   DoNotShowIfCD=" + DoNotShowIfCD);
   WriteLogLinePlain("   USSFSilentMode=" + USSFSilentMode);
   WriteLogLinePlain("   VerifyInstallHDD=" + VerifyInstallHDD);
   WriteLogLinePlain("   AllowCheckForInternet=" + AllowCheckForInternet);
   WriteLogLinePlain("   LoadDesktopBeforeInstall=" + LoadDesktopBeforeInstall);
   WriteLogLinePlain("   ReOpenAfterInstall=" + ReOpenAfterInstall);
   WriteLogLinePlain("   DisableCatCheckBoxes=" + DisableCatCheckBoxes);
   WriteLogLinePlain("   SortWithinCats=" + SortWithinCats);
   WriteLogLinePlain("   DisableOnDepsNotMet=" + DisableOnDepsNotMet);
   WriteLogLinePlain("   AlwaysUseScrollBar=" + AlwaysUseScrollBar);
   WriteLogLinePlain("   DontSplitCats=" + DontSplitCats);
   WriteLogLinePlain("   InstallByCategory=" + InstallByCategory);
   WriteLogLinePlain("   ReallyForce=" + ReallyForce);
   WriteLogLinePlain("   DisableIfDoGray=" + DisableIfDoGray);
   WriteLogLinePlain("   InstallFonts=" + InstallFonts);
   WriteLogLinePlain("   ShowCommandInInstaller=" + ShowCommandInInstaller);
   WriteLogLinePlain("   ShowInstallerImages=" + ShowInstallerImages);
   WriteLogLinePlain("   AlwaysShowOutputWindow=" + AlwaysShowOutputWindow);
   WriteLogLinePlain("   EjectCDWhenDone=" + EjectCDWhenDone);
   WriteLogLinePlain("   DoNotShowIfUSB=" + DoNotShowIfUSB);
   WriteLogLinePlain("   DisableHotKeys=" + DisableHotKeys);
   WriteLogLinePlain("   MaintainAutoLogonCount=" + MaintainAutoLogonCount);

   // Tools tab
   WriteLogLinePlain("");
   WriteLogLinePlain("// Tools tab");
   WriteLogLinePlain("   MonitorResolution=" + MonitorResolution);
   WriteLogLinePlain("   MonitorDepth=" + MonitorDepth);
   WriteLogLinePlain("   MonitorRefresh=" + MonitorRefresh);
   WriteLogLinePlain("   // ---");
   WriteLogLinePlain("   ExecuteBeforeEnabled=" + ExecuteBeforeEnabled);
   WriteLogLinePlain("   ExecuteBefore=['"+ExecuteBefore+"']");
   WriteLogLinePlain("   ExecuteAfterEnabled=" + ExecuteAfterEnabled);
   WriteLogLinePlain("   ExecuteAfter=['"+ExecuteAfter+"']");
   WriteLogLinePlain("   // ---");
   WriteLogLinePlain("   RestartComputer=" + RestartComputer);
   WriteLogLinePlain("   RestartType=" + RestartType);
   WriteLogLinePlain("   RestartSeconds=" + RestartSeconds);
   WriteLogLinePlain("   DoNotLoadDesktop=" + DoNotLoadDesktop);
   WriteLogLinePlain("   // ---");
   WriteLogLinePlain("   LogInstallation=" + LogInstallation);
   WriteLogLinePlain("   LogPath=['" + LogPath + "'];");
   WriteLogLinePlain("   TimeStampLogFile=" + TimeStampLogFile);

   // Audio tab
   WriteLogLinePlain("");
   WriteLogLinePlain("// Audio tab");
   WriteLogLinePlain("   PlayAudioInInstaller=" + PlayAudioInInstaller);
   WriteLogLinePlain("   InstallAudio=['"+InstallAudio+"']");
   WriteLogLinePlain("   Volume=" + Volume);
   WriteLogLinePlain("   Shuffle=" + Shuffle);
   WriteLogLinePlain("   CopyAudioFolder=" + CopyAudioFolder);
   WriteLogLinePlain("   CopyAudioPath=['" + CopyAudioPath +"']");
   WriteLogLinePlain("   DeleteAudioFolder=" + DeleteAudioFolder);

   // Sounds tab
   WriteLogLinePlain("");
   WriteLogLinePlain("// Sounds tab");
   WriteLogLinePlain("   SndWPIStartCB=" + SndWPIStartCB);
   WriteLogLinePlain("   SndWPIStart=['" + SndWPIStart + "'];");
   WriteLogLinePlain("   SndInstallStartCB=" + SndInstallStartCB);
   WriteLogLinePlain("   SndInstallStart=['" + SndInstallStart + "'];");
   WriteLogLinePlain("   SndInstallSuccessCB=" + SndInstallSuccessCB);
   WriteLogLinePlain("   SndInstallSuccess=['" + SndInstallSuccess + "'];");
   WriteLogLinePlain("   SndInstallFailCB=" + SndInstallFailCB);
   WriteLogLinePlain("   SndInstallFail=['" + SndInstallFail + "'];");
   WriteLogLinePlain("   SndInstallFinishCB=" + SndInstallFinishCB);
   WriteLogLinePlain("   SndInstallFinish=['" + SndInstallFinish + "'];");
   WriteLogLinePlain("   SndInstallWarningCB=" + SndInstallWarningCB);
   WriteLogLinePlain("   SndInstallWarning=['" + SndInstallWarning + "'];");
   WriteLogLinePlain("   SndWPIExitCB=" + SndWPIExitCB);
   WriteLogLinePlain("   SndWPIExit=['" + SndWPIExit + "'];");
   
   // Style tab
   WriteLogLinePlain("");
   WriteLogLinePlain("// Style tab");
   WriteLogLinePlain("   Theme='" + Theme +"'");
   WriteLogLinePlain("   Skin='" + ThemeSkin +"'");
   WriteLogLinePlain("   BgPicture='" + BgPicture + "'");
   WriteLogLinePlain("   // ---");
   WriteLogLinePlain("   LayoutStyle=" + LayoutStyle);
   WriteLogLinePlain("   // ---");
   WriteLogLinePlain("   ShowToolTips=" + ShowToolTips);
}

function LogGlobalVariables()
{
   position = "installer_log.js";
   whatfunc = "LogGlobalVariables()";

   WriteLogLinePlain("\r\n" + getText(GlobalVariables));
   WriteLogLinePlain("   %OSLANG%=" + oslang);
   WriteLogLinePlain("   %WPIPATH%=" + wpipath);
   WriteLogLinePlain("   %ROOT%=" + root);
   WriteLogLinePlain("   %CDROM%=" + cddrv);
   WriteLogLinePlain("   %USB%=" + usbdrv);
   WriteLogLinePlain("   %DOSPATH%=" + dospath);
   WriteLogLinePlain("   %SYSTEMDRIVE%=" + sysdrv);
   WriteLogLinePlain("   %WINDIR%=" + windir);
   WriteLogLinePlain("   %PROGRAMFILES%=" + programfiles);
   WriteLogLinePlain("   %TEMP%=" + temp);
   WriteLogLinePlain("   %SYSDIR%=" + sysdir);
   WriteLogLinePlain("   %ALLUSERSPROFILE%=" + allusersprofile);
   WriteLogLinePlain("   %USERPROFILE%=" + userprofile);
   WriteLogLinePlain("   %APPDATA%=" + appdata);
   WriteLogLinePlain("   %COMMONPROGRAMFILES%=" + commonprogramfiles);
}

function LogTimeStamp()
{
   position = "installer_log.js";
   whatfunc = "LogTimeStamp()";

   var DateStamp = new Date();

   return DateStamp.toLocaleString();
}

function StartLogEntry(prog)
{
   position = "installer_log.js";
   whatfunc = "StartLogEntry()";

   if (LogInstallation)
   logHandle.WriteLine("\r\n-----\r\n\r\n" + LogTimeStamp() + "\r\n   " + getText(lblProgram) + ": " + prog.prog + "\r\n   " + getText(lblUniqueID) + ": " + prog.uid + "\r\n   " + getText(lblOrder) + ": " + prog.ordr + "\r\n   " + getText(lblCategory) + ": " + prog.cat);

}

function WriteLogLine(logTxt)
{
   position = "installer_log.js";
   whatfunc = "WriteLogLine()";

   if (LogInstallation)
   logHandle.WriteLine("   " + LogTimeStamp() + " - " + logTxt);
}

function WriteLogLinePlain(logTxt)
{
   position = "installer_log.js";
   whatfunc = "WriteLogLinePlain()";

   if (LogInstallation)
   logHandle.WriteLine(logTxt);
}

function CloseLogFile()
{
   position = "installer_log.js";
   whatfunc = "CloseLogFile()";

   if (LogInstallation && logHandle != null)
   {
      logHandle.WriteLine("\r\n-----");
      logHandle.WriteLine("\r\n" + getText(txtNumberFailedInstalls) + " " + NumFailed);
      logHandle.WriteLine("\r\n" + getText(InstallProcessFinished) + " " + LogTimeStamp());

      logHandle.Close();
   }
}
