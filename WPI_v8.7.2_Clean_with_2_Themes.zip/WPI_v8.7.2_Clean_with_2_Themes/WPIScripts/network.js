//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// network.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

function GetUserInfo()
{
   position = "network.js";
   whatfunc = "GetUserInfo()";
   LogOnServer = getEnvVar("LOGONSERVER");
   UserDomain = getEnvVar("USERDOMAIN");
   ComputerName = getEnvVar("COMPUTERNAME");
   UserName = getEnvVar("USERNAME");
}

function SetUserInfo()
{
   position = "network.js";
   whatfunc = "SetUserInfo()";

   if (document.getElementById("UserInfo"))
   document.getElementById("UserInfo").innerHTML = "\\\\" + ComputerName + "\\" + UserName;
}

function isLogOnServer(name)
{
   position = "network.js";
   whatfunc = "isLogOnServer()";

   if (LogOnServer.toUpperCase() == name.toUpperCase())
   return true;
   else
   return false;
}

function isUserDomain(name)
{
   position = "network.js";
   whatfunc = "isUserDomain()";

   if (UserDomain.toUpperCase() == name.toUpperCase())
   return true;
   else
   return false;
}

function isComputerName(name)
{
   position = "network.js";
   whatfunc = "isComputerName()";

   if (ComputerName.toUpperCase() == name.toUpperCase())
   return true;
   else
   return false;
}

function isUserName(name)
{
   position = "network.js";
   whatfunc = "isUserName()";

   if (UserName.toUpperCase() == name.toUpperCase())
   return true;
   else
   return false;
}

function CheckIfUsingActiveDirectory()
{
   position = "network.js";
   whatfunc = "CheckIfUsingActiveDirectory()";

   try
   {
      ADSysInfo = new ActiveXObject("ADSystemInfo");
      var strUser = ADSysInfo.UserName;

      IsUsingAD = true;
   }
   catch(ex)
   {
      IsUsingAD = false;
   }
}

function isUsingActiveDirectory()
{
   position = "network.js";
   whatfunc = "isUsingActiveDirectory()";

   return IsUsingAD;
}

function isSiteNameMemberOf(sSiteName)
{
   position = "network.js";
   whatfunc = "isSiteNameMemberOf()";

   if ( ! IsUsingAD)
   return false;

   if (ADSysInfo.SiteName.toUpperCase() == sSiteName.toUpperCase())
   return true;
   else
   return false;
}

function isUserMemberOf(GroupCN)
{
   position = "network.js";
   whatfunc = "isUserMemberOf()";

   if ( ! IsUsingAD)
   return false;

   var User, MemberOf;

   User = GetObject("LDAP://" + ADSysInfo.UserName);
   MemberOf = User.MemberOf.toArray().join("\n").split("\n");

   var find = new RegExp(GroupCN, "i");
   for (i = 0; i < this.MemberOf.length; i ++ )
   {
      if (find.test(this.MemberOf[i]))
      return true;
   }

   return false;
}

function isUserCN(sCNpart)
{
   position = "network.js";
   whatfunc = "isUserCN()";

   if ( ! IsUsingAD)
   return false;

   var t1 = new String();
   var t2 = new String();

   t1 = sCNpart.toUpperCase().replace(/\W/gi, "");
   t2 = GetObject("LDAP://" + ADSysInfo.UserName);
   t2 = t2.toUpperCase().replace(/\W/gi, "");
   if (t2.indexOf(t1) != - 1)
   return true;
   else
   return false;
}

function isComputerCN(sCNpart)
{
   position = "network.js";
   whatfunc = "isComputerCN()";

   if ( ! IsUsingAD)
   return false;

   var t1 = new String();
   var t2 = new String();

   t1 = sCNpart.toUpperCase().replace(/\W/gi, "");
   t2 = GetObject("LDAP://" + ADSysInfo.ComputerName);
   t2 = t2.toUpperCase().replace(/\W/gi, "");
   if (t2.indexOf(t1) != - 1)
   return true;
   else
   return false;
}

function ConnectedToInternet()
{
   position = "network.js";
   whatfunc = "ConnectedToInternet()";

   return ConnToNet;
}

function CheckForInternet()
{
   position = "network.js";
   whatfunc = "CheckForInternet()";

   ConnToNet = pingSite("google.com");
}

function loadXMLDoc(URL, callbackFunction)
{
   position = "network.js";
   whatfunc = "loadXMLDoc()";

   if ( ! ConnectedToInternet())
   return false;

   dhtmlxAjax.get(URL, callbackFunction);

   return true;
}

function getElementTextNS(prefix, local, parentElem, index)
{
   position = "network.js";
   whatfunc = "getElementTextNS()";

   var result = "";

   if (prefix && isIE)
   result = parentElem.getElementsByTagName(prefix + ":" + local)[index];
   else
   result = parentElem.getElementsByTagName(local)[index];
   if (result)
   {
      if (result.childNodes.length > 1)
      return result.childNodes[1].nodeValue;
      else
      return result.firstChild.nodeValue;
   }
   else
   return "n/a";
}
