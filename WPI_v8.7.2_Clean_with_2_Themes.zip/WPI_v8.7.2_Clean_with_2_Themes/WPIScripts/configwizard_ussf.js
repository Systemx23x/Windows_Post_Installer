//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// configwizard_ussf.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

function ShowUSSF()
{
   position = "configwizard_ussf.js";
   whatfunc = "ShowUSSF()";

   dhxWins.window("ConfigWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 450, 125);
   SubWizardWindow.setText(getText(lblUSSF));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\configwizardtemplate_ussf.htm", "layersubwizard");

   document.getElementById("legUSSF").innerHTML = getText(lblUSSF);
   document.getElementById("lblFile").innerHTML = getText(lblFile);
   document.getElementById("lblType").innerHTML = getText(lblType);
   document.getElementById("lblSwitches").innerHTML = getText(lblSwitches);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);
   document.getElementById("File").value = USSF_FileName;
   document.getElementById("Type").value = USSFStrings.Types[USSF_Type].Type;
   document.getElementById("Switches").value = USSFStrings.Types[USSF_Type].Switches.replace(/%s/, "");
   document.getElementById("Notes").value = USSFStrings.Types[USSF_Type].Notes;

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   AutoSizeWindow(SubWizardWindow, "layersubwizard");
}

function HideUSSF(ok)
{
   position = "configwizard_ussf.js";
   whatfunc = "HideUSSF()";

   if (ok)
   {
      document.getElementById("cmd1").value = sprintf(USSFStrings.Types[USSF_Type].Switches, document.getElementById("cmd1").value);

      ConfigUpdated();
   }

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = ConfigWindow.getText();
   dhxWins.window("ConfigWindow").setModal(true);
}

function HandleUSSF()
{
   position = "configwizard_ussf.js";
   whatfunc = "HandleUSSF()";

   var path, ProgramToAnalyze, FileName, FileExtension;

   if (document.getElementById("cmd1").value.indexOf("{WEB}") != - 1 || document.getElementById("cmd1").value.indexOf("{DOWNLOAD}") != - 1)
   {
      Alert("", getText(errCanNotTestInternetFiles), getText(lblOK), "", 3, 0, 0, 0);

      return;
   }

   if (document.getElementById("cmd1").value != "")
   {
      path = document.getElementById("cmd1").value;
      path = path.replace(/\"/g,"");
      ProgramToAnalyze = document.getElementById ("cmd1").value;
      ProgramToAnalyze = ProgramToAnalyze.replace(/\"/g,"");
      ProgramToAnalyze = ReplacePath(ProgramToAnalyze);

      if (FileExists(ProgramToAnalyze))
      {
         FileName = fso.GetFileName(ProgramToAnalyze);
         USSF_FileName = FileName;
         FileExtension = fso.GetExtensionName(FileName);
         ParseProgram(ProgramToAnalyze, FileName, FileExtension, 0);
      }
      else
      Alert("", getText(errCouldNotOpenFile) + "\n'"+temp+"'.", getText(lblOK), "", 2, 0, 0, 0);
      ConfigUpdated();
   }
}

function ShowMessage(type)
{
   position = "configwizard_ussf.js";
   whatfunc = "ShowMessage()";

   USSF_Type = type;

   if ( ! USSFSilentMode)
   ShowUSSF();
   else
   document.getElementById("cmd1").value = sprintf(USSFStrings.Types[USSF_Type].Switches, document.getElementById("cmd1").value);
}

function ParseError(type)
{
   position = "configwizard_ussf.js";
   whatfunc = "ParseError()";

   Alert("", sprintf(getText(txtUSSFError).toString(), USSFStrings.Errors[type].Error, USSFStrings.Errors[type].Notes), getText(lblOK), "", 2, 0, 0, 0);
}

function ParseProgram(ProgramToAnalyze, FileName, FileExtension)
{
   position = "configwizard_ussf.js";
   whatfunc = "ParseProgram()";

   var header = "";

   switch (FileExtension)
   {
      case "msi" :
         {
            header = GetFileHeader(ProgramToAnalyze, 66);
            if (header == "D0CF11E0A1B11AE1000000000000000000000000000000003E000300FEFF090006")
            ShowMessage(15);
            else if (header != 0)
            ParseError(1);
            break;
         }

      case "exe" :
         {
            header = GetFileHeader(ProgramToAnalyze, 4);
            if (header == "4D5A")
            TestExeFile(ProgramToAnalyze);
            else if (header != 0)
            ParseError(0);
            break;
         }

      case "inf" :
         {
            ShowMessage(0);
            break;
         }

      case "reg" :
         {
            if (TestRegFile(ProgramToAnalyze) == 1)
            ShowMessage(1);
            break;
         }

      default :
         {
            ParseError(4);
            break;
         }
   }
}

function GetFileHeader(ProgramToAnalyze, NumberOfCharsToReturn)
{
   position = "configwizard_ussf.js";
   whatfunc = "GetFileHeader()";

   var FileHandle;
   var Header, HexHeader = "", hex = "";

   try
   {
      FileHandle = fso.OpenTextFile(ProgramToAnalyze, 1, false, 0);
   }
   catch (ex)
   {
      ParseError(5);

      return 0;
   }

   Header = FileHandle.Read(NumberOfCharsToReturn / 2);
   HexHeader = "", hex = "";

   FileHandle.Close();
   for (var i = 0; i < Header.length; i ++ )
   {
      hex = Header.charCodeAt(i).toString(16).toUpperCase();

      HexHeader += (hex.length < 2 ? "0" + hex : hex);
   }

   return HexHeader;
}

function TestRegFile(ProgramToAnalyze)
{
   position = "configwizard_ussf.js";
   whatfunc = "TestRegFile()";

   var Header;

   Header = GetFileHeader(ProgramToAnalyze, 156), FinalHeader = "";

   if (Header != 0)
   {
      if (Header.substr(0, 4) == "FFFE")
      {
         // Original .reg file encoded in UTF - 16, little - endian
         Header = Header.substr(4);
         // TEST IF THIS IS THE EXACT PORT OF THIS FOR CYCLE
         /* For $i = 1 To StringLen($Header) Step 4
         $FinalHeader = $FinalHeader & StringMid($Header, $i, 2)
         Next */
         for (var i = 0; i < Header.length; i += 4)
         {
            FinalHeader = FinalHeader + substr(i, 2);
         }
         Header = FinalHeader;
      }
      if ((Header.substr(0, 76) != "57696E646F777320526567697374727920456469746F722056657273696F6E20352E30300D0A") && (Header.substr(0, 20) != "52454745444954340D0A"))
      {
         ParseError(2);

         return 2;
      }

      return 1;
   }
   else
   return 0;
}

function TestExeFile(ProgramToAnalyze)
{
   position = "configwizard_ussf.js";
   whatfunc = "TestExeFile()";

   var IDString = PEiD(ProgramToAnalyze);

   if (IDString.search("Nullsoft PiMP SFX") > - 1)
   {
      TestInno(ProgramToAnalyze);
      ShowMessage(2);
   }
   else if (IDString.search("Inno Setup") > - 1)
   ShowMessage(3);
   else if (IDString.search("Installshield AFW") > - 1)
   ShowMessage(4);
   else if (IDString.search("InstallShield 2003") > - 1)
   ShowMessage(5);
   else if ((IDString.search("Wise Installer") > - 1) || (IDString.search("PEncrypt 4.0") > - 1))
   ShowMessage(6);
   else if (IDString.search("RAR SFX") > - 1)
   ShowMessage(7);
   else if ((IDString.search("CAB SFX") > - 1) || (IDString.search("SPx Method") > - 1))
   ShowMessage(8);
   else if (IDString.search("ZIP SFX") > - 1)
   ShowMessage(9);
   else if (IDString.search("Borland Delphi") > - 1)
   {
      if (TestInno(ProgramToAnalyze) == 1)
      ShowMessage(3);
      else if (TestZipSFX(ProgramToAnalyze) == 1)
      ShowMessage(9);
      else
      {
         ParseError(3);
      }
   }
   else if ((IDString.search("Microsoft Visual C\\+\\+") > - 1) && ! (IDString.search("SPx Method") > - 1) && (Test7Zip(ProgramToAnalyze) == 1))
   ShowMessage(10);
   else if (IDString.search("Not a valid PE file") > - 1)
   {
      if (Test7Zip(ProgramToAnalyze) == 1)
      ShowMessage(11);
      else if (TestZipSFX($ProgramToAnalyze) == 2)
      ShowMessage(12);
      else
      ParseError(6);
   }
   else if (IDString.search("WinZip") > - 1)
   ShowMessage(13);
   else if (IDString.search("UPX") > - 1)
   ShowMessage(14);
   else
   {
      if (Test7Zip(ProgramToAnalyze) == 1)
      ShowMessage(11);
      else if (TestZipSFX(ProgramToAnalyze) == 2)
      ShowMessage(12);
      else
      {
         ParseError(3);
      }
   }
}

function PEiD(ProgramToAnalyze)
{
   position = "configwizard_ussf.js";
   whatfunc = "PEiD()";

   var ExSig = RegKeyValue("HKCU\\Software\\PEiD\\ExSig");
   var LoadPlugins = RegKeyValue("HKCU\\Software\\PEiD\\LoadPlugins");
   var StayOnTop = RegKeyValue("HKCU\\Software\\PEiD\\StayOnTop");

   WriteRegKey("HKCU\\Software\\PEiD\\ExSig", 0, "REG_DWORD");
   WriteRegKey("HKCU\\Software\\PEiD\\LoadPlugins", 1, "REG_DWORD")
   WriteRegKey("HKCU\\Software\\PEiD\\StayOnTop", 0, "REG_DWORD")

   var PEiDOutputPath = WshEnv("TEMP") + "\\WPI_PEiD";
   if (fso.FolderExists(PEiDOutputPath))
   fso.DeleteFolder(PEiDOutputPath);
   fso.CreateFolder(PEiDOutputPath);
   var PEiDOutputFile = PEiDOutputPath + "\\PEiDOutput.TXT";
   RunCmd('"' + wpipath + '\\Tools\\PEiD\\PEiD.exe" "' + ProgramToAnalyze + '" -hard -Save -QuitAfter -IDPath:"' + PEiDOutputPath + '"', false, true);
   if ( ! fso.FileExists(PEiDOutputFile))
   {
      ParseError(7);

      return "";
   }

   var FileHandle = fso.OpenTextFile(PEiDOutputFile, 1);
   var IDString = FileHandle.ReadLine();
   FileHandle.Close();
   fso.DeleteFolder(PEiDOutputPath);

   WriteRegKey("HKCU\\Software\\PEiD\\ExSig", ExSig, "REG_DWORD");
   WriteRegKey("HKCU\\Software\\PEiD\\LoadPlugins", LoadPlugins, "REG_DWORD");
   WriteRegKey("HKCU\\Software\\PEiD\\StayOnTop", StayOnTop, "REG_DWORD");

   return IDString;
}

function TestInno(ProgramToAnalyze)
{
   position = "configwizard_ussf.js";
   whatfunc = "TestInno()";

   var oExec = WshShell.Exec('"' + wpipath + '\\Tools\\InnoUnp\\InnoUnp.exe" "' + ProgramToAnalyze + '"');

   while (oExec.Status == 0)
   Pause(0, 100);
   var Output = oExec.StdOut.ReadAll() + oExec.StdErr.ReadAll();
   if (Output.search("Version detected:") > - 1)
   return 1;

   return 0;
}

function TestZipSFX(ProgramToAnalyze)
{
   position = "configwizard_ussf.js";
   whatfunc = "TestZipSFX()";

   var oExec = WshShell.Exec('"' + wpipath + '\\Tools\\UnZip\\UnZip.exe" -l "' + ProgramToAnalyze + '"');

   while (oExec.Status == 0)
   Pause(0, 100);
   var Output = oExec.StdOut.ReadAll() + oExec.StdErr.ReadAll();

   if (Output.search("signature not found") == - 1)
   return 1;
   if (Output.search("Length") > - 1)
   return 2;

   return 0;
}

function Test7Zip(ProgramToAnalyze)
{
   position = "configwizard_ussf.js";
   whatfunc = "Test7Zip()";

   var oExec = WshShell.Exec('"' + wpipath + '\\Tools\\7z\\7z.exe" l "' + ProgramToAnalyze + '"');

   var x = 0;
   while (oExec.Status == 0 && x < 5)
   {
      Pause(0, 100);
      x ++ ;
   }
   var Output = oExec.StdOut.ReadAll() + oExec.StdErr.ReadAll();
   if (Output.search("Listing archive:") > - 1)
   return 1;

   return 0;
}
