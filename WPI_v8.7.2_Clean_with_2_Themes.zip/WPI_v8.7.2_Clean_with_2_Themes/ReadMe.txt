!!! *** Existing users only *** !!! 

All others just delete the readme.txt file from the 
WPI folder to remove this notice\button.

The 5 "core" WPI files need to be moved to the new dir.

WPI will no longer recognize your files in the wpiscripts dir.

To easily do this just run the cmd file "Upgrade", In your old WPI
folder, then copy the created UserFiles folder to the new WPI folder. 

Steps to update your WPI folder:

1. Download and extract the new WPI archive to a different location.

2. Run the upgrade.cmd file in the old WPI folder.

3. Copy the newly created UserFiles folder from old to new.

4. Copy your Audio folder from old to new.

5. Copy your Install folder from old to new.

6. Copy Themes folder from old to new.

7. Copy all of your Logos\Graphics files the new location.

8. Rename or move your old folder in case something goes wrong.

9. Move the new WPI folder to where you want it.

10. Test it!

MAJOR new step!
Update your run WPI methods as WPI\WPI.hta no longer exists! 
You now need to use WPI\WPI.exe! 

(To remove the "Read Me" button delete the readme.txt file in the WPI folder.)