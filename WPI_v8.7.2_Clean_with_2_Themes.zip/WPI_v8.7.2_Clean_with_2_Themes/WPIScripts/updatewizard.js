//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// updatewizard.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

function CheckForNeededUpdates()
{
   position = "updatewizard.js";
   whatfunc = "CheckForNeededUpdates()";

   if (NeedUpdateWizard == 2)
   {
      UpdateWizard2();
   }

   if (NeedUpdateWizard == 800)
   {
      UpdateWizard800();
   }
}

function UpdateWizard800()
{
   position = "updatewizard.js";
   whatfunc = "UpdateWizard800()";

   var src, dst;

   src = configFile;
   dst = configFile.replace(/.js/, "-orig.js");
   fso.CopyFile(src, dst);
   var txt = new String();

   if (fromCDDrive)
   {
      Alert("", getText(txtCanNotSaveToCD), getText(lblOK), "", 2, 0, 0, 0);

      return;
   }

   strFile = configFile.replace(/.js/, "_json800.js");
   try
   {
      Alert("", getText(txtConfigBeingUpdated) + "\n\n" + getText(txtPleaseWait) + "\n\n\n" + getText(txtBackupMade), "---none---", "", 3, - 1, 0, 0);

      tf = fso.CreateTextFile(strFile, true, true);
      tf.WriteLine("// WPI Config 8.1.0");
      tf.WriteLine("//");
      tf.WriteLine("// User defined options");
      tf.WriteLine("//");
      tf.WriteLine("");
      tf.WriteLine("");
      tf.WriteLine('ConfigList=');
      tf.WriteLine('{');
      tf.WriteLine('\t"Configurations" : [');
      if (configList.Configurations.length == 0)
      {
         tf.WriteLine('\t],');
      }
      else
      {
         for (var j = 0; j < configList.Configurations.length;
         j ++ )
         {
            tf.WriteLine('\t\t{');
            tf.WriteLine('\t\t\t"Name" : "'+configList.Configurations[j].Name+'",');
            if (j != configList.Configurations.length - 1)
            {
               tf.WriteLine('\t\t},');
            }
            else
            {
               tf.WriteLine('\t\t}');
            }
         }
         tf.WriteLine('\t],');
      }
      tf.WriteLine('\t"ShowMultiDefault" : ' + document.getElementById("ShowMultiDefault").checked + ',');
      tf.WriteLine('\t"CheckOnLoad" : ' + GetCheckOnLoad() + ',');
      tf.WriteLine('\t"SortOrder" : [');
      if (configList.SortOrder.length == 0)
      {
         tf.WriteLine('\t],');
      }
      else
      {
         for (var j = 0; j < configList.SortOrder.length;
         j ++ )
         {
            tf.WriteLine('\t\t{');
            tf.WriteLine('\t\t\t"Category" : "'+configList.SortOrder[j].Category+'"');
            if (j != configList.SortOrder.length - 1)
            {
               tf.WriteLine('\t\t},');
            }
            else
            {
               tf.WriteLine('\t\t}');
            }
         }
         tf.WriteLine('\t],');
      }
      tf.WriteLine("");
      tf.WriteLine('\t"Programs" : [');
      for (var i = 0; i < configList.Programs.length;
      i ++ )
      {
         tf.WriteLine('\t\t{');
         tf.WriteLine('\t\t\t"Program" : "'+configList.Programs[i].Program+'",');
         tf.WriteLine('\t\t\t"ShortDescription" : "'+configList.Programs[i].ShortDescription+'",');
         tf.WriteLine('\t\t\t"UserID" : "'+configList.Programs[i].UserID+'",');
         tf.WriteLine('\t\t\t"InstallOrder" : ' + configList.Programs[i].InstallOrder + ',');
         tf.WriteLine('\t\t\t"Default" : ' + configList.Programs[i].Default + ',');
         tf.WriteLine('\t\t\t"Force" : ' + configList.Programs[i].Force + ',');
         tf.WriteLine('\t\t\t"Category" : "'+configList.Programs[i].Category+'",');
         tf.WriteLine('\t\t\t"Configurations" : [');
         if (configList.Programs[i].Configurations.length == 0)
         {
            tf.WriteLine('\t\t\t],');
         }
         else
         {
            for (var j = 0; j < configList.Programs[i].Configurations.length;
            j ++ )
            {
               tf.WriteLine('\t\t\t\t{');
               tf.WriteLine('\t\t\t\t\t"Name" : "'+configList.Programs[i].Configurations[j].Name+'"');
               if (j != configList.Programs[i].Configurations.length - 1)
               {
                  tf.WriteLine('\t\t\t\t},');
               }
               else
               {
                  tf.WriteLine('\t\t\t\t}');
               }
            }
            tf.WriteLine('\t\t\t],');
         }
         tf.WriteLine('\t\t\t"RebootCode" : "'+configList.Programs[i].RebootCode+'",');
         tf.WriteLine('\t\t\t"RepeatCommand" : "'+configList.Programs[i].RepeatCommand+'",');
         tf.WriteLine('\t\t\t"Commands" : [');
         if (configList.Programs[i].Commands.length == 0)
         {
            tf.WriteLine('\t\t\t],');
         }
         else
         {
            for (var j = 0; j < configList.Programs[i].Commands.length;
            j ++ )
            {
               tf.WriteLine('\t\t\t\t{');
               tf.WriteLine('\t\t\t\t\t"Command" : \''+configList.Programs[i].Commands[j].Command+'\'');
               if (j != configList.Programs[i].Commands.length - 1)
               {
                  tf.WriteLine('\t\t\t\t},');
               }
               else
               {
                  tf.WriteLine('\t\t\t\t}');
               }
            }
            tf.WriteLine('\t\t\t],');
         }
         tf.WriteLine('\t\t\t"Dependencies" : [');
         if (configList.Programs[i].Dependencies.length == 0)
         {
            tf.WriteLine('\t\t\t],');
         }
         else
         {
            for (var j = 0; j < configList.Programs[i].Dependencies.length;
            j ++ )
            {
               tf.WriteLine('\t\t\t\t{');
               tf.WriteLine('\t\t\t\t\t"UserID" : "'+configList.Programs[i].Dependencies[j].UserID+'"');
               if (j != configList.Programs[i].Dependencies.length - 1)
               {
                  tf.WriteLine('\t\t\t\t},');
               }
               else
               {
                  tf.WriteLine('\t\t\t\t}');
               }
            }
            tf.WriteLine('\t\t\t],');
         }
         tf.WriteLine('\t\t\t"Exclusions" : [');
         if (configList.Programs[i].Exclusions.length == 0)
         {
            tf.WriteLine('\t\t\t],');
         }
         else
         {
            for (var j = 0; j < configList.Programs[i].Exclusions.length;
            j ++ )
            {
               tf.WriteLine('\t\t\t\t{');
               tf.WriteLine('\t\t\t\t\t"UserID" : "'+configList.Programs[i].Exclusions[j].UserID+'"');
               if (j != configList.Programs[i].Exclusions.length - 1)
               {
                  tf.WriteLine('\t\t\t\t},');
               }
               else
               {
                  tf.WriteLine('\t\t\t\t}');
               }
            }
            tf.WriteLine('\t\t\t],');
         }
         tf.WriteLine('\t\t\t"Conditions" : \''+configList.Programs[i].Conditions+'\',');
         tf.WriteLine('\t\t\t"GrayedConditions" : \''+configList.Programs[i].GrayedConditions+'\',');
         tf.WriteLine('\t\t\t"ToolTip" : [');
         tf.WriteLine('\t\t\t\t{');
         tf.WriteLine('\t\t\t\t\t"Description" : \''+configList.Programs[i].ToolTip[0].Description+'\',');
         tf.WriteLine('\t\t\t\t\t"Picture" : \''+configList.Programs[i].ToolTip[0].Picture+'\',');
         tf.WriteLine('\t\t\t\t\t"PictureWidth" : ' + configList.Programs[i].ToolTip[0].PictureWidth + ',');
         tf.WriteLine('\t\t\t\t\t"PictureHeight" : ' + configList.Programs[i].ToolTip[0].PictureHeight + ',');
         tf.WriteLine('\t\t\t\t\t"TextLocation" : "'+configList.Programs[i].ToolTip[0].TextLocation);
         tf.WriteLine('\t\t\t\t}');
         tf.WriteLine('\t\t\t],');
         if (i != configList.Programs.length - 1)
         {
            tf.WriteLine('\t\t},');
         }
         else
         {
            tf.WriteLine('\t\t}');
         }
      }
      tf.WriteLine('\t]');
      tf.WriteLine('};');
   }
   catch(ex)
   {
      alert(getText(errCouldNotSaveFile) + "\n\n" + getText(lblFile) + ": " + strFile + "\n" + getText(lblErrorNumber) + ": " + (ex.number & 0xffff) + "\n" + getText(lblErrorDescription) + ": " + ex.description);
   }
   finally
   {
      try
      {
         tf.Close();
      }
      catch (ex0)
      {
         ;

      }

      Pause(1, 0);
      CloseAlert(0);
   }

   RefreshWPI();
}

function UpdateWizard2()
{
   position = "updatewizard.js";
   whatfunc = "UpdateWizard2()";

   var src, dst;

   src = optionsFile;
   dst = optionsFile.replace(/.js/, "-orig.js");
   fso.CopyFile(src, dst);

   src = configFile;
   dst = configFile.replace(/.js/, "-orig.js");
   fso.CopyFile(src, dst);

   ShowConfig();
   Alert("", getText(txtConfigBeingUpdated) + "\n\n" + getText(txtPleaseWait) + "\n\n\n" + getText(txtBackupMade), "---none---", "", 3, - 1, 0, 0);
   SaveConfig();
   CloseAlert(0);
   Pause(1, 0);
   HideConfig(false);

   ShowOptions();
   Alert("", getText(txtOptionsBeingUpdated) + "\n\n" + getText(txtPleaseWait) + "\n\n\n" + getText(txtBackupMade), "---none---", "", 3, - 1, 0, 0);
   SaveOptions();
   CloseAlert(0);
   Pause(1, 0);
   HideOptions(false);

   RefreshWPI();
}

function UpdateWizard1()
{
   position = "updatewizard.js";
   whatfunc = "UpdateWizard1()";

   var src, dst;

   src = configFile;
   dst = configFile.replace(/.js/, "-orig.js");
   fso.CopyFile(src, dst);

   ReadOldConfig();
   SaveNewConfig();
}

function UpdateCommand(cmd)
{
   position = "updatewizard.js";
   whatfunc = "UpdateCommand()";

   var firstToken;

   if (cmd.indexOf("JSCRIPT=") != - 1 && cmd.substr(0, 1) != '"')
   {
      cmd = cmd.replace(/JSCRIPT=/gi,'{JSCRIPT}=');

      return cmd;
   }

   if (cmd.indexOf(" ") != - 1 && cmd.substr(0, 1) != '"')
   {
      firstToken = cmd.substr(0, cmd.indexOf(" "));
      if (firstToken == "")
      firstToken = cmd;
      switch(firstToken.toUpperCase())
      {
         case 'REGDLL' :
            cmd = cmd.replace(/REGDLL/gi, '{REGDLL}');
            break;

         case 'UNREGDLL' :
            cmd = cmd.replace(/UNREGDLL/gi, '{UNREGDLL}');
            break;

         case 'INSTINF' :
            cmd = cmd.replace(/INSTINF/gi, '{INSTINF}');
            break;

         case 'REGEDIT' :
            cmd = cmd.replace(/REGEDIT \/S/gi, '{REGEDIT}');
            break;

         case 'FILECOPY' :
            cmd = cmd.replace(/FILECOPY/gi, '{FILECOPY}');
            break;

         case 'FILEMOVE' :
            cmd = cmd.replace(/FILEMOVE/gi, '{FILEMOVE}');
            break;

         case 'RENAME' :
            cmd = cmd.replace(/RENAME/gi, '{RENAME}');
            break;

         case 'DELETE' :
            cmd = cmd.replace(/DELETE/gi, '{DELETE}');
            break;

         case 'MAKEDIR' :
            cmd = cmd.replace(/MAKEDIR/gi, '{MAKEDIR}');
            break;

         case 'DIRCOPY' :
            cmd = cmd.replace(/DIRCOPY/gi, '{DIRCOPY}');
            break;

         case 'DELDIR' :
            cmd = cmd.replace(/DELDIR/gi, '{DELDIR}');
            break;

         case 'TSKILL' :
            cmd = cmd.replace(/TSKILL/gi, '{TASKKILL}');
            break;

         case 'TASKKILL' :
            cmd = cmd.replace(/TASKKILL \/F \/IM/gi, '{TASKKILL}');
            cmd = cmd.replace(/TASKKILL \/IM \/F/gi, '{TASKKILL}');
            break;

         case '%EXTRACT%' :
            cmd = cmd.replace(/%EXTRACT%/gi, '{EXTRACT}');
            break;

         case '%SLEEP%' :
            cmd = cmd.replace(/%SLEEP%/gi, '{SLEEP}');
            break;

         case '%REBOOT%' :
            cmd = cmd.replace(/%REBOOT%/gi, '{REBOOT}');
            break;

         case '{BATCH}' :
            cmd = cmd.replace(/{BATCH}/gi, 'batch');
            break;
      }

      return cmd;
   }

   if (cmd.indexOf(" ") == - 1 && cmd.substr(0, 1) != '"')
   cmd = '"'+cmd+'"';

   return cmd;
}

function ReadOldConfig()
{
   position = "updatewizard.js";
   whatfunc = "ReadOldConfig()";

   var line = new String();
   var opt = new String();
   var val = new String();
   var i, txt;

   pn = 1;
   strFile = configFile;
   if (FileExists(strFile))
   {
      configList = [];
      try
      {
         tf = fso.OpenTextFile(strFile, 1, 0, - 2);
         while ( ! tf.AtEndOfStream)
         {
            line = tf.ReadLine();
            if (line.search("^ *$") == 0)
            continue;
            // empty line
            if (line.search("^ *//") == 0)
            continue;
            // comments
            if (line.search("^ *pn") == 0)
            continue;
            // pn ++
            line = line.replace(/^var /g, "");
            line = line.replace(/^ */g, "");

            opt = line.substring(0, line.indexOf("["));
            val = line.substring(line.indexOf("=") + 1, line.length);
            val = val.replace(/^ *\[ */, "").replace(/^ *' */,"");
            val = val.replace(/ *] *$/, "").replace(/ *' *$/,"");
            val = val.replace(/ *]; *$/, "").replace(/ *' *$/,"");
            val = val.replace(/\\\\/g,"\\");
            val = val.replace(/\\'/g,"'");
            switch (opt)
            {
               case "prog" :
               configList[pn - 1] = new program(pn);
               clearProgram(configList[pn - 1]);
               configList[pn - 1].prog = val;
               pn ++ ;
               break;

               case "ordr" :
               configList[pn - 2].ordr = val;
               break;

               case "desc" :
               configList[pn - 2].desc = val;
               break;

               case "uid" :
               configList[pn - 2].uid = val;
               break;

               case "dflt" :
               configList[pn - 2].dflt = val;
               break;

               case "cat" :
               configList[pn - 2].cat = val;
               break;

               case "forc" :
               configList[pn - 2].forc = val;
               break;

               case "configs" :
               configList[pn - 2].configs = val;
               break;

               case "deps" :
               val = val.replace (/ *' *, *' */gi, ",");
               configList[pn - 2].deps = val;
               break;

               case "excl" :
               val = val.replace (/ *' *, *' */gi, ",");
               configList[pn - 2].excl = val;
               break;

               case "cond" :
               configList[pn - 2].cond = val;
               break;

               case "gcond" :
               configList[pn - 2].gcond = val;
               break;

               case "regb" :
               configList[pn - 2].regb = val;
               break;

               case "cmd1" :
               configList[pn - 2].cmd1 = val;
               break;

               case "cmd2" :
               configList[pn - 2].cmd2 = val;
               break;

               case "cmd3" :
               configList[pn - 2].cmd3 = val;
               break;

               case "cmd4" :
               configList[pn - 2].cmd4 = val;
               break;

               case "cmd5" :
               configList[pn - 2].cmd5 = val;
               break;

               case "cmd6" :
               configList[pn - 2].cmd6 = val;
               break;

               case "cmd7" :
               configList[pn - 2].cmd7 = val;
               break;

               case "cmd8" :
               configList[pn - 2].cmd8 = val;
               break;

               case "cmd9" :
               configList[pn - 2].cmd9 = val;
               break;

               case "cmd10" :
               configList[pn - 2].cmd10 = val;
               break;

               case "rega" :
               configList[pn - 2].rega = val;
               break;

               case "picf" :
               configList[pn - 2].picf = val;
               break;

               case "picw" :
               if (configList[pn - 2].picf)
               configList[pn - 2].picw = val;
               break;

               case "pich" :
               if (configList[pn - 2].picf)
               configList[pn - 2].pich = val;
               break;

               case "textl" :
               if (configList[pn - 2].picf)
               configList[pn - 2].textl = val;
               break;
            }
         }
      }
      catch(ex)
      {
         ;

      }
      finally
      {
         try
         {
            tf.Close();
         }
         catch (ex0)
         {
            ;

         }
      }
   }
}

function SaveNewConfig()
{
   position = "updatewizard.js";
   whatfunc = "SaveNewConfig()";

   var form, txt;

   strFile = configFile;
   try
   {
      tf = fso.CreateTextFile(strFile, true, true);

      tf.WriteLine("// WPI Config 7.2.0+");
      tf.WriteLine("//");
      tf.WriteLine("// User defined options");
      tf.WriteLine("//");
      tf.WriteLine("//---------------------------------------------------------------------------------------------");
      tf.WriteLine("// Reference ... prog[0] won't be used. It's just an example.");
      tf.WriteLine("// Look in program.js to see explanation of these properties.");
      tf.WriteLine("//---------------------------------------------------------------------------------------------  ");
      tf.WriteLine("// pn=0;    // start value for prog numbering");
      tf.WriteLine("// prog[pn]=['ProgramName'];");
      tf.WriteLine("// uid[pn]=['APP1'];");
      tf.WriteLine("// desc[pn]=['Description'];");
      tf.WriteLine("// ordr[pn]=[0];");
      tf.WriteLine("// dflt[pn]=['no'];");
      tf.WriteLine("// forc[pn]=['false'];");
      tf.WriteLine("// cat[pn]=['Application Category'];");
      tf.WriteLine("// configs[pn]=['List of configs to be auto checked. Comma seperated'];");
      tf.WriteLine("// cmds[pn]=['Command Lines'];");
      tf.WriteLine("// deps[pn]=['List of items dependant on this item'];");
      tf.WriteLine("// excl[pn]=['List of items to exclude'];");
      tf.WriteLine("// cond[pn]=['Javascript Conditional Statement'];");
      tf.WriteLine("// gcond[pn]=['Javascript Conditional Statement to gray item'];");
      tf.WriteLine("// picf[pn]=['Picture File'];");
      tf.WriteLine("// picw[pn]=['Width'];");
      tf.WriteLine("// pich[pn]=['Height'];");
      tf.WriteLine("// textl[pn]=['Text Location'];");
      tf.WriteLine("// pn++;");
      tf.WriteLine("");
      tf.WriteLine("//---------------------------------------------------------------------------------------------");
      tf.WriteLine("// Your programs here ...");
      tf.WriteLine("//---------------------------------------------------------------------------------------------");
      tf.WriteLine("pn=1;");

      for (var i = 0; i < configList.length && configList[i] != null;
      i ++ )
      {
         WriteConfigValue(tf, "prog", configList[i].prog, 0);

         txt = GetConfigValue(configList[i].uid, 0);
         txt = txt.replace(/ */g, "");
         WriteConfigValue(tf, "uid", txt, 1);

         WriteConfigValue(tf, "desc", configList[i].desc, 0);
         WriteConfigValue(tf, "ordr", configList[i].ordr, 1);
         WriteConfigValue(tf, "dflt", configList[i].dflt, 0);
         WriteConfigValue(tf, "forc", configList[i].forc, 0);
         WriteConfigValue(tf, "cat", configList[i].cat, 0);
         WriteConfigValue(tf, "configs", configList[i].configs, 0);

         Commands.splice(0, Commands.length);

         if (configList[i].regb != null)
         {
            configList[i].regb = configList[i].regb.replace(/\\/g,"\\\\").replace(/'/g,"\\'");
            Commands.splice(Commands.length, 0, "{REGEDIT} " + configList[i].regb);
         }
         if (configList[i].cmd1 != null)
         {
            configList[i].cmd1 = UpdateCommand(configList[i].cmd1);
            configList[i].cmd1 = configList[i].cmd1.replace(/\\/g,"\\\\").replace(/'/g,"\\'");
            Commands.splice(Commands.length, 0, configList[i].cmd1);
         }
         if (configList[i].cmd2 != null)
         {
            configList[i].cmd2 = UpdateCommand(configList[i].cmd2);
            configList[i].cmd2 = configList[i].cmd2.replace(/\\/g,"\\\\").replace(/'/g,"\\'");
            Commands.splice(Commands.length, 0, configList[i].cmd2);
         }
         if (configList[i].cmd3 != null)
         {
            configList[i].cmd3 = UpdateCommand(configList[i].cmd3);
            configList[i].cmd3 = configList[i].cmd3.replace(/\\/g,"\\\\").replace(/'/g,"\\'");
            Commands.splice(Commands.length, 0, configList[i].cmd3);
         }
         if (configList[i].cmd4 != null)
         {
            configList[i].cmd4 = UpdateCommand(configList[i].cmd4);
            configList[i].cmd4 = configList[i].cmd4.replace(/\\/g,"\\\\").replace(/'/g,"\\'");
            Commands.splice(Commands.length, 0, configList[i].cmd4);
         }
         if (configList[i].cmd5 != null)
         {
            configList[i].cmd5 = UpdateCommand(configList[i].cmd5);
            configList[i].cmd5 = configList[i].cmd5.replace(/\\/g,"\\\\").replace(/'/g,"\\'");
            Commands.splice(Commands.length, 0, configList[i].cmd5);
         }
         if (configList[i].cmd6 != null)
         {
            configList[i].cmd6 = UpdateCommand(configList[i].cmd6);
            configList[i].cmd6 = configList[i].cmd6.replace(/\\/g,"\\\\").replace(/'/g,"\\'");
            Commands.splice(Commands.length, 0, configList[i].cmd6);
         }
         if (configList[i].cmd7 != null)
         {
            configList[i].cmd7 = UpdateCommand(configList[i].cmd7);
            configList[i].cmd7 = configList[i].cmd7.replace(/\\/g,"\\\\").replace(/'/g,"\\'");
            Commands.splice(Commands.length, 0, configList[i].cmd7);
         }
         if (configList[i].cmd8 != null)
         {
            configList[i].cmd8 = UpdateCommand(configList[i].cmd8);
            configList[i].cmd8 = configList[i].cmd8.replace(/\\/g,"\\\\").replace(/'/g,"\\'");
            Commands.splice(Commands.length, 0, configList[i].cmd8);
         }
         if (configList[i].cmd9 != null)
         {
            configList[i].cmd9 = UpdateCommand(configList[i].cmd9);
            configList[i].cmd9 = configList[i].cmd9.replace(/\\/g,"\\\\").replace(/'/g,"\\'");
            Commands.splice(Commands.length, 0, configList[i].cmd9);
         }
         if (configList[i].cmd10 != null)
         {
            configList[i].cmd10 = UpdateCommand(configList[i].cmd10);
            configList[i].cmd10 = configList[i].cmd10.replace(/\\/g,"\\\\").replace(/'/g,"\\'");
            Commands.splice(Commands.length, 0, configList[i].cmd10);
         }
         if (configList[i].rega != null)
         {
            configList[i].rega = configList[i].rega.replace(/\\/g,"\\\\").replace(/'/g,"\\'");
            Commands.splice(Commands.length, 0, "{REGEDIT} " + configList[i].rega);
         }

         if (Commands.length > 0)
         tf.WriteLine("cmds[pn]=['" + Commands.join("','") + "'];");
         else
         tf.WriteLine("cmds[pn]=[''];");

         txt = GetConfigValue(configList[i].deps, 0);
         if (txt != "''")
         {
            txt = txt.replace(/ */g, "");
            txt = txt.replace(/'/g,",");
            txt = txt.replace(/,,/g, ",");
            txt = txt.replace(/,/g, "','");
            txt = txt.replace(/^',/,"").replace(/,'$/, "");
            WriteConfigValue(tf, "deps", txt, 1);
         }

         txt = GetConfigValue(configList[i].excl, 0);
         if (txt != "''")
         {
            txt = txt.replace(/ */g, "");
            txt = txt.replace(/'/g,",");
            txt = txt.replace(/,,/g, ",");
            txt = txt.replace(/,/g, "','");
            txt = txt.replace(/^',/,"").replace(/,'$/, "");
            WriteConfigValue(tf, "excl", txt, 1);
         }

         WriteConfigValue(tf, "cond", configList[i].cond, 0);
         WriteConfigValue(tf, "gcond", configList[i].gcond, 0);
         WriteConfigValue(tf, "picf", configList[i].picf, 0);
         WriteConfigValue(tf, "picw", configList[i].picw, 0);
         WriteConfigValue(tf, "pich", configList[i].pich, 0);
         WriteConfigValue(tf, "textl", configList[i].textl, 0);

         tf.WriteLine("pn++;");
         tf.WriteLine("");
      }
      tf.WriteLine("//---------------------------------------------------------------------------------------------");
      tf.WriteLine("// End of program definitions ...");
      tf.WriteLine("//---------------------------------------------------------------------------------------------");
   }
   catch(ex)
   {
      alert(getText(errCouldNotSaveFile) + "\n\n" + getText(lblFile) + ": " + strFile + "\n" + getText(lblErrorNumber) + ": " + (ex.number & 0xffff) + "\n" + getText(lblErrorDescription) + ": " + ex.description);

      return;
   }
   finally
   {
      try
      {
         tf.Close();
      }
      catch (ex0)
      {
         ;

      }
   }
}
