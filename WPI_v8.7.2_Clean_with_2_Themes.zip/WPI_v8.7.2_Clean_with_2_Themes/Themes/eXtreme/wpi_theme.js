// WPI Theme Options 8.0.0+
//
// User defined theme options
//


// Background color
Theme_BGColor="";

// What to do with background image
// repeat, no-repeat, repeat-x, repeat-y, stretch
// Use repeat if using a small pattern image
Theme_BackgroundRepeat="stretch";

// top, left, center, right, bottom.  and any combonation
// Must also set: Theme_BackgroundRepeat="no-repeat";
Theme_BackgroundPosition="";

//-------------------------------------------------------------------------

// Title background height
Theme_TitleBGHeight=44;

// Title bar background color
Theme_TitleBGColor="#003399";

// If titlebg.png exists, repeat pattern to fill entire bar?
// repeat, no-repeat, repeat-x, repeat-y
Theme_TitleBGImageRepeat="repeat";

// If title.png exists, specify width and height
// If want no image or text, copy title.png from /Common/imgs/, width and height of 0
// Title image width
Theme_TitleImageWidth=322;

// Title image height
Theme_TitleImageHeight=44;

// Align title image where?
// left, center, right
Theme_TitleImageAlign="center";

//-------------------------------------------------------------------------

// If title.png does not exist, text will be used
Theme_TitleTextColor="#ffffff";
Theme_TitleTextFont="Arial";
Theme_TitleTextSize="1.5em";
Theme_TitleTextWeight="bold";
Theme_TitleTextStyle="";
Theme_TitleTextAlign="center";

//-------------------------------------------------------------------------

// If smallbart.png exists, specify height.  Width is automatic
Theme_SmallBarTHeight=3;

//-------------------------------------------------------------------------

// Show text for side panel buttons (Begin Install, Options, Config...)
Theme_ShowButtonText=true;

//-------------------------------------------------------------------------

// Side bar background color if not using side.png
Theme_SidePanelBGColor="";

// If side.png exists, specify width.  Height is automatic
// Side panel width
Theme_SidePanelWidth=200;

// If sidepanel.png exists, repeat pattern to fill entire panel?
// repeat, no-repeat, repeat-x, repeat-y
Theme_SidePanelBGImageRepeat="repeat";

//-------------------------------------------------------------------------

// Main panel background color if not using MainPanel.png
Theme_MainPanelBGColor="";

// If sidepanel.png exists, repeat pattern to fill entire panel?
// repeat, no-repeat, repeat-x, repeat-y
Theme_MainPanelBGImageRepeat="repeat";

//-------------------------------------------------------------------------

// If logo.png exists, specify width and height
// Logo image width
Theme_LogoImageWidth=288;

// Logo image height
Theme_LogoImageHeight=432;

// Logo pixels from right edge
Theme_LogoImageRight=25;

// Logo pixels from bottom
Theme_LogoImageBottom=25;

//-------------------------------------------------------------------------

// If smallbarb.png exists, specify height.  Width is automatic
Theme_SmallBarBHeight=3;

//-------------------------------------------------------------------------

// Bottom background height
Theme_BottomBGHeight=84;

// Bottom bar background color
Theme_BottomBGColor="#003399";

// If bottombg.png exists, repeat pattern to fill entire bar?
// repeat, no-repeat, repeat-x, repeat-y
Theme_BottomBGImageRepeat="repeat";

// If bottom.png exists, will centered on bottom bar
// Bottom image width
Theme_BottomImageWidth=0;

// Bottom image height
Theme_BottomImageHeight=0;

//-------------------------------------------------------------------------

// If bottom.png does not exist, text will be used if specified
Theme_BottomTextColor="#ffffff";
Theme_BottomTextFont="Eurostile";
Theme_BottomTextSize="1em";
Theme_BottomTextWeight="bold";
Theme_BottomTextStyle="";
Theme_BottomTextAlign="center";
Theme_BottomText="";

//-------------------------------------------------------------------------

// Location of Exit button
// left or right
Theme_ExitButtonLocation="right";

// Show exit text or not.
Theme_ShowExitButtonText=false;


//=========================================================================


// What to do with installer background image
// repeat, stretch
// Use repeat if using a small pattern image
// You must set this item and the actual repeat style in installer.css under .Background
Installer_BackgroundRepeat="stretch";


//=========================================================================


// Set your custom number of items per column.  Can be negative number
maxentries += -3;

// Toggle showing the percent value, ie: 75%, in the install progress bar
ShowPercentValue=false;

// Toggle showing tool tips
//ShowToolTips=true;
