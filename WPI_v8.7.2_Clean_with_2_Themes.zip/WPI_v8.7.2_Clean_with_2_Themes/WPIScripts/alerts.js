//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// alerts.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

function Alert(title, message, buttons, defaultInput, type, timeout, extraWidth, extraHeight)
{
   // type : 1 = plain, 2 = error, 3 = warning, 4 = success, 5 = prompt, 6 = input
   // buttons : 1, 2, 3, ...., 0   1 = OK, 0 = Cancel
   position = "alerts.js";
   whatfunc = "Alert()";

   var Message = new String(message);
   var TempButtons = new String(buttons);
   var alertWidth, alertHeight;
   var messBox = "";
   var btns = [];
   var imgPath;

   alertWidth = 350;
   if (type != 6)
   alertHeight = 170;
   else
   alertHeight = 155;
   if (timeout > 0 && type != 6)
   alertHeight += 20;

   if (TempButtons.indexOf("|") != - 1)
   btns = TempButtons.split("|");
   else
   btns[0] = getText(lblOK);

   alertTitle = title;
   if (alertTitle == "")
   alertTitle = "Windows Post-Install Wizard";

   if (timeout > 0)
   alertTimer = timeout;

   if (timeout == - 1)
   DoCancelPause = false;
   else
   DoCancelPause = true;

   try
   {
      dhxWins.window(BlockWindow).setModal(false);
   }
   catch(ex)
   {
      ;

   }

   AlertWindow = dhxWins.createWindow("AlertWindow", 50, 50, alertWidth + extraWidth, 83);
   AlertWindow.setText(alertTitle);
   AlertWindow.setModal(true);
   AlertWindow.button("close").hide();
   AlertWindow.button("park").hide();
   AlertWindow.button("minmax1").hide();
   AlertWindow.denyPark();
   AlertWindow.denyResize();
   AlertWindow.keepInViewport(true);
   AlertWindow.center();

   OldActiveWindow = ActiveWindow;
   ActiveWindow = AlertWindow.getText();

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layeralert";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "10 10 10 5";

   imgPath = "../Common/imgs/";

   if (type != 6)
   {
      messBox = '<table border="0" width="100%" height="100%" cellspacing="2" cellpadding="0"><tr>';
      messBox += '<td valign="top"><div id="AlertMessage" class="'+(isInstaller ? "InstallText" : "opTxt")+'" style="padding:0 0 0 5;"></div></td>';
      messBox += '<td><div style="width:10px; height:10px; display:inline; font-size:1px;"></div></td>';
      messBox += '</tr>';
      if (buttons != "---none---")
      {
         messBox += '<tr><td><div style="width:10px; height:20px; display:inline; font-size:1px;"></div></td><td></td></tr>';
         messBox += '<tr><td style="vertical-align:bottom; height:100%;">';
         messBox += '<table border="0" cellpadding="2" cellspacing="0"><tr>';
         for (var i = 1; i <= btns.length; i ++ )
         messBox += '<td><a id="Button'+i+'" class="button" href="#" onMouseOut="this.blur();" onClick="this.blur(); CloseAlert('+((i==btns.length && btns.length>1) ? 0 : i)+');"><span><div id="Text'+((i==btns.length && btns.length>1) ? '0' : i)+'" class="buttonTxt"></div></span></a></td>';
         messBox += '</tr></table>';
         messBox += '</td><td></td></tr>';
      }
      if (timeout > 0)
      {
         messBox += '<tr><td><div style="width:1px; height:10px; display:inline; font-size:1px;"></div></td></tr>';
         messBox += '<tr><td><font style="font-size:3px;"><img src="'+imgPath+'BWline.gif" border="0" width="100%" height="2" align="absbottom"></font></td></tr>';
         messBox += '<tr><td><div id="AutoCloseMessage" class="opTxt" style="width:100%; align:left;"></div></td></tr>';
      }
      messBox += '</table>';
   }
   else
   {
      messBox = '<table border="0" width="100%" height="100%" cellspacing="2" cellpadding="0"><tr>';
      messBox += '<td width="100%"></td><td></td>';
      messBox += '</tr><tr>';
      messBox += '<td valign="top"><div id="AlertMessage" class="'+(isInstaller ? "InstallText" : "opTxt")+'" style="padding:0 0 0 5;"></div></td>';
      messBox += '<td valign="top">';
      messBox += '<table border="0" cellpadding="2" cellspacing="0">';
      for (var i = 1; i <= btns.length; i ++ )
      messBox += '<tr><td><a id="Button'+i+'" class="button" href="#" onMouseOut="this.blur();" onClick="this.blur(); CloseAlert('+((i==btns.length && btns.length>1) ? 0 : i)+');"><span><div id="Text'+((i==btns.length && btns.length>1) ? '0' : i)+'" class="buttonTxt"></div></span></a></td></tr>';
      messBox += '</table>';
      messBox += '</td></tr><tr>';
      messBox += '<td colspan="2" style="padding:0 0 0 5;">';
      messBox += '<input id="AlertStringGadget" type="text" class="opTextBox" style="width:100%;">';
      messBox += '</td>';
      messBox += '</tr></table>';
   }

   newDiv.innerHTML = messBox;
   objDiv.appendChild(newDiv);

   imgPath = "url('../Common/imgs/Alerts/";

   switch(type)
   {
      case 1 :
         document.getElementById("layeralert").style.backgroundImage = "";
         break;

      case 2 :
         document.getElementById("layeralert").style.backgroundImage = imgPath + "error_bg.png')";
         break;

      case 3 :
         document.getElementById("layeralert").style.backgroundImage = imgPath + "warning_bg.png')";
         break;

      case 4 :
         document.getElementById("layeralert").style.backgroundImage = imgPath + "success_bg.png')";
         break;

      case 5 :
         document.getElementById("layeralert").style.backgroundImage = imgPath + "prompt_bg.png')";
         break;

      case 6 :
         document.getElementById("layeralert").style.backgroundImage = imgPath + "prompt_bg.png')";
         break;
   }
   document.getElementById("layeralert").style.backgroundPosition = "bottom right";
   document.getElementById("layeralert").style.backgroundRepeat = "no-repeat";
   Message = Message.replace(/\n/gi, "<br>");
   document.getElementById("AlertMessage").innerHTML = Message;
   if (buttons != "---none---")
   {
      document.getElementById("Text1").innerHTML = getText(lblOK);
      for (var i = 1; i < btns.length - 1; i ++ )
      document.getElementById("Text" + (i + 1)).innerHTML = btns[i];
      if (document.getElementById("Text0") != null)
      document.getElementById("Text0").innerHTML = getText(lblCancel);
   }

   if (type == 6)
   document.getElementById("AlertStringGadget").value = defaultInput;

   AlertWindow.attachObject("layeralert");
   document.getElementById("layeralert").style.display = 'block';

   AutoSizeWindow(AlertWindow, "layeralert");

   if (timeout > 0 && type != 6)
   {
      document.getElementById("AutoCloseMessage").innerHTML = getText(txtWindowAutoClose1) + " " + timeout + " " + getText(txtWindowAutoClose2);

      interval = window.setInterval("CloseAlert(1)", timeout * 1000);
   }

   if (buttons != "---none---")
   {
      document.getElementById("Button1").focus();
      // Required
      document.getElementById("Button1").blur();
      // Required
   }

   if (type != 6)
   PlaySound(ReplacePath(alertSound));

   if (timeout == - 1)
   return;

   Pause(604800, 0);

   if (type != 6)
   return alertButton;
   // Yes, here, not CloseAlert()
   else
   return alertText;
}

function CountDownAlert()
{
   position = "alerts.js";
   whatfunc = "CountDownAlert()";

   alertTimer -- ;

   if (alertTimer == 1)
   CloseAlert(1);
}

function CloseAlert(button)
{
   position = "alerts.js";
   whatfunc = "CloseAlert()";

   if (dhxWins.isWindow("AlertWindow"))
   {
      window.clearInterval(interval);

      if (document.getElementById("AlertStringGadget") != null && button != 0)
      alertText = document.getElementById("AlertStringGadget").value;
      else
      alertText = null;

      alertButton = button;

      AlertWindow.close();
      AlertWindow = null;

      ActiveWindow = OldActiveWindow;

      try
      {
         dhxWins.window(BlockWindow).setModal(true);
      }
      catch(ex)
      {
         ;

      }
   }

   if (DoCancelPause)
   CancelPause();
}
