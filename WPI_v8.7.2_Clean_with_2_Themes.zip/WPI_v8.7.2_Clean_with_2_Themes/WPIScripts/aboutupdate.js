//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// aboutupdate.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

function ToggleAboutWPI()
{
   position = "aboutupdate.js";
   whatfunc = "ToggleAboutWPI()";

   if (OptionsWizardOpen || ConfigWizardOpen || NetworkWizardOpen)
   return;
   if ( ! dhxWins.isWindow("AboutWindow"))
   ShowAboutWPI();
   else
   AboutWindow.bringToTop();
}

function ShowAboutWPI()
{
   position = "aboutupdate.js";
   whatfunc = "ShowAboutWPI()";

   AboutWindow = dhxWins.createWindow("AboutWindow", 50, 50, 610, 455);
   AboutWindow.setText(getText(lblAboutWPI));
   AboutWindow.setModal(true);
   AboutWindow.button("park").hide();
   AboutWindow.button("minmax1").hide();
   AboutWindow.button("close").hide();
   AboutWindow.denyResize();
   AboutWindow.denyPark();
   AboutWindow.center();

   OldActiveWindow = ActiveWindow;
   ActiveWindow = AboutWindow.getText();

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layerabout";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "10px";

   objDiv.appendChild(newDiv);

   AboutWindow.attachObject("layerabout");
   document.getElementById("layerabout").style.display = 'block';

   CreateTab("\\Common\\aboutwpitemplate.htm", "layerabout");
   CreateTab("\\Common\\aboutwpitemplate_version.htm", "tabtabVersion");
   CreateTab("\\Common\\aboutwpitemplate_projectteam.htm", "tabtabProjectTeam");
   CreateTab("\\Common\\aboutwpitemplate_links.htm", "tabtabLinks");
   CreateTab("\\Common\\aboutwpitemplate_license.htm", "tabtabLicense");
   CreateTab("\\Common\\aboutwpitemplate_changelog.htm", "tabtabChangeLog");

   AboutTabs = new dhtmlXTabBar("AboutTabs", "top");
   AboutTabs.setImagePath("../Common/codebase/imgs/");
   AboutTabs.setStyle(dhxSkin);
   AboutTabs.setSkinColors(null, "#f0f0f0", null);
   AboutTabs.enableForceHiding(true);
   var tablist = new Array('tabVersion', 'tabProjectTeam', 'tabLinks', 'tabLicense', 'tabChangeLog');
   for (var i = 0; i < tablist.length; i ++ )
   {
      AboutTabs.addTab("Tab" + (i + 1).toString(), getText(eval(tablist[i])), "" + Math.round((parseInt(document.getElementById("AboutTabs").offsetWidth) - 16) / tablist.length) + "px");
   }

   document.getElementById("legAboutVersion").innerHTML = getText(legVersion);
   document.getElementById("lblAboutVersion").innerHTML = getText(legVersion) + ":&nbsp;";
   document.getElementById("About_Version").innerHTML = ShortVersion;
   document.getElementById("lblAboutReleased").innerHTML = getText(lblReleased) + ":&nbsp;";
   document.getElementById("About_Released").innerHTML = ReleaseDate;
   document.getElementById("legAboutDonations").innerHTML = getText(legDonations);
   document.getElementById("legAboutUpdate").innerHTML = getText(lblUpdate);
   document.getElementById("CheckForUpdate").innerHTML = getText(txtCheckForUpdate);
   document.getElementById("legAboutProjectTeam").innerHTML = getText(tabProjectTeam);
   document.getElementById("legAboutLinks").innerHTML = getText(tabLinks);
   document.getElementById("lblAboutHomePage").innerHTML = getText(lblHomePage);
   document.getElementById("lblAboutForum1").innerHTML = getText(lblForum);
   document.getElementById("lblAboutForum2").innerHTML = getText(lblForum);
   document.getElementById("lblAboutEMail1").innerHTML = getText(lblEMail);
   document.getElementById("legLicense").innerHTML = getText(lblLicense);
   document.getElementById("legChangeLog").innerHTML = getText(tabChangeLog);
   document.getElementById("lblOK").innerHTML = getText(lblOK);

   var txt = new String();
   txt = "";
   strFile = wpipath + "\\ChangeLog.txt";
   if (FileExists(strFile))
   {
      try
      {
         tf = fso.OpenTextFile(strFile, 1);
         while ( ! tf.AtEndOfStream)
         txt = tf.ReadAll();
      }
      catch(ex)
      {
         ;

      }
      finally
      {
         tf.Close();
      }
   }
   else
   txt = "n/a";
   txt = txt.replace(/\n/gi, "<br>");
   document.getElementById("ChangeLog").innerHTML = txt;

   for (var i = 0; i < tablist.length; i ++ )
   {
      AboutTabs.setContent("Tab" + (i + 1).toString(), "tab" + tablist[i]);
   }

   AboutTabs.setTabActive("Tab1");
}

function HideAboutWPI()
{
   position = "aboutupdate.js";
   whatfunc = "HideAboutWPI()";

   if (dhxWins.isWindow("AboutWindow"))
   {
      AboutWindow.close();
      AboutWindow = null;
   }

   ActiveWindow = OldActiveWindow;
}

function ShowUpdate()
{
   position = "aboutupdate.js";
   whatfunc = "ShowUpdate()";

   if (dhxWins.isWindow("UpdateWindow"))
   {
      UpdateWindow.bringToTop();

      return;
   }

   UpdateWindow = dhxWins.createWindow("UpdateWindow", 25, 25, 600, 405);
   UpdateWindow.setText(getText(lblUpdateWPI));
   UpdateWindow.setModal(true);
   UpdateWindow.button("park").hide();
   UpdateWindow.button("minmax1").hide();
   UpdateWindow.button("close").hide();
   UpdateWindow.denyResize();
   UpdateWindow.center();

   OldActiveWindow = ActiveWindow;
   ActiveWindow = UpdateWindow.getText();

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layerupdate";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "10px";

   objDiv.appendChild(newDiv);

   var txt = new String();
   txt = "";

   strFile = wpipath + "\\Common\\updatewpi.htm";
   if ( ! FileExists(strFile))
   {
      Alert("", getText(errCouldNotOpenFile) + " '"+strFile+"'.", getText(lblOK), "", 2, 0, 0, 0);
      HideUpdate();
   }
   try
   {
      tf = fso.OpenTextFile(strFile, 1);
      while ( ! tf.AtEndOfStream)
      txt = tf.ReadAll();
   }
   catch(ex)
   {
      ;

   }
   finally
   {
      tf.Close();
   }

   UpdateWindow.attachObject("layerupdate");
   document.getElementById("layerupdate").style.display = 'block';
   document.getElementById("layerupdate").innerHTML = txt;
   document.getElementById("legVersion").innerHTML = getText(legVersion);
   document.getElementById("txtInstalledVersion").innerHTML = getText(txtInstalledVersion);
   document.getElementById("InstalledVersion").innerHTML = ShortVersion;
   document.getElementById("txtLatestVersion").innerHTML = getText(txtLatestVersion);
   document.getElementById("legNotes").innerHTML = getText(legNotes);
   document.getElementById("legMD5").innerHTML = getText(lblMD5);
   document.getElementById("DownloadUpdate").innerHTML = getText(lblUpdate);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);
   document.getElementById("Btn_DownloadUpdate").disabled = true;
}

function FillInUpdate()
{
   position = "aboutupdate.js";
   whatfunc = "FillInUpdate()";

   document.getElementById("LatestVersion").innerHTML = UpdateVersion;
   document.getElementById("Notes").innerHTML = "<pre>" + UpdateTitle + "\n<hr>\n" + UpdateNotes + "</pre>";
   document.getElementById("MD5").value = UpdateMD5;
   document.getElementById("DownloadLink").href = UpdateLink;
}

function HideUpdate()
{
   position = "aboutupdate.js";
   whatfunc = "HideUpdate()";

   if (dhxWins.isWindow("UpdateWindow"))
   {
      UpdateWindow.close();
      UpdateWindow = null;
   }

   ActiveWindow = OldActiveWindow;
}

function CheckForUpdate()
{
   position = "aboutupdate.js";
   whatfunc = "CheckForUpdate()";

   UpdateAvailable = false;
   ShowUpdate();

   if ( ! loadXMLDoc("http://www.wpiw.net/downloads/wpi.xml", ExtractUpdateInfo))
   {
      alert(getText(txtUpdateError));
      HideUpdate();

      return;
   }

   Pause(2, 0);

   UpdateAvailable = fileVersionGreaterThan(UpdateVersion, ShortVersion);

   FillInUpdate();
   document.getElementById("Btn_DownloadUpdate").disabled = ! UpdateAvailable;
   // The opposite
}

function ExtractUpdateInfo(loader)
{
   position = "aboutupdate.js";
   whatfunc = "ExtractUpdateInfo()";

   var items;

   items = loader.xmlDoc.responseXML.getElementsByTagName("item");

   for (var i = 0; i < items.length; i ++ )
   {
      UpdateVersion = getElementTextNS("", "version", items[i], 0);
      UpdateLink = getElementTextNS("", "link", items[i], 0);
      UpdateMD5 = getElementTextNS("", "md5", items[i], 0);
      UpdateTitle = getElementTextNS("", "title", items[i], 0);
      UpdateNotes = getElementTextNS("", "notes", items[i], 0);
   }
}

function DownloadUpdate()
{
   position = "aboutupdate.js";
   whatfunc = "DownloadUpdate()";

   if (UpdateAvailable)
   document.getElementById("DownloadLink").click();
}
