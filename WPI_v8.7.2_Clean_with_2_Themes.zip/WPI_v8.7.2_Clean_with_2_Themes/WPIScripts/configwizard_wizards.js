//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

function ShowCreateShortcut()
{
   position = "configwizard_wizards.js";
   whatfunc = "ShowCreateShortcut()";

   dhxWins.window("ConfigWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 475, 125);
   SubWizardWindow.setText(getText(lblCreateShortcut));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\configwizardtemplate_createshortcut.htm", "layersubwizard");

   document.getElementById("legCreateShortcut").innerHTML = getText(lblCreateShortcut);
   document.getElementById("lblDescription").innerHTML = getText(lblDescription);
   document.getElementById("Description").value = getText(lblShortcutTo) + " ";
   document.getElementById("lblIconLocation").innerHTML = getText(lblIconLocation);
   document.getElementById("lblHotkey").innerHTML = getText(lblHotkey);
   document.getElementById("lblTargetPath").innerHTML = getText(lblTargetPath);
   document.getElementById("lblArguments").innerHTML = getText(lblArguments);
   document.getElementById("lblDestination").innerHTML = getText(lblDestination);
   document.getElementById("lblFolder").innerHTML = getText(lblFolder);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);

   var opt = document.getElementById("Destination").getElementsByTagName("OPTGROUP");
   opt[0].label = getText(grpCurrentUser);
   opt[1].label = getText(grpAllUsers);
   with (document.getElementById("Destination"))
   {
      options[0].text = getText(optDesktop);
      options[1].text = getText(optFavorites);
      options[2].text = getText(optMyDocuments);
      options[3].text = getText(optQuickLaunch);
      options[4].text = getText(optStartMenu);
      options[5].text = getText(optStartMenuPrograms);
      options[6].text = getText(optStartup);
      options[7].text = getText(optDesktop);
      options[8].text = getText(optStartMenu);
      options[9].text = getText(optStartMenuPrograms);
      options[10].text = getText(optStartup);
   }

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   AutoSizeWindow(SubWizardWindow, "layersubwizard");

   document.getElementById("Description").focus();
   moveCaretToEnd(this.document.all.Description);
}

function HideCreateShortcut(ok)
{
   position = "configwizard_wizards.js";
   whatfunc = "HideCreateShortcut()";

   if (ok)
   {
      var txt;

      txt = '{JSCRIPT}=CreateShortcut(';
      txt += '"'+document.getElementById("Description").value+'"';
      txt += ',"'+document.getElementById("IconLocation").value+'"';
      txt += ',"'+document.getElementById("Hotkey").value+'"';
      txt += ',"'+document.getElementById("TargetPath").value+'"';
      txt += ',"'+document.getElementById("Arguments").value.replace(/\"/gi, '#quote#') + '"';
      txt += ',"'+document.getElementById("Destination").value+'"';
      txt += ',"'+document.getElementById("Folder").value+'"';
      txt += ')';

      HandleCommandsSelectionMenu(txt);

      ConfigUpdated();
   }

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = ConfigWindow.getText();
   dhxWins.window("ConfigWindow").setModal(true);
}

function clearIconLocationBrowse()
{
   position = "configwizard_wizards.js";
   whatfunc = "clearIconLocationBrowse()";

   document.getElementById("div_IconLocationBrowse").innerHTML = "";
   document.getElementById("div_IconLocationBrowse").innerHTML = '<input id="IconLocationBrowse" type="file" style="display:none;">';
}

function SetIconLocationPath()
{
   position = "configwizard_wizards.js";
   whatfunc = "SetIconLocationPath()";

   if (document.getElementById("IconLocationBrowse").value != "")
   document.getElementById("IconLocation").value = document.getElementById("IconLocationBrowse").value;
}

function clearTargetPathBrowse()
{
   position = "configwizard_wizards.js";
   whatfunc = "clearTargetPathBrowse()";

   document.getElementById("div_TargetPathBrowse").innerHTML = "";
   document.getElementById("div_TargetPathBrowse").innerHTML = '<input id="TargetPathBrowse" type="file" style="display:none;">';
}

function SetTargetPathPath()
{
   position = "configwizard_wizards.js";
   whatfunc = "SetTargetPathPath()";

   if (document.getElementById("TargetPathBrowse").value != "")
   document.getElementById("TargetPath").value = document.getElementById("TargetPathBrowse").value;
}

function HandleCreateShortcutDestination()
{
   position = "configwizard_wizards.js";
   whatfunc = "HandleCreateShortcutDestination()";

   var val;

   val = document.getElementById("Destination").value;

   if (val == "Favorites")
   {
      document.getElementById("Arguments").value = "";
      document.getElementById("Arguments").disabled = true;
   }

   document.getElementById("Folder").value = "";
   if (val == "Favorites" || val == "MyDocuments" || val == "StartMenu" || val == "Programs" || val == "AllUsersStartMenu" || val == "AllUsersPrograms")
   document.getElementById("Folder").disabled = false;
   else
   document.getElementById("Folder").disabled = true;
}

function ShowCreateWindowsUser()
{
   position = "configwizard_wizards.js";
   whatfunc = "ShowCreateWindowsUser()";

   dhxWins.window("ConfigWindow").setModal(false);
   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 430, 125);
   SubWizardWindow.setText(getText(lblCreateWindowsUser));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\configwizardtemplate_createwindowsuser.htm", "layersubwizard");

   document.getElementById("legCreateWindowsUser").innerHTML = getText(lblCreateWindowsUser);
   document.getElementById("lblUserName").innerHTML = getText(lblUserName);
   document.getElementById("lblUserPassword").innerHTML = getText(lblUserPassword);
   document.getElementById("lblConfirmPassword").innerHTML = getText(lblConfirmPassword);
   document.getElementById("lblAdministrator").innerHTML = getText(lblAdministrator);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   AutoSizeWindow(SubWizardWindow, "layersubwizard");

   document.getElementById("UserName").focus();
}

function HandleCWUConfirmPassword()
{
   position = "networkwizard.js";
   whatfunc = "HandleCWUConfirmPassword()";

   if (document.getElementById("UserPassword").value != document.getElementById("ConfirmPassword").value)
   {
      BlockWindow = "SubWizardWindow";
      Alert("", getText(txtPasswordsDontMatch), getText(lblOK), "", 2, 0, 0, 0);
      document.getElementById("UserPassword").value = "";
      document.getElementById("ConfirmPassword").value = "";
      document.getElementById("UserPassword").focus();
   }
}

function HideCreateWindowsUser(ok)
{
   position = "configwizard_wizards.js";
   whatfunc = "HideCreateWindowsUser()";

   if (ok)
   {
      var txt;

      txt = '{JSCRIPT}=CreateWindowsUser(';
      txt += '"'+document.getElementById("UserName").value+'"';
      txt += ',"'+document.getElementById("UserPassword").value+'"';
      txt += ',' + (document.getElementById("Administrator").checked ? "true" : "false") + '';
      txt += ')';

      HandleCommandsSelectionMenu(txt);

      ConfigUpdated();
   }

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = ConfigWindow.getText();
   dhxWins.window("ConfigWindow").setModal(true);
}

function ShowDeleteWindowsUser()
{
   position = "configwizard_wizards.js";
   whatfunc = "ShowDeleteWindowsUser()";

   dhxWins.window("ConfigWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 430, 125);
   SubWizardWindow.setText(getText(lblDeleteWindowsUser));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\configwizardtemplate_deletewindowsuser.htm", "layersubwizard");

   document.getElementById("legDeleteWindowsUser").innerHTML = getText(lblDeleteWindowsUser);
   document.getElementById("lblUserName").innerHTML = getText(lblUserName);
   document.getElementById("lblDeleteFiles").innerHTML = getText(lblDeleteFiles);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   AutoSizeWindow(SubWizardWindow, "layersubwizard");

   document.getElementById("UserName").focus();
}

function HideDeleteWindowsUser(ok)
{
   position = "configwizard_wizards.js";
   whatfunc = "HideDeleteWindowsUser()";

   if (ok)
   {
      var txt;

      txt = '{JSCRIPT}=DeleteWindowsUser(';
      txt += '"'+document.getElementById("UserName").value+'"';
      txt += ',' + (document.getElementById("DeleteFiles").checked ? "true" : "false") + '';
      txt += ')';

      HandleCommandsSelectionMenu(txt);

      ConfigUpdated();
   }

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = ConfigWindow.getText();
   dhxWins.window("ConfigWindow").setModal(true);
}

function ShowSetFirewall()
{
   position = "configwizard_wizards.js";
   whatfunc = "ShowSetFirewall()";

   dhxWins.window("ConfigWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 300, 125);
   SubWizardWindow.setText(getText(lblSetFirewall));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\configwizardtemplate_setfirewall.htm", "layersubwizard");

   document.getElementById("legSetFirewall").innerHTML = getText(legSetFirewall);
   document.getElementById("lblEnabled").innerHTML = getText(lblEnabled);
   document.getElementById("lblDisabled").innerHTML = getText(lblDisabled);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   AutoSizeWindow(SubWizardWindow, "layersubwizard");
}

function HideSetFirewall(ok)
{
   position = "configwizard_wizards.js";
   whatfunc = "HideSetFirewall()";

   if (ok)
   {
      var txt;

      txt = '{JSCRIPT}=SetFirewall(';
      txt += (document.getElementById("FirewallEnabled").checked ? "true" : "false");
      txt += ')';

      HandleCommandsSelectionMenu(txt);

      ConfigUpdated();
   }

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = ConfigWindow.getText();
   dhxWins.window("ConfigWindow").setModal(true);
}

function ShowSetFilePrinterSharing()
{
   position = "configwizard_wizards.js";
   whatfunc = "ShowSetFilePrinterSharing()";

   dhxWins.window("ConfigWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 300, 125);
   SubWizardWindow.setText(getText(lblSetFilePrinterSharing));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\configwizardtemplate_setfileprintersharing.htm", "layersubwizard");

   document.getElementById("legSetFilePrinterSharing").innerHTML = getText(legSetFilePrinterSharing);
   document.getElementById("lblEnabled").innerHTML = getText(lblEnabled);
   document.getElementById("lblDisabled").innerHTML = getText(lblDisabled);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   AutoSizeWindow(SubWizardWindow, "layersubwizard");
}

function HideSetFilePrinterSharing(ok)
{
   position = "configwizard_wizards.js";
   whatfunc = "HideSetFilePrinterSharing()";

   if (ok)
   {
      var txt;

      txt = '{JSCRIPT}=SetFilePrinterSharing(';
      txt += (document.getElementById("FilePrinterSharingEnabled").checked ? "true" : "false");
      txt += ')';

      HandleCommandsSelectionMenu(txt);

      ConfigUpdated();
   }

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = ConfigWindow.getText();
   dhxWins.window("ConfigWindow").setModal(true);
}

function ShowMapNetworkDrive()
{
   position = "configwizard_wizards.js";
   whatfunc = "ShowMapNetworkDrive()";

   dhxWins.window("ConfigWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 400, 125);
   SubWizardWindow.setText(getText(lblMapNetworkDrive));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\configwizardtemplate_mapnetworkdrive.htm", "layersubwizard");

   document.getElementById("legMapNetworkDrive").innerHTML = getText(legMapNetworkDrive);
   document.getElementById("lblDrive").innerHTML = getText(lblDrive);
   document.getElementById("lblFolder").innerHTML = getText(lblFolder);
   document.getElementById("lblReconnectAtLogon").innerHTML = getText(lblReconnectAtLogon);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   AutoSizeWindow(SubWizardWindow, "layersubwizard");
}

function HideMapNetworkDrive(ok)
{
   position = "configwizard_wizards.js";
   whatfunc = "HideMapNetworkDrive()";

   if (ok)
   {
      var txt;

      txt = '{JSCRIPT}=MapNetworkDrive(';
      txt += '"'+document.getElementById("SelectDrive").value+'"';
      txt += ',"'+document.getElementById("Folder").value+'"';
      txt += ',' + document.getElementById("ReconnectAtLogon").checked;
      txt += ')';

      HandleCommandsSelectionMenu(txt);

      ConfigUpdated();
   }

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = ConfigWindow.getText();
   dhxWins.window("ConfigWindow").setModal(true);
}

function ShowShareFolder()
{
   position = "configwizard_wizards.js";
   whatfunc = "ShowShareFolder()";

   dhxWins.window("ConfigWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 400, 125);
   SubWizardWindow.setText(getText(lblShareFolder));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\configwizardtemplate_sharefolder.htm", "layersubwizard");

   document.getElementById("legShareFolder").innerHTML = getText(legShareFolder);
   document.getElementById("lblShareName").innerHTML = getText(lblShareName);
   document.getElementById("lblSharePath").innerHTML = getText(lblSharePath);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   AutoSizeWindow(SubWizardWindow, "layersubwizard");

   document.getElementById("ShareName").focus();
}

function HideShareFolder(ok)
{
   position = "configwizard_wizards.js";
   whatfunc = "HideShareFolder()";

   if (ok)
   {
      var txt;

      txt = '{JSCRIPT}=ShareFolder(';
      txt += '"'+document.getElementById("ShareName").value+'"';
      txt += ',"'+document.getElementById("SharePath").value+'"';
      txt += ')';

      HandleCommandsSelectionMenu(txt);

      ConfigUpdated();
   }

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = ConfigWindow.getText();
   dhxWins.window("ConfigWindow").setModal(true);
}

function ShowSetPageFileSize()
{
   position = "configwizard_wizards.js";
   whatfunc = "ShowSetPageFileSize()";

   dhxWins.window("ConfigWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 325, 125);
   SubWizardWindow.setText(getText(lblSetPageFileSize));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\configwizardtemplate_setpagefilesize.htm", "layersubwizard");

   document.getElementById("legSetPageFileSize").innerHTML = getText(legSetPageFileSize);
   document.getElementById("lblDriveLetter").innerHTML = getText(lblDriveLetter);
   document.getElementById("lblInitialSize").innerHTML = getText(lblInitialSize);
   document.getElementById("lblMaximumSize").innerHTML = getText(lblMaximumSize);
   document.getElementById("lblNoPageFile").innerHTML = getText(lblNoPageFile);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   GetPageFileInfo();
   if (PF_Drive == null)
   PF_Drive = "C:";
   if (PF_InitialSize == null)
   PF_InitialSize = 768;
   if (PF_MaximumSize == null)
   PF_MaximumSize = 1536;
   document.getElementById("DriveLetter").value = PF_Drive;
   document.getElementById("InitialSize").value = PF_InitialSize;
   document.getElementById("MaximumSize").value = PF_MaximumSize;

   AutoSizeWindow(SubWizardWindow, "layersubwizard");

   document.getElementById("InitialSize").focus();
}

function HandleNoPageFile()
{
   position = "networkwizard.js";
   whatfunc = "HandleNoPageFile()";

   if (document.getElementById("NoPageFile").checked)
   {
      document.getElementById("DriveLetter").disabled = true;
      document.getElementById("InitialSize").disabled = true;
      document.getElementById("MaximumSize").disabled = true;
   }
   else
   {
      document.getElementById("DriveLetter").disabled = false;
      document.getElementById("InitialSize").disabled = false;
      document.getElementById("MaximumSize").disabled = false;
   }
}

function HideSetPageFileSize(ok)
{
   position = "configwizard_wizards.js";
   whatfunc = "HideSetPageFileSize()";

   if (ok)
   {
      var txt;

      txt = '{JSCRIPT}=SetPageFileSize(';
      txt += '"'+document.getElementById("DriveLetter").value+'"';
      txt += ',' + document.getElementById("InitialSize").value;
      txt += ',' + document.getElementById("MaximumSize").value;
      txt += ',' + (document.getElementById("NoPageFile").checked ? "true" : "false");
      txt += ')';

      HandleCommandsSelectionMenu(txt);

      ConfigUpdated();
   }

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = ConfigWindow.getText();
   dhxWins.window("ConfigWindow").setModal(true);
}

function ShowFormatDrive()
{
   position = "configwizard_wizards.js";
   whatfunc = "ShowFormatDrive()";

   dhxWins.window("ConfigWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 400, 125);
   SubWizardWindow.setText(getText(lblFormatDrive));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\configwizardtemplate_formatdrive.htm", "layersubwizard");

   document.getElementById("legFormatDrive").innerHTML = getText(legFormatDrive);
   document.getElementById("lblDriveLetter").innerHTML = getText(lblDriveLetter);
   document.getElementById("lblVolumeLabel").innerHTML = getText(lblVolumeLabel);
   document.getElementById("lblFileSystem2").innerHTML = getText(lblFileSystem2);
   document.getElementById("lblClusterSize").innerHTML = getText(lblClusterSize);
   document.getElementById("legFormatOptions").innerHTML = getText(legFormatOptions);
   document.getElementById("lblQuickFormat").innerHTML = getText(lblQuickFormat);
   document.getElementById("lblEnableCompression").innerHTML = getText(lblEnableCompression);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);
   document.getElementById("FileSystem").options[0].text = getText(optNTFS);
   document.getElementById("FileSystem").options[1].text = getText(optFAT32);
   document.getElementById("FileSystem").options[2].text = getText(optFAT);

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   AutoSizeWindow(SubWizardWindow, "layersubwizard");

   document.getElementById("VolumeLabel").focus();
}

function HideFormatDrive(ok)
{
   position = "configwizard_wizards.js";
   whatfunc = "HideFormatDrive()";

   if (ok)
   {
      var txt;

      txt = '{JSCRIPT}=FormatDrive(';
      txt += '"'+document.getElementById("DriveLetter").value+'"';
      txt += ',"'+document.getElementById("VolumeLabel").value+'"';
      txt += ',"'+document.getElementById("FileSystem").value+'"';
      txt += ',"'+document.getElementById("ClusterSize").value+'"';
      txt += ',' + (document.getElementById("QuickFormat").checked ? 'true' : 'false');
      txt += ',' + (document.getElementById("EnableCompression").checked ? 'true' : 'false');
      txt += ')';

      HandleCommandsSelectionMenu(txt);

      ConfigUpdated();
   }

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = ConfigWindow.getText();
   dhxWins.window("ConfigWindow").setModal(true);
}

function ShowSetAutoLogonUser()
{
   position = "configwizard_wizards.js";
   whatfunc = "ShowSetAutoLogonUser()";

   dhxWins.window("ConfigWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 430, 125);
   SubWizardWindow.setText(getText(lblSetAutoLogonUser));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\configwizardtemplate_setautologonuser.htm", "layersubwizard");

   document.getElementById("legSetAutoLogonUser").innerHTML = getText(lblSetAutoLogonUser);
   document.getElementById("lblUserName").innerHTML = getText(lblUserName);
   document.getElementById("lblUserPassword").innerHTML = getText(lblUserPassword);
   document.getElementById("lblDomainName").innerHTML = getText(lblDomainName);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   AutoSizeWindow(SubWizardWindow, "layersubwizard");

   document.getElementById("DomainName").value = LogOnServer.replace("\\\\", "");
   document.getElementById("UserName").focus();
}

function HideSetAutoLogonUser(ok)
{
   position = "configwizard_wizards.js";
   whatfunc = "HideSetAutoLogonUser()";

   if (ok)
   {
      var txt;

      txt = '{JSCRIPT}=SetAutoLogonUser(';
      txt += '"'+document.getElementById("UserName").value+'"';
      txt += ',"'+document.getElementById("UserPassword").value+'"';
      txt += ',"'+document.getElementById("DomainName").value+'"';
      txt += ')';

      HandleCommandsSelectionMenu(txt);

      ConfigUpdated();
   }

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = ConfigWindow.getText();
   dhxWins.window("ConfigWindow").setModal(true);
}

function ShowCreateRegKey()
{
   position = "configwizard_wizards.js";
   whatfunc = "ShowCreateRegKey()";

   dhxWins.window("ConfigWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 400, 125);
   SubWizardWindow.setText(getText(lblCreateRegKey));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\configwizardtemplate_CreateRegKey.htm", "layersubwizard");

   document.getElementById("legCreateRegKey").innerHTML = getText(legCreateRegKey);
   document.getElementById("lblValueName").innerHTML = getText(lblValueName);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   AutoSizeWindow(SubWizardWindow, "layersubwizard");

   document.getElementById("ValueName").focus();
}

function HideCreateRegKey(ok)
{
   position = "configwizard_wizards.js";
   whatfunc = "HideCreateRegKey()";

   if (ok)
   {
      var txt;

      txt = '{JSCRIPT}=CreateRegKey(';
      txt += '"'+document.getElementById("ValueName").value+'"';
      txt += ')';

      HandleCommandsSelectionMenu(txt);

      ConfigUpdated();
   }

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = ConfigWindow.getText();
   dhxWins.window("ConfigWindow").setModal(true);
}

function ShowWriteRegKey1()
{
   position = "configwizard_wizards.js";
   whatfunc = "ShowWriteRegKey1()";

   dhxWins.window("ConfigWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 400, 125);
   SubWizardWindow.setText(getText(lblWriteRegKey));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\configwizardtemplate_writeregkey1.htm", "layersubwizard");

   document.getElementById("legWriteRegKey").innerHTML = getText(legWriteRegKey);
   document.getElementById("lblValueName").innerHTML = getText(lblValueName);
   document.getElementById("lblValueData").innerHTML = getText(lblValueData);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   AutoSizeWindow(SubWizardWindow, "layersubwizard");

   document.getElementById("ValueName").focus();
}

function HideWriteRegKey1(ok)
{
   position = "configwizard_wizards.js";
   whatfunc = "HideWriteRegKey1()";

   if (ok)
   {
      var txt;

      txt = '{JSCRIPT}=WriteRegKey(';
      txt += '"'+document.getElementById("ValueName").value+'"';
      if (WriteRegType != "REG_DWORD" && WriteRegType != "REG_QWORD")
      txt += ',"'+document.getElementById("ValueData").value+'"';
      else
      txt += ',' + document.getElementById("ValueData").value;

      txt += ',"'+WriteRegType+'"';
      txt += ')';

      HandleCommandsSelectionMenu(txt);

      ConfigUpdated();
   }

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = ConfigWindow.getText();
   dhxWins.window("ConfigWindow").setModal(true);
}

function ShowWriteRegKey2()
{
   position = "configwizard_wizards.js";
   whatfunc = "ShowWriteRegKey2()";

   dhxWins.window("ConfigWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 400, 125);
   SubWizardWindow.setText(getText(lblWriteRegKey));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow2";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\configwizardtemplate_writeregkey2.htm", "layersubwizard");

   document.getElementById("legWriteRegKey").innerHTML = getText(legWriteRegKey);
   document.getElementById("lblValueName").innerHTML = getText(lblValueName);
   document.getElementById("lblValueData").innerHTML = getText(lblValueData);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   AutoSizeWindow(SubWizardWindow, "layersubwizard");

   document.getElementById("ValueName").focus();
}

function HideWriteRegKey2(ok)
{
   position = "configwizard_wizards.js";
   whatfunc = "HideWriteRegKey2()";

   if (ok)
   {
      var txt;

      txt = '{JSCRIPT}=WriteRegKey(';
      txt += '"'+document.getElementById("ValueName").value+'"';
      txt += ',new Array("'+document.getElementById("ValueData").value.replace(/\r/g,'", "')+'")';
      txt += ',"'+WriteRegType+'"';
      txt += ')';

      HandleCommandsSelectionMenu(txt);

      ConfigUpdated();
   }

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = ConfigWindow.getText();
   dhxWins.window("ConfigWindow").setModal(true);
}

function ShowSetSecurityCenter_XP()
{
   position = "configwizard_wizards.js";
   whatfunc = "ShowSetSecurityCenter_XP()";

   dhxWins.window("ConfigWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 325, 125);
   SubWizardWindow.setText(getText(lblSecurityCenterSettings));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\configwizardtemplate_securitycenter_xp.htm", "layersubwizard");

   document.getElementById("legSecurityCenterSettings").innerHTML = getText(legSecurityCenterSettings);
   document.getElementById("lblFirewall").innerHTML = getText(lblFirewall);
   document.getElementById("lblAutomaticUpdates").innerHTML = getText(lblAutomaticUpdates);
   document.getElementById("lblVirusProtection").innerHTML = getText(lblVirusProtection);
   document.getElementById("lblFirstRunDisabled").innerHTML = getText(lblFirstRunDisabled);
   document.getElementById("lblDisableSecurityCenter").innerHTML = getText(lblDisableSecurityCenter);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   AutoSizeWindow(SubWizardWindow, "layersubwizard");
}

function HideSetSecurityCenter_XP(ok)
{
   position = "configwizard_wizards.js";
   whatfunc = "HideSetSecurityCenter_XP()";

   if (ok)
   {
      var txt;

      txt = '{JSCRIPT}=SetSecurityCenter_XP(';
      txt += (document.getElementById("Firewall").checked ? 'true' : 'false');
      txt += ',' + (document.getElementById("AutomaticUpdates").checked ? 'true' : 'false');
      txt += ',' + (document.getElementById("VirusProtection").checked ? 'true' : 'false');
      txt += ',' + (document.getElementById("FirstRunDisabled").checked ? 'true' : 'false');
      txt += ',' + (document.getElementById("DisableSecurityCenter").checked ? 'true' : 'false');
      txt += ')';

      HandleCommandsSelectionMenu(txt);

      ConfigUpdated();
   }

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = ConfigWindow.getText();
   dhxWins.window("ConfigWindow").setModal(true);
}

function ShowScreenSaver()
{
   position = "configwizard_wizards.js";
   whatfunc = "ShowScreenSaver()";

   dhxWins.window("ConfigWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 400, 125);
   SubWizardWindow.setText(getText(lblScreenSaverSettings));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\configwizardtemplate_screensaver.htm", "layersubwizard");

   document.getElementById("legScreenSaver").innerHTML = getText(legScreenSaver);
   document.getElementById("lblWait").innerHTML = getText(lblWait);
   document.getElementById("lblMinutes").innerHTML = getText(optMinutes);
   document.getElementById("lblScreenSaverIsSecure").innerHTML = getText(lblScreenSaverIsSecure);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);

   with (document.getElementById("ScreenSavers"))
   {
      options[0].text = getText(optNoneSS);
      var opt = document.getElementById("ScreenSavers").getElementsByTagName("OPTGROUP");
      opt[0].label = getText(lblXP);
      options[1].text = getText(opt3DFlowerBox);
      options[2].text = getText(opt3DFlyingObjects);
      options[3].text = getText(opt3DPipes);
      options[4].text = getText(opt3DText);
      options[5].text = getText(optBeziers);
      options[6].text = getText(optBlank);
      options[7].text = getText(optMarquee);
      options[8].text = getText(optMystify);
      options[9].text = getText(optStarfield);
      options[10].text = getText(optWindowsXP);

      var opt = document.getElementById("ScreenSavers").getElementsByTagName("OPTGROUP");
      opt[1].label = getText(lblVista);
      options[11].text = getText(opt3DText);
      options[12].text = getText(optAurora);
      options[13].text = getText(optBlank);
      options[14].text = getText(optBubbles);
      options[15].text = getText(optMystify);
      options[16].text = getText(optRibbons);
      options[17].text = getText(optWindowsEnergy);
      options[18].text = getText(optWindowsLogo);

      var opt = document.getElementById("ScreenSavers").getElementsByTagName("OPTGROUP");
      opt[2].label = getText(lblWindows7);
      options[19].text = getText(opt3DText);
      options[20].text = getText(optBubbles);
      options[21].text = getText(optMystify);
      options[22].text = getText(optRibbons);
   }

   HandleScreenSavers();

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   AutoSizeWindow(SubWizardWindow, "layersubwizard");
}

function HandleScreenSavers()
{
   position = "networkwizard.js";
   whatfunc = "HandleScreenSavers()";

   if (document.getElementById("ScreenSavers").value == "(none)")
   {
      document.getElementById("Wait").disabled = true;
      document.getElementById("IsSecure").disabled = true;
   }
   else
   {
      document.getElementById("Wait").disabled = false;
      document.getElementById("IsSecure").disabled = false;
   }
}

function HideScreenSaver(ok)
{
   position = "configwizard_wizards.js";
   whatfunc = "HideScreenSaver()";

   if (ok)
   {
      var txt;

      txt = '{JSCRIPT}=ScreenSaver(';
      txt += '"'+document.getElementById("ScreenSavers").value+'"';
      txt += ',' + document.getElementById("Wait").value;
      txt += ',' + (document.getElementById("IsSecure").checked ? "true" : "false") + '';
      txt += ')';

      HandleCommandsSelectionMenu(txt);

      ConfigUpdated();
   }

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = ConfigWindow.getText();
   dhxWins.window("ConfigWindow").setModal(true);
}

function ShowPowerOptions()
{
   position = "configwizard_wizards.js";
   whatfunc = "ShowPowerOptions()";

   dhxWins.window("ConfigWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 550, 370);
   SubWizardWindow.setText(getText(lblPowerOptionsProperties));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   SubWizardWindow.attachObject("layersubwizard");

   CreateTab("\\Common\\configwizardtemplate_poweroptions.htm", "layersubwizard");
   CreateTab("\\Common\\configwizardtemplate_poweroptions_powerschemes.htm", "tabtabPowerSchemes");
   CreateTab("\\Common\\configwizardtemplate_poweroptions_alarms.htm", "tabtabAlarms");
   CreateTab("\\Common\\configwizardtemplate_poweroptions_advanced.htm", "tabtabAdvanced");
   CreateTab("\\Common\\configwizardtemplate_poweroptions_hibernate.htm", "tabtabHibernate");

   powerTabs = new dhtmlXTabBar("PowerTabs", "top");
   powerTabs.setImagePath("../common/codebase/imgs/");
   powerTabs.setStyle(dhxSkin);
   powerTabs.enableForceHiding(true);
   var tablist = new Array('tabPowerSchemes', 'tabAlarms', 'tabAdvanced', 'tabHibernate');
   for (var i = 0; i < tablist.length; i ++ )
   {
      powerTabs.addTab("Tab" + (i + 1).toString(), getText(eval(tablist[i])), "" + Math.round((parseInt(document.getElementById("PowerTabs").offsetWidth) - 16) / tablist.length) + "px");
   }

   document.getElementById("legPowerSchemes").innerHTML = getText(legPowerSchemes);
   document.getElementById("lblCustomScheme").innerHTML = getText(lblCustomScheme);
   document.getElementById("legSettingsForPowerScheme").innerHTML = getText(legSettingsForPowerScheme);
   document.getElementById("lblWhenComputerIs").innerHTML = getText(lblWhenComputerIs);
   document.getElementById("lblDesktopPluggedIn").innerHTML = getText(lblDesktopPluggedIn);
   document.getElementById("lblRunningOnBatteries").innerHTML = getText(lblRunningOnBatteries);
   document.getElementById("lblTurnOffMonitor").innerHTML = getText(lblTurnOffMonitor);
   document.getElementById("lblTurnOffHardDisks").innerHTML = getText(lblTurnOffHardDisks);
   document.getElementById("lblSystemStandby").innerHTML = getText(lblSystemStandby);
   document.getElementById("lblSystemHibernate").innerHTML = getText(lblSystemHibernate);
   document.getElementById("legLowBatteryAlarm").innerHTML = getText(legLowBatteryAlarm);
   document.getElementById("lblActivateLowBatteryAlarm").innerHTML = getText(lblActivateLowBatteryAlarm);
   document.getElementById("lblLowAlarmAction").innerHTML = getText(lblAlarmAction);
   document.getElementById("legCriticalBatteryAlarm").innerHTML = getText(legCriticalBatteryAlarm);
   document.getElementById("lblActivateCriticalBatteryAlarm").innerHTML = getText(lblActivateCriticalBatteryAlarm);
   document.getElementById("lblCriticalAlarmAction").innerHTML = getText(lblAlarmAction);
   document.getElementById("legOptionsPO").innerHTML = getText(legOptions);
   document.getElementById("lblAlwaysShowIcon").innerHTML = getText(lblAlwaysShowIcon);
   document.getElementById("lblPromptForPassword").innerHTML = getText(lblPromptForPassword);
   document.getElementById("legPowerButtons").innerHTML = getText(legPowerButtons);
   document.getElementById("lblWhenCloseLid").innerHTML = getText(lblWhenCloseLid);
   document.getElementById("lblWhenPressPower").innerHTML = getText(lblWhenPressPower);
   document.getElementById("lblWhenPressSleep").innerHTML = getText(lblWhenPressSleep);
   document.getElementById("legHibernate").innerHTML = getText(legHibernate);
   document.getElementById("lblEnableHibernation").innerHTML = getText(lblEnableHibernation);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);

   with (document.getElementById("PowerSchemes"))
   {
      var opt = document.getElementById("PowerSchemes").getElementsByTagName("OPTGROUP");
      opt[0].label = getText(lblXP);
      options[0].text = getText(optHomeOfficeDesk);
      options[1].text = getText(optPortableLaptop);
      options[2].text = getText(optPresentation);
      options[3].text = getText(optAlwaysOn);
      options[4].text = getText(optMinPowerMan);
      options[5].text = getText(optMaxBattery);

      var opt = document.getElementById("PowerSchemes").getElementsByTagName("OPTGROUP");
      opt[1].label = getText(lblVista);
      options[6].text = getText(optBalanced);
      options[7].text = getText(optPowerSaver);
      options[8].text = getText(optHighPerformance);

      var opt = document.getElementById("PowerSchemes").getElementsByTagName("OPTGROUP");
      opt[2].label=getText(lblWindows7);
		options[9].text=getText(optBalanced);
		options[10].text=getText(optPowerSaver);
		options[11].text=getText(optHighPerformance); 
		options[12].text=getText(optCustom);    
		
	 var opt=document.getElementById("PowerSchemes").getElementsByTagName("OPTGROUP");
		opt[3].label=getText(lblWindows8);
		options[12].text=getText(optBalanced);
		options[13].text=getText(optPowerSaver);
		options[14].text=getText(optHighPerformance); 
		options[15].text=getText(optCustom);       
   }

   with (document.getElementById("MonitorAC"))
   {
      options[0].text = getText(optAfter) + " 1 " + getText(optMinute);
      options[1].text = getText(optAfter) + " 2 " + getText(optMinutes);
      options[2].text = getText(optAfter) + " 3 " + getText(optMinutes);
      options[3].text = getText(optAfter) + " 5 " + getText(optMinutes);
      options[4].text = getText(optAfter) + " 10 " + getText(optMinutes);
      options[5].text = getText(optAfter) + " 15 " + getText(optMinutes);
      options[6].text = getText(optAfter) + " 20 " + getText(optMinutes);
      options[7].text = getText(optAfter) + " 25 " + getText(optMinutes);
      options[8].text = getText(optAfter) + " 30 " + getText(optMinutes);
      options[9].text = getText(optAfter) + " 45 " + getText(optMinutes);
      options[10].text = getText(optAfter) + " 1 " + getText(optHour);
      options[11].text = getText(optAfter) + " 2 " + getText(optHours);
      options[12].text = getText(optAfter) + " 3 " + getText(optHours);
      options[13].text = getText(optAfter) + " 4 " + getText(optHours);
      options[14].text = getText(optAfter) + " 5 " + getText(optHours);
      options[15].text = getText(optNever);
   }
   with (document.getElementById("MonitorDC"))
   {
      options[0].text = getText(optAfter) + " 1 " + getText(optMinute);
      options[1].text = getText(optAfter) + " 2 " + getText(optMinutes);
      options[2].text = getText(optAfter) + " 3 " + getText(optMinutes);
      options[3].text = getText(optAfter) + " 5 " + getText(optMinutes);
      options[4].text = getText(optAfter) + " 10 " + getText(optMinutes);
      options[5].text = getText(optAfter) + " 15 " + getText(optMinutes);
      options[6].text = getText(optAfter) + " 20 " + getText(optMinutes);
      options[7].text = getText(optAfter) + " 25 " + getText(optMinutes);
      options[8].text = getText(optAfter) + " 30 " + getText(optMinutes);
      options[9].text = getText(optAfter) + " 45 " + getText(optMinutes);
      options[10].text = getText(optAfter) + " 1 " + getText(optHour);
      options[11].text = getText(optAfter) + " 2 " + getText(optHours);
      options[12].text = getText(optAfter) + " 3 " + getText(optHours);
      options[13].text = getText(optAfter) + " 4 " + getText(optHours);
      options[14].text = getText(optAfter) + " 5 " + getText(optHours);
      options[15].text = getText(optNever);
   }

   with (document.getElementById("HardDisksAC"))
   {
      options[0].text = getText(optAfter) + " 3 " + getText(optMinutes);
      options[1].text = getText(optAfter) + " 5 " + getText(optMinutes);
      options[2].text = getText(optAfter) + " 10 " + getText(optMinutes);
      options[3].text = getText(optAfter) + " 15 " + getText(optMinutes);
      options[4].text = getText(optAfter) + " 20 " + getText(optMinutes);
      options[5].text = getText(optAfter) + " 25 " + getText(optMinutes);
      options[6].text = getText(optAfter) + " 30 " + getText(optMinutes);
      options[7].text = getText(optAfter) + " 45 " + getText(optMinutes);
      options[8].text = getText(optAfter) + " 1 " + getText(optHour);
      options[9].text = getText(optAfter) + " 2 " + getText(optHours);
      options[10].text = getText(optAfter) + " 3 " + getText(optHours);
      options[11].text = getText(optAfter) + " 4 " + getText(optHours);
      options[12].text = getText(optAfter) + " 5 " + getText(optHours);
      options[13].text = getText(optNever);
   }
   with (document.getElementById("HardDisksDC"))
   {
      options[0].text = getText(optAfter) + " 3 " + getText(optMinutes);
      options[1].text = getText(optAfter) + " 5 " + getText(optMinutes);
      options[2].text = getText(optAfter) + " 10 " + getText(optMinutes);
      options[3].text = getText(optAfter) + " 15 " + getText(optMinutes);
      options[4].text = getText(optAfter) + " 20 " + getText(optMinutes);
      options[5].text = getText(optAfter) + " 25 " + getText(optMinutes);
      options[6].text = getText(optAfter) + " 30 " + getText(optMinutes);
      options[7].text = getText(optAfter) + " 45 " + getText(optMinutes);
      options[8].text = getText(optAfter) + " 1 " + getText(optHour);
      options[9].text = getText(optAfter) + " 2 " + getText(optHours);
      options[10].text = getText(optAfter) + " 3 " + getText(optHours);
      options[11].text = getText(optAfter) + " 4 " + getText(optHours);
      options[12].text = getText(optAfter) + " 5 " + getText(optHours);
      options[13].text = getText(optNever);
   }

   with (document.getElementById("StandbyAC"))
   {
      options[0].text = getText(optAfter) + " 1 " + getText(optMinute);
      options[1].text = getText(optAfter) + " 2 " + getText(optMinutes);
      options[2].text = getText(optAfter) + " 3 " + getText(optMinutes);
      options[3].text = getText(optAfter) + " 5 " + getText(optMinutes);
      options[4].text = getText(optAfter) + " 10 " + getText(optMinutes);
      options[5].text = getText(optAfter) + " 15 " + getText(optMinutes);
      options[6].text = getText(optAfter) + " 20 " + getText(optMinutes);
      options[7].text = getText(optAfter) + " 25 " + getText(optMinutes);
      options[8].text = getText(optAfter) + " 30 " + getText(optMinutes);
      options[9].text = getText(optAfter) + " 45 " + getText(optMinutes);
      options[10].text = getText(optAfter) + " 1 " + getText(optHour);
      options[11].text = getText(optAfter) + " 2 " + getText(optHours);
      options[12].text = getText(optAfter) + " 3 " + getText(optHours);
      options[13].text = getText(optAfter) + " 4 " + getText(optHours);
      options[14].text = getText(optAfter) + " 5 " + getText(optHours);
      options[15].text = getText(optNever);
   }
   with (document.getElementById("StandbyDC"))
   {
      options[0].text = getText(optAfter) + " 1 " + getText(optMinute);
      options[1].text = getText(optAfter) + " 2 " + getText(optMinutes);
      options[2].text = getText(optAfter) + " 3 " + getText(optMinutes);
      options[3].text = getText(optAfter) + " 5 " + getText(optMinutes);
      options[4].text = getText(optAfter) + " 10 " + getText(optMinutes);
      options[5].text = getText(optAfter) + " 15 " + getText(optMinutes);
      options[6].text = getText(optAfter) + " 20 " + getText(optMinutes);
      options[7].text = getText(optAfter) + " 25 " + getText(optMinutes);
      options[8].text = getText(optAfter) + " 30 " + getText(optMinutes);
      options[9].text = getText(optAfter) + " 45 " + getText(optMinutes);
      options[10].text = getText(optAfter) + " 1 " + getText(optHour);
      options[11].text = getText(optAfter) + " 2 " + getText(optHours);
      options[12].text = getText(optAfter) + " 3 " + getText(optHours);
      options[13].text = getText(optAfter) + " 4 " + getText(optHours);
      options[14].text = getText(optAfter) + " 5 " + getText(optHours);
      options[15].text = getText(optNever);
   }

   with (document.getElementById("HibernateAC"))
   {
      options[0].text = getText(optAfter) + " 25 " + getText(optMinutes);
      options[1].text = getText(optAfter) + " 30 " + getText(optMinutes);
      options[2].text = getText(optAfter) + " 45 " + getText(optMinutes);
      options[3].text = getText(optAfter) + " 1 " + getText(optHour);
      options[4].text = getText(optAfter) + " 2 " + getText(optHours);
      options[5].text = getText(optAfter) + " 3 " + getText(optHours);
      options[6].text = getText(optAfter) + " 4 " + getText(optHours);
      options[7].text = getText(optAfter) + " 5 " + getText(optHours);
      options[8].text = getText(optAfter) + " 6 " + getText(optHours);
      options[9].text = getText(optNever);
   }
   with (document.getElementById("HibernateDC"))
   {
      options[0].text = getText(optAfter) + " 25 " + getText(optMinutes);
      options[1].text = getText(optAfter) + " 30 " + getText(optMinutes);
      options[2].text = getText(optAfter) + " 45 " + getText(optMinutes);
      options[3].text = getText(optAfter) + " 1 " + getText(optHour);
      options[4].text = getText(optAfter) + " 2 " + getText(optHours);
      options[5].text = getText(optAfter) + " 3 " + getText(optHours);
      options[6].text = getText(optAfter) + " 4 " + getText(optHours);
      options[7].text = getText(optAfter) + " 5 " + getText(optHours);
      options[8].text = getText(optAfter) + " 6 " + getText(optHours);
      options[9].text = getText(optNever);
   }

   with (document.getElementById("LowAlarmAction"))
   {
      options[0].text = getText(optDoNothing);
      options[1].text = getText(optStandBy);
      options[2].text = getText(optHibernate);
      options[3].text = getText(optShutDown2);
   }
   with (document.getElementById("CriticalAlarmAction"))
   {
      options[0].text = getText(optDoNothing);
      options[1].text = getText(optStandBy);
      options[2].text = getText(optHibernate);
      options[3].text = getText(optShutDown2);
   }

   with (document.getElementById("WhenCloseLid"))
   {
      options[0].text = getText(optDoNothing);
      options[1].text = getText(optStandBy);
      options[2].text = getText(optHibernate);
      options[3].text = getText(optShutDown2);
   }
   with (document.getElementById("WhenPressPower"))
   {
      options[0].text = getText(optDoNothing);
      options[1].text = getText(optStandBy);
      options[2].text = getText(optHibernate);
      options[3].text = getText(optShutDown2);
   }
   with (document.getElementById("WhenPressSleep"))
   {
      options[0].text = getText(optDoNothing);
      options[1].text = getText(optStandBy);
      options[2].text = getText(optHibernate);
      options[3].text = getText(optShutDown2);
   }

   LowBatterySlider = new dhtmlxSlider("LowBatterySlider", 400, "arrowgreen", false, 0, 100, null, 1);
   LowBatterySlider.setImagePath("../common/codebase/imgs/");
   LowBatterySlider.attachEvent("onChange", SetLowAlarmValue);
   LowBatterySlider.init();
   LowBatterySlider.setValue(10);

   CriticalBatterySlider = new dhtmlxSlider("CriticalBatterySlider", 400, "arrowgreen", false, 0, 100, null, 1);
   CriticalBatterySlider.setImagePath("../common/codebase/imgs/");
   CriticalBatterySlider.attachEvent("onChange", SetCriticalAlarmValue);
   CriticalBatterySlider.init();
   CriticalBatterySlider.setValue(5);

   for (var i = 0; i < tablist.length; i ++ )
   {
      powerTabs.setContent("Tab" + (i + 1).toString(), "tab" + tablist[i]);
   }

   powerTabs.setTabActive('Tab1');


   HandlePowerSchemes();
   // set defaults
   document.getElementById("layersubwizard").style.display = 'block';
}

function HandlePowerSchemes()
{
   position = "configwizard_wizards.js";
   whatfunc = "HandlePowerSchemes()";

   var scheme;

   if (document.getElementById("PowerSchemes").value == "Home/Office Desk")
   scheme = 0;
   if (document.getElementById("PowerSchemes").value == "Portable/Laptop")
   scheme = 1;
   if (document.getElementById("PowerSchemes").value == "Presentation")
   scheme = 2;
   if (document.getElementById("PowerSchemes").value == "Always On")
   scheme = 3;
   if (document.getElementById("PowerSchemes").value == "Minimal Power Management")
   scheme = 4;
   if (document.getElementById("PowerSchemes").value == "Max Battery")
   scheme = 5;
   if (document.getElementById("PowerSchemes").value == "381b4222-f694-41f0-9685-ff5bb260df2e")
   scheme = 6;
   if (document.getElementById("PowerSchemes").value == "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c")
   scheme = 7;
   if (document.getElementById("PowerSchemes").value == "a1841308-3541-4fab-bc81-f71556f20b4a")
   scheme = 8;

   if (document.getElementById("PowerSchemes").value == "custom")
   {
      document.getElementById("CustomScheme").disabled = false;
      document.getElementById("CustomScheme").value = getText(txtNew);
      document.getElementById("CustomScheme").focus();
      selectText(this.document.all.CustomScheme, getText(txtNew));
      document.getElementById("MonitorAC").value = PowerSchemes.Scheme[0].MonitorAC;
      document.getElementById("MonitorDC").value = PowerSchemes.Scheme[0].MonitorDC;
      document.getElementById("HardDisksAC").value = PowerSchemes.Scheme[0].HardDiskAC;
      document.getElementById("HardDisksDC").value = PowerSchemes.Scheme[0].HardDiskDC;
      document.getElementById("StandbyAC").value = PowerSchemes.Scheme[0].StandbyAC;
      document.getElementById("StandbyDC").value = PowerSchemes.Scheme[0].StandbyDC;
      document.getElementById("HibernateAC").value = PowerSchemes.Scheme[0].HibernateAC;
      document.getElementById("HibernateDC").value = PowerSchemes.Scheme[0].HibernateDC;
      document.getElementById("LowBatteryAlarm").checked = true;
      LowBatterySlider.setValue(10);
      document.getElementById("LowAlarmAction").value = 0;
      document.getElementById("CriticalBatteryAlarm").checked = true;
      CriticalBatterySlider.setValue(5);
      document.getElementById("CriticalAlarmAction").value = 0;
      document.getElementById("ShowIcon").checked = PowerSchemes.Scheme[0].Icon;
      document.getElementById("PromptPassword").checked = PowerSchemes.Scheme[0].Prompt;
      document.getElementById("WhenCloseLid").value = PowerSchemes.Scheme[0].CloseLid;
      document.getElementById("WhenPressPower").value = PowerSchemes.Scheme[0].PowerButton;
      document.getElementById("WhenPressSleep").value = PowerSchemes.Scheme[0].SleepButton;
      document.getElementById("Hibernate").checked = PowerSchemes.Scheme[0].Hibernate;
   }
   else
   {
      document.getElementById("CustomScheme").value = "";
      document.getElementById("CustomScheme").disabled = true;
      document.getElementById("MonitorAC").value = PowerSchemes.Scheme[scheme].MonitorAC;
      document.getElementById("MonitorDC").value = PowerSchemes.Scheme[scheme].MonitorDC;
      document.getElementById("HardDisksAC").value = PowerSchemes.Scheme[scheme].HardDiskAC;
      document.getElementById("HardDisksDC").value = PowerSchemes.Scheme[scheme].HardDiskDC;
      document.getElementById("StandbyAC").value = PowerSchemes.Scheme[scheme].StandbyAC;
      document.getElementById("StandbyDC").value = PowerSchemes.Scheme[scheme].StandbyDC;
      document.getElementById("HibernateAC").value = PowerSchemes.Scheme[scheme].HibernateAC;
      document.getElementById("HibernateDC").value = PowerSchemes.Scheme[scheme].HibernateDC;
      document.getElementById("LowBatteryAlarm").checked = true;
      LowBatterySlider.setValue(10);
      document.getElementById("LowAlarmAction").value = 0;
      document.getElementById("CriticalBatteryAlarm").checked = true;
      CriticalBatterySlider.setValue(5);
      document.getElementById("CriticalAlarmAction").value = 0;
      document.getElementById("ShowIcon").checked = PowerSchemes.Scheme[scheme].Icon;
      document.getElementById("PromptPassword").checked = PowerSchemes.Scheme[0].Prompt;
      document.getElementById("WhenCloseLid").value = PowerSchemes.Scheme[scheme].CloseLid;
      document.getElementById("WhenPressPower").value = PowerSchemes.Scheme[scheme].PowerButton;
      document.getElementById("WhenPressSleep").value = PowerSchemes.Scheme[scheme].SleepButton;
      document.getElementById("Hibernate").checked = PowerSchemes.Scheme[0].Hibernate;
   }
}

function SetLowAlarmValue(value, slider)
{
   position = "configwizard_wizards.js";
   whatfunc = "SetLowAlarmValue()";

   document.getElementById("LowBatteryLevel").innerHTML = value + "%";
}

function SetCriticalAlarmValue(value, slider)
{
   position = "configwizard_wizards.js";
   whatfunc = "SetCriticalAlarmValue()";

   document.getElementById("CriticalBatteryLevel").innerHTML = value + "%";
}

function HidePowerOptions(ok)
{
   position = "configwizard_wizards.js";
   whatfunc = "HidePowerOptions()";

   if (ok)
   {
      var txt;

      txt = '{JSCRIPT}=PowerOptions(';
      txt += '"'+document.getElementById("PowerSchemes").value+'"';
      txt += ',"'+document.getElementById("CustomScheme").value+'"';
      txt += ',' + document.getElementById("MonitorAC").value;
      txt += ',' + document.getElementById("MonitorDC").value;
      txt += ',' + document.getElementById("HardDisksAC").value;
      txt += ',' + document.getElementById("HardDisksDC").value;
      txt += ',' + document.getElementById("StandbyAC").value;
      txt += ',' + document.getElementById("StandbyDC").value;
      txt += ',' + document.getElementById("HibernateAC").value;
      txt += ',' + document.getElementById("HibernateDC").value;
      txt += ',' + (document.getElementById("LowBatteryAlarm").checked ? 'true' : 'false');
      txt += ',' + LowBatterySlider.getValue();
      txt += ',' + document.getElementById("LowAlarmAction").value;
      txt += ',' + (document.getElementById("CriticalBatteryAlarm").checked ? 'true' : 'false');
      txt += ',' + CriticalBatterySlider.getValue();
      txt += ',' + document.getElementById("CriticalAlarmAction").value;
      txt += ',' + (document.getElementById("ShowIcon").checked ? 'true' : 'false');
      txt += ',' + (document.getElementById("PromptPassword").checked ? 'true' : 'false');
      txt += ',' + document.getElementById("WhenCloseLid").value;
      txt += ',' + document.getElementById("WhenPressPower").value;
      txt += ',' + document.getElementById("WhenPressSleep").value;
      txt += ',' + (document.getElementById("Hibernate").checked ? 'true' : 'false');
      txt += ')';

      HandleCommandsSelectionMenu(txt);

      ConfigUpdated();
   }

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = ConfigWindow.getText();
   dhxWins.window("ConfigWindow").setModal(true);
}

function ShowErrorReporting()
{
   position = "configwizard_wizards.js";
   whatfunc = "ShowErrorReporting()";

   dhxWins.window("ConfigWindow").setModal(false);

   SubWizardWindow = dhxWins.createWindow("SubWizardWindow", 50, 50, 400, 125);
   SubWizardWindow.setText(getText(lblErrorReporting));
   SubWizardWindow.setModal(true);
   SubWizardWindow.button("park").hide();
   SubWizardWindow.button("minmax1").hide();
   SubWizardWindow.button("close").hide();
   SubWizardWindow.keepInViewport(true);
   SubWizardWindow.denyResize();
   SubWizardWindow.center();
   ActiveWindow = "SubWizardWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layersubwizard";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   CreateTab("\\Common\\configwizardtemplate_errorreporting.htm", "layersubwizard");

   document.getElementById("legErrorReporting").innerHTML = getText(legErrorReporting);
   document.getElementById("lblDisableErrorReporting").innerHTML = getText(lblDisableErrorReporting);
   document.getElementById("lblButNotifyMe").innerHTML = getText(lblButNotifyMe);
   document.getElementById("lblEnableErrorReporting").innerHTML = getText(lblEnableErrorReporting);
   document.getElementById("lblWindowsOS").innerHTML = getText(lblWindowsOS);
   document.getElementById("lblPrograms").innerHTML = getText(lblPrograms);
   document.getElementById("lblOK").innerHTML = getText(lblOK);
   document.getElementById("lblCancel").innerHTML = getText(lblCancel);

   HandleErrorReporting();

   SubWizardWindow.attachObject("layersubwizard");
   document.getElementById("layersubwizard").style.display = 'block';

   AutoSizeWindow(SubWizardWindow, "layersubwizard");
}

function HandleErrorReporting()
{
   position = "networkwizard.js";
   whatfunc = "HandleErrorReporting()";

   if (document.getElementById("DisableErrorReporting").checked)
   {
      document.getElementById("NotifyMe").disabled = false;
      document.getElementById("WindowsOS").disabled = true;
      document.getElementById("Programs").disabled = true;
   }
   else
   {
      document.getElementById("NotifyMe").checked = true;
      document.getElementById("NotifyMe").disabled = true;
      document.getElementById("WindowsOS").disabled = false;
      document.getElementById("Programs").disabled = false;
   }
}

function HideErrorReporting(ok)
{
   position = "configwizard_wizards.js";
   whatfunc = "HideErrorReporting()";

   if (ok)
   {
      var txt;

      txt = '{JSCRIPT}=ErrorReporting(';
      txt += (document.getElementById("EnableErrorReporting").checked ? "true" : "false");
      txt += ',' + (document.getElementById("NotifyMe").checked ? "true" : "false");
      txt += ',' + (document.getElementById("WindowsOS").checked ? "true" : "false");
      txt += ',' + (document.getElementById("Programs").checked ? "true" : "false");
      txt += ')';

      HandleCommandsSelectionMenu(txt);

      ConfigUpdated();
   }

   if (dhxWins.isWindow("SubWizardWindow"))
   {
      SubWizardWindow.close();
      SubWizardWindow = null;
   }

   ActiveWindow = ConfigWindow.getText();
   dhxWins.window("ConfigWindow").setModal(true);
}
