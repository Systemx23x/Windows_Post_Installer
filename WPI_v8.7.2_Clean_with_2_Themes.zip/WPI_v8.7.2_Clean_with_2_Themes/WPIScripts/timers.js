//************************************************
// Windows Post-Install Wizard
// timers.js
//************************************************

function startInterval()
{
	position="timers.js";
	whatfunc="startInterval()";

	if (interval != "")
		return;

	if (Seconds<1)
		Seconds=1;
	startSecs=Seconds;
	if (Seconds>3600)
		Seconds=3600;
	if (Seconds>60)
	{
		m=parseInt(Seconds/60);
		Seconds=Seconds-(m*60);
	}
	else
		m=0;

	interval=window.setInterval("tTimer()",1000);
}

function stopInterval()
{
	position="timers.js";
	whatfunc="stopInterval()";

	if (interval != "")
	{
		window.clearInterval(interval);
		interval="";
		document.getElementById("TimerLayer").style.visibility="hidden";
	}
}

function tTimer()
{
	position="timers.js";
	whatfunc="tTimer()";

	var txt="";

	if (Seconds==0)
		Seconds=1;

	txt=m+":"+ --Seconds;

	if (Seconds==0)
	{
		txt=m+":"+"0"+Seconds;
		m--;
		Seconds=60;
	}

	if (Seconds<10 && Seconds>-1)
		txt=m+":"+"0"+Seconds;

	document.getElementById("TimerDisplay").innerHTML=txt;
	passed++;

	document.getElementById("Timer_bar").style.width=Math.abs(TimerWidth-Math.floor((passed/startSecs)*TimerWidth))+"px";

	if (m==0 && Seconds<=StartBeepAtSecs)
		PlaySound(wpipath+"\\Themes\\"+Theme+"\\TimerSound.wav");

	if (Seconds==60 && m<0)
	{
		document.getElementById("TimerDisplay").innerHTML="0:00";
		document.getElementById("Timer_bar").width=0;
		Pause(0,250);

		stopInterval();

		checkInstall('timer');
	}
}

function PlaySound(soundfile)
{
	position="timers.js";
	whatfunc="PlaySound()";

	var TimerSoundElement = document.getElementById("TimerSound"); 
        if (TimerSoundElement) 
        { 
                StopSound(); 
                TimerSoundElement.src=ReplacePath(soundfile).replace(/\"/g,''); 
        }

}

function StopSound()
{
	position="timers.js";
	whatfunc="StopSound()";

	document.getElementById("TimerSound").src="";
}

function ins_initInterval()
{
	position="timers.js";
	whatfunc="ins_initInterval()";

	var startDate=new Date();
	ins_startSecs=(startDate.getHours()*60*60) + (startDate.getMinutes()*60) + startDate.getSeconds();
}

function ins_startInterval()
{
	position="timers.js";
	whatfunc="ins_startInterval()";

	interval=window.setInterval("ins_iTimer()",1000);
}

function ins_stopInterval()
{
	position="timers.js";
	whatfunc="ins_stopInterval()";

	if (interval != "")
	{
		window.clearInterval(interval);
		interval="";
	}
}

function ins_iTimer()
{
	position="timers.js";
	whatfunc="ins_iTimer()";

	var txt="";
	var now=new Date();
	var nowSecs=(now.getHours()*60*60) + (now.getMinutes()*60) + now.getSeconds();
	var elapsedSecs=nowSecs - ins_startSecs;
	
	var hours=Math.floor(elapsedSecs/3600);
	elapsedSecs=elapsedSecs - (hours*3600);

	var minutes=Math.floor(elapsedSecs/60);
	elapsedSecs=elapsedSecs - (minutes*60);

	var seconds=elapsedSecs;

	txt=((hours < 10) ? "0" : "") + hours;
	txt += ((minutes < 10) ? ":0" : ":") + minutes;
	txt += ((seconds < 10) ? ":0" : ":") + seconds;

	document.getElementById("TimerDisplay").innerHTML=txt;
}
